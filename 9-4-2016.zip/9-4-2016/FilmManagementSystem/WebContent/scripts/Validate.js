function validateField(){
	
	//validation for title
	var flag=true;
	var filmname=film.fname.value;
	
	var filmtitle=filmf.filmtitle.value;
	var letters = /^[A-Za-z]+$/; 
	if(!filmtitle.match(letters)||filmtitle==""||filmtitle==null)  
	{  
		document.getElementById("titleerr").innerHTML="*Title is mandatory and should only contain alphabet"; 
		filmtitle.focus(); 
		return true;  
	}  
	else  
	{  
		document.getElementById("titleerr").innerHTML="";
		 
		return false;  
	}  
		
		
		//validation for ratings
	var rating=film.ratings.value;
	
	if(rating<=0 || rating>=5 )
		{
		  
          document.getElementById("ratingsErr").innerHTML="*Invalid Ratings.Please enter ratings fom 1 t0 5" ;
		
		flag=false;
		}else
			document.getElementById("ratingsErr").innerHTML="";
	
	
	//validation for length
	var length=film.length.value;
	
	if(length<=0 || length>1000)
		{
		 document.getElementById("lengthErr").innerHTML="*Invalid Length.Please enter length from 1 to 1000" ;
			
			flag=false;
			}else
				document.getElementById("lengthErr").innerHTML="";
		
		
	
	//validation for rental duration
	
	var releaseyear=film.releaseyear.value;
	var rentalduration=film.rentalduration.value;
	
	if(releaseyear>=rentalduration)
		{
		 document.getElementById("rentaldurationErr").innerHTML="*Invalid Rental Duration.Rental Duration should be greater than Release Year" ;
	
	flag=false;
	}else
		document.getElementById("rentaldurationErr").innerHTML="";
		
	
	return flag;
}