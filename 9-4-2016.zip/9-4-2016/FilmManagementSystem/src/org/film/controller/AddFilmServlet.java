package org.film.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.film.pojo.Actor;
import org.film.pojo.Category;
import org.film.pojo.Film;
import org.film.pojo.Language;
import org.film.service.FilmService;
import org.film.service.FilmServiceImpl;

/**
 * Servlet implementation class AddFilmServlet
 */
public class AddFilmServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		PrintWriter out=response.getWriter();
		FilmService filmService=new FilmServiceImpl();
		
		List<Language> languages=filmService.getAllLanguages();
		List<Category> categories=filmService.getAllACategories();
		List<Actor> actors=filmService.getAllActors();
		
		
		Film film=new Film();
		
		
		out.println("<html>");
		out.println("<head>");
		
		out.println("<link rel='stylesheet' type='text/css' href='../css/myStyle.css'>"+
                     "<script type='text/javascript' src='../scripts/Validate.js'></script>"+
                    "<link rel='stylesheet' type='text/css' href='../css/jquery-ui-1.9.2.custom.css'>"+
                     "<link rel='stylesheet' type='text/css' href='../css/jquery-ui-1.9.2.custom.min.css'>"+
                     "<script type='text/javascript' src='../scripts/jquery-1.8.3.js'></script>"+
                    "<script type='text/javascript' src='../scripts/jquery-ui-1.9.2.custom.js'></script>"+
                     "<script type='text/javascript' src='../scripts/jquery-ui-1.9.2.custom.min.js'></script>"+
                    // "<script type='text/javascript' src='../scripts/datepicker.js'></script>"+
                     "<script>$(function() {$('#datepicker1').datepicker({maxDate:'0'});});</script>"+
				"<script>$(function() {$( '#datepicker2' ).datepicker();});</script>");
                    
			
		out.println("<title>Film Details</title>");
		out.println("</head>");

		out.println("<body>");


		out.println("<form name='film' method='post' action='SaveFilmServlet'>");

		out.println("<h2><center>Film Registration Form</center></h1>");
		out.print("<table>");


		out.println("<tr>"
			+"<td>Title:</td>"
			+"<td><input type='text' name='fname' size='20' onmouseout='return validateField()'></td>"
			+"</tr>"
			+"<tr>");
			
			
		out.println("<tr>"
			+"<td> Description:</td>"
			+"<td>"
			+"<textarea rows='4' name='description' cols='25' onmouseout='return validateField()'></textarea>"
			+"</td>"
			+"</tr>");
			
			
			
			out.println("<tr>"
			+"<td>Release Year:</td>"
			+"<td>"
			+"<input type='date' name='releaseyear' id='datepicker1' size='20'>"
			+"</td>"
			+"</tr>");
			
			 out.println("<tr>"
					   +"<td>Original Language</td>");
					   out.println("<td><select name='orgLang' >");
					   for(Language lang:languages){
						   
							out.println("<option value='"+ lang.getLanguage_Id()+"'>"
									+lang.getLanguage_Name()+ "</option>");
							
							
					   }
					   
					 out.println("</select></td></tr>");
					 
					 
					 //Other Languages
					 

					 out.println("<tr>"
							   +"<td>Other Languages</td>");
							   out.println("<td><select name='otherLang' multiple=''>");
							   for(Language lang:languages){
								   
									out.println("<option value='"+ lang.getLanguage_Id()+"'>"
											+lang.getLanguage_Name()+ "</option>");
									
									
							   }
							   
							 out.println("</select></td></tr>");
							 
					 
					 out.println("<tr>"
								+"<td>Rental Duration:</td>"
								+"<td><input type='date' name='rentalduration' id='datepicker2' size='20' onmouseout='return validateField()'></td>"
								+"</tr>");
			
			out.println("<tr>"
			+"<td>Length</td>"
			+"<td>"
			+"<input type='text' name='length' size='20'></td>"
			+"</tr>");
			
			
			
			out.println("<tr>"
			+"<td>Replacement Cost:</td>"
			+"<td><input type='text' name='replacementcost' size='20' onmouseout='return validateField()'></td>"
			+"</tr>");
			
			
			out.println("<tr>"
				+"<td>Film Rating:</td>"
				+"<td>"
				+"<select name='ratings'>"
					+"<option value='1'>1</option>"
					+"<option value='2'>2</option>"
					+"<option value='3'>3</option>"
					+"<option value='4'>4</option>"
					+"<option value='5'>5</option>"
				+"</select>"
				
				+"</td>"
			+"</tr>");
			
			
			
			out.println("<tr>"
			+"<td>Special Features:</td>"
			+"<td>"
				+"<textarea rows='4' name='specialfeature' cols='25'></textarea>"
			+"</td>"
			+"</tr>");
			
			
			//category
			 out.println("<tr>"
					   +"<td>Category</td>");
					   out.println("<td><select name='category' >");
					   for(Category category:categories){
						   
							out.println("<option value='"+ category.getCategory_Id()+"'>"
									+category.getCategory_Name()+ "</option>");
							
							
					   }
					   
					 out.println("</select></td></tr>");
					 
					//Actor
					 out.println("<tr>"
							   +"<td>Choose Actor</td>");
							   out.println("<td><select name='actor' multiple=''>");
							   for(Actor actor:actors){
								   
									out.println("<option value='"+ actor.getActor_Id()+"'>"
											+actor.getFirstName()+actor.getLastName()+ "</option>");
									
									
							   }
							   
							 out.println("</select></td></tr>");
			
			
	
			out.println("<tr>"
				+"<td></td>"
				+"<td><input type='submit' value='Save'>"
				+"<input type='reset' value='Clear'>"
				 +"</td>"
			+"</tr>");
			
	out.println("</table>");


		out.println("</form>");


		out.println("</body>");
		out.println("</html>");

		
		
		
		
	}

		
		
		

}
