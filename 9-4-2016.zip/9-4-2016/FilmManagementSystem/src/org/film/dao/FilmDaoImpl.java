package org.film.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.film.pojo.Actor;
import org.film.pojo.Category;
import org.film.pojo.Film;
import org.film.pojo.Language;

public class FilmDaoImpl implements FilmDao{
	
	

public Connection getConnection(){
		
		Connection connection=null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/film_management","root","Pass1234");
			
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		return connection;
	}

	
	@Override
	public void AddFilmServlet(Film film) {
	
		
			
			Connection con=getConnection();
			
			String sql="insert into film(title,description,releaseYear,rentalDuration,originalLanguage,length,replacementCost,ratings,specialFeatures,category)"+"values(?,?,?,?,?,?,?,?,?,?)";
			try {
				PreparedStatement pst=con.prepareStatement(sql);
				pst.setString(1, film.getFilm_Title());
				
				pst.setString(2, film.getDescreption());
				
				pst.setDate(3, new Date(film.getRelease_Year().getTime()));
				
				pst.setDate(4, new Date(film.getRental_Duration().getTime()));
				
				pst.setObject(5,film.getOriginal_Language().getLanguage_Id());
			
				pst.setInt(6,film.getLength());
				pst.setDouble(7, film.getReplacement_Cost());
				pst.setInt(8, film.getRatings());
				pst.setString(9, film.getSpecial_Features());
				pst.setObject(10, film.getCategory().getCategory_Id());
				
				
				
				int count=pst.executeUpdate();
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			//save data into film_actors
			String str1="select * from film order by filmid desc limit 1 ";
			
			int fid=0;
			
			try {
				PreparedStatement pst=con.prepareStatement(str1);
				ResultSet rs=pst.executeQuery();
				
				while(rs.next())
				{
				fid=rs.getInt(1);
				}
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			String str2="insert into film_actors(film_id,actor_id)values(?,?)";
			
			
			try {
				PreparedStatement pst=con.prepareStatement(str2);
				List<Actor> actors=film.getActors();
				
				
				for(Actor actor:actors)
				{
					pst.setInt(1, fid);
					pst.setObject(2,actor.getActor_Id());
					
				}
				int count=pst.executeUpdate();
				pst.setObject(2, null);
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			
			//save data into film_language
			String str3="select * from film order by filmid desc limit 1 ";
			
			int filmid=0;
			
			try {
				PreparedStatement pst=con.prepareStatement(str3);
				ResultSet rs=pst.executeQuery();
				
				while(rs.next())
				{
				fid=rs.getInt(1);
				}
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			String str4="insert into film_language(film_id,language_id) values(?,?)";
			
			
			try {
				PreparedStatement pst=con.prepareStatement(str4);
				List<Language> languages=film.getLanguages();
				
				for(Language lang:languages)
				{
					pst.setInt(1, fid);
					pst.setObject(2,lang.getLanguage_Id());
				}
				int count=pst.executeUpdate();
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			
			
		}


	@Override

	public List<Language> getAllLanguages() {
		ArrayList<Language> languages=new ArrayList<>();
		String str="select * from language";
		Connection con=getConnection();
		
		try {
			PreparedStatement pst=con.prepareStatement(str);
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				Language lang=new Language();
				lang.setLanguage_Id(rs.getInt(1));
				lang.setLanguage_Name(rs.getString(2));
				
				
				
				
				//Adding the customer into arraylist
				languages.add(lang);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return languages;
	}


	@Override
	public List<Actor> getAllActors() {
		ArrayList<Actor> actors=new ArrayList<>();
		String str="select * from actors";
		Connection con=getConnection();
		
		try {
			PreparedStatement pst=con.prepareStatement(str);
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				Actor actor=new Actor();
				actor.setActor_Id(rs.getInt(1));
				actor.setFirstName(rs.getString(2));
				actor.setLastName(rs.getString(3));
				
				
				
				
				//Adding the customer into arraylist
				actors.add(actor);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return actors;
	}


	@Override
	public List<Category> getAllACategories() {
		ArrayList<Category> categories=new ArrayList<>();
		String str="select * from category";
		Connection con=getConnection();
		
		try {
			PreparedStatement pst=con.prepareStatement(str);
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				Category category=new Category();
				category.setCategory_Id(rs.getInt(1));
				category.setCategory_Name(rs.getString(2));
			   
				
				
				
				
				//Adding the customer into arraylist
				categories.add(category);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return categories;
	}
}


