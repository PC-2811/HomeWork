package org.film.pojo;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import java.util.Set;

public class Film {
	
	//private fields
		private int film_Id;
		private String descreption;
		private String film_Title;
	    private Date release_Year;
		private List<Language> languages;
		private Language original_Language;
		private Date rental_Duration;
		private int length;
		private double replacement_Cost;
		private int ratings;
		private String special_Features;
		private List<Actor> actors;
		private Category category;
		
		//No argument constructor
		public Film(){}

		//constructor with fields
		public Film(int film_Id, String descreption, String film_Title, Date release_Year, List<Language> languages,
				Language original_Language, Date rental_Duration, int length, double replacement_Cost, int ratings,
				String special_Features, List<Actor> actors, Category category) {
			super();
			this.film_Id = film_Id;
			this.descreption = descreption;
			this.film_Title = film_Title;
			this.release_Year = release_Year;
			this.languages = languages;
			this.original_Language = original_Language;
			this.rental_Duration = rental_Duration;
			this.length = length;
			this.replacement_Cost = replacement_Cost;
			this.ratings = ratings;
			this.special_Features = special_Features;
			this.actors = actors;
			this.category = category;
		}

		
		//Getters and Setters
		public int getFilm_Id() {
			return film_Id;
		}

	
		public void setFilm_Id(int film_Id) {
			this.film_Id = film_Id;
		}

		public String getDescreption() {
			return descreption;
		}

		public void setDescreption(String descreption) {
			this.descreption = descreption;
		}

		public String getFilm_Title() {
			return film_Title;
		}

		public void setFilm_Title(String film_Title) {
			this.film_Title = film_Title;
		}

		public Date getRelease_Year() {
			return release_Year;
		}

		public void setRelease_Year(Date release_Year) {
			this.release_Year = release_Year;
		}

		public List<Language> getLanguages() {
			return languages;
		}

		public void setLanguages(List<Language> languages) {
			this.languages = languages;
		}

		public Language getOriginal_Language() {
			return original_Language;
		}

		public void setOriginal_Language(Language original_Language) {
			this.original_Language = original_Language;
		}

		public Date getRental_Duration() {
			return rental_Duration;
		}

		public void setRental_Duration(Date rental_Duration) {
			this.rental_Duration = rental_Duration;
		}

		public int getLength() {
			return length;
		}

		public void setLength(int length) {
			this.length = length;
		}

		public double getReplacement_Cost() {
			return replacement_Cost;
		}

		public void setReplacement_Cost(double replacement_Cost) {
			this.replacement_Cost = replacement_Cost;
		}

		public int getRatings() {
			return ratings;
		}

		public void setRatings(int ratings) {
			this.ratings = ratings;
		}

		public String getSpecial_Features() {
			return special_Features;
		}

		public void setSpecial_Features(String special_Features) {
			this.special_Features = special_Features;
		}

		public List<Actor> getActors() {
			return actors;
		}

		public void setActors(List<Actor> actors) {
			this.actors = actors;
		}

		public Category getCategory() {
			return category;
		}

		public void setCategory(Category category) {
			this.category = category;
		}
		
		
		//toString()
		@Override
		public String toString() {
			return "Film [film_Id=" + film_Id + ", descreption=" + descreption + ", film_Title=" + film_Title
					+ ", release_Year=" + release_Year + ", languages=" + languages + ", original_Language="
					+ original_Language + ", rental_Duration=" + rental_Duration + ", length=" + length
					+ ", replacement_Cost=" + replacement_Cost + ", ratings=" + ratings + ", special_Features="
					+ special_Features + ", actors=" + actors + ", category=" + category + "]";
		}

		
			
		

}
