package com.flp.fms.service;

import java.util.List;
import java.util.Set;

import com.flp.fms.domain.*;

public interface IActorService {

	public List<Actor> getActor();
}
