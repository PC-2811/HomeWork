package com.flp.fms.service;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.flp.fms.dao.FilmDaoImplForList;
import com.flp.fms.dao.IFilmDao;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;

public class FilmServiceImpl implements IFilmService{
	
	private IFilmDao filmDao=new FilmDaoImplForList();

	@Override
	public List<Language> getLanguages() {
		
		return filmDao.getLanguages();
	}

	@Override
	public List<Category> getCategory() {
		
		return filmDao.getCategory();
	}
	
	
	
	@Override
	public void addFilm(Film film) {
		
		//film.setFilm_Id();
		filmDao.addFilm(film);
		
	}
	
	
	
	
	/*
    public int generate_Film_Id(){
		
		int filmId=0;
		
		//Verify filmId has been Duplicated or not
		do{
			double fid=Math.random()*1000;
			filmId=(int)fid;
		}while(checkDuplicateFilmId(filmId));
		
		
		return filmId;
	}*/

	@Override
	public List<Film> getAllFilms() {
		
		return filmDao.getAllFilms();
	}

	@Override
	public boolean deleteFilmDetailByRatings(int ratings){
		// TODO Auto-generated method stub
		return filmDao.deleteFilmDetailByRatings(ratings);
	}

	@Override
	public boolean deleteFilmDetailsByTitle(String title) {
		// TODO Auto-generated method stub
		return filmDao.deleteFilmDetailsByTitle(title);
	}

	@Override
	public boolean deleteFilmDetailsByReleaseYear(Date releaseYear) {
		// TODO Auto-generated method stub
		return filmDao.deleteFilmDetailsByReleaseYear(releaseYear);
	}

	@Override
	public List<Film> searchFilmDetailsById(Film film,int filmid) {
		// TODO Auto-generated method stub
		return filmDao.searchFilmDetailsById(film,filmid);
	}

	@Override
	public List<Film> searchFilmDetailsByTitle(Film film,String title) {
		// TODO Auto-generated method stub
		return filmDao.searchFilmDetailsByTitle(film,title);
	}

	@Override
	public List<Film> searchFilmDetailsByActor(Film film,String actor) {
		// TODO Auto-generated method stub
		return filmDao.searchFilmDetailsByActor(film,actor);
	}

	@Override
	public List<Film> searchFilmDetailsByCategory(Film film,int category) {
		// TODO Auto-generated method stub
		return filmDao.searchFilmDetailsByCategory(film,category);
	}

	@Override
	public List<Film> searchFilmDetailsByLanguage(Film film,String language) {
		// TODO Auto-generated method stub
		return filmDao.searchFilmDetailsByLanguage(film,language);
	}

	@Override
	public List<Film> searchFilmDetailsByRatings(Film film,int ratings) {
		// TODO Auto-generated method stub
		return filmDao.searchFilmDetailsByRatings(film,ratings);
	}

	@Override
	public int modifyFilmDetailsById(Film film, int filmid) {
		// TODO Auto-generated method stub
		return filmDao.modifyFilmDetailsById(film, filmid);
	}
/*
	@Override
	public List<Film> modifyFilmDetailsByTitle(Film film, String title) {
		// TODO Auto-generated method stub
		return filmDao.modifyFilmDetailsByTitle(film, title);
	}

	@Override
	public List<Film> modifyFilmDetailsByReleaseYear(Film film, Date releaseYear) {
		// TODO Auto-generated method stub
		return filmDao.modifyFilmDetailsByReleaseYear(film, releaseYear);
	}
	
	*/
	


	
}
