package com.flp.fms.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;



public class FilmDaoImplForList implements IFilmDao{

	
	private Map<Integer, Film> film_Repository=new HashMap<>();
	
public Connection getConnection(){
		
		Connection connection=null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection=(Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/phase2","root","Pass1234");
			
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return connection;
	}


	
	@Override
	public List<Language> getLanguages() {
		
		Connection con=getConnection();
		List<Language> languageList=new ArrayList<>();
		String sql="select * from LANGUAGE";

		try {
			PreparedStatement pst=(PreparedStatement) con.prepareStatement(sql);
			ResultSet rs=pst.executeQuery();
					
			while(rs.next()){
				
				Language languages=new Language();
				languages.setLanguage_Id(rs.getInt(1));
				languages.setLanguage_Name(rs.getString(2));
				
				languageList.add(languages);
							
			}
						
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return languageList;
		
		
		}
	
	
	
	public List<Category> getCategory(){
		
		List<Category> categoryList=new ArrayList<>();
		Connection con=getConnection();
		String sql="select * from category";

		try {
			PreparedStatement pst=(PreparedStatement) con.prepareStatement(sql);
			ResultSet rs=pst.executeQuery();
					
			while(rs.next()){
				Category category=new Category();
				category.setCategory_Id(rs.getInt(1));
				category.setCategory_Name(rs.getString(2));
				
							
				categoryList.add(category);
							
			}
						
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return categoryList;
		
		
		
	}



	//CURD Operation
		@Override
		public void addFilm(Film film) {
			
			Connection con=getConnection();
			film_Repository.put(film.getFilm_Id(), film);
			
			String sql="insert into film(title,description,releaseYear,originalLanguage,rentalDuration,length,replacementCost,ratings,specialFeatures,category)"
					+ "	 values(?,?,?,?,?,?,?,?,?,?)";

try {
PreparedStatement pst=(PreparedStatement) con.prepareStatement(sql);
pst.setString(1, film.getFilm_Title());
pst.setString(2, film.getDescreption());
pst.setDate(3, new Date(film.getRelease_Year().getTime()));
pst.setObject(4, film.getOriginal_Language().getLanguage_Id());
pst.setDate(5, new Date(film.getRental_Duration().getTime()));
pst.setInt(6, film.getLength());
pst.setDouble(7, film.getReplacement_Cost());
pst.setInt(8, film.getRatings());
pst.setString(9, film.getSpecial_Features());
pst.setObject(10, film.getCategory().getCategory_Id());


int count=pst.executeUpdate();


} catch (SQLException e) {
// TODO Auto-generated catch block
e.printStackTrace();
}


String sql1="select * from film order by filmid desc limit 1";

//Films film1=new Films();
int fid=0;
try {
PreparedStatement pst=(PreparedStatement) con.prepareStatement(sql1);
ResultSet rs=pst.executeQuery();


while(rs.next()){
fid=rs.getInt(1);

}		


} catch (SQLException e) {
// TODO Auto-generated catch block
e.printStackTrace();
}


String sql2="insert into film_actors(film_id,actor_id)" + "values(?,?)";

try {

PreparedStatement pst=(PreparedStatement) con.prepareStatement(sql2);
List<Actor> act=film.getActors();


for(Actor act1:act)
{
pst.setInt(1, fid);
pst.setObject(2, act1.getActor_Id());

int count=pst.executeUpdate();
}


} catch (SQLException e) {
// TODO Auto-generated catch block
e.printStackTrace();
}


String sql3="insert into film_language(film_id,language_id)" + "values(?,?)";

try {

PreparedStatement pst=(PreparedStatement) con.prepareStatement(sql3);
List<Language> lanlist=film.getLanguages();

for(Language lan1:lanlist){
pst.setInt(1, fid);
pst.setObject(2, lan1.getLanguage_Id());

int count=pst.executeUpdate();
}

} catch (SQLException e) {
// TODO Auto-generated catch block
e.printStackTrace();
}


			
						
			
		}

//List all film details
		@Override
		public List<Film> getAllFilms() {
			
			Connection con=getConnection();
			//film_Repository.put(film.getFilm_Id(), film);
			List<Film> filmList1=new ArrayList<>();
			String sql="select film.filmid,film.title,film.description,film.releaseYear,language.language_name,film.rentalDuration,film.length,film.replacementCost,film.ratings,film.specialFeatures,category.category_name from film join category on(film.category=category.category_id) join language on(film.originalLanguage=language.language_Id)";
			
			
			try {
				PreparedStatement pst=con.prepareStatement(sql);
				
				ResultSet rs=pst.executeQuery();
				
				while(rs.next())
				{
					Film film=new Film();
					film.setFilm_Id(rs.getInt(1));
					film.setFilm_Title(rs.getString(2));
					film.setDescreption(rs.getString(3));
					film.setRelease_Year(rs.getDate(4).valueOf(rs.getDate(4).toString()));
					
					Language lang=new Language();
					lang.setLanguage_Name(rs.getString(5));
					//lang.setLanguage_Id(rs.getInt(5));
					film.setOriginal_Language(lang);
					
					film.setRental_Duration(rs.getDate(6).valueOf(rs.getDate(6).toString()));
					film.setLength(rs.getInt(7));
					film.setReplacement_Cost(rs.getDouble(8));
					film.setRatings(rs.getInt(9));
					film.setSpecial_Features(rs.getString(10));
					
					Category category=new Category();
					category.setCategory_Name(rs.getString(11));
					film.setCategory(category);
					
					//get multiple languages
					List<Language> languages=getLanguage(rs.getInt(1));
					film.setLanguages(languages);
					
					//get multiple actors
					List<Actor> actors=getActors(rs.getInt(1));
					film.setActors(actors);
					
					filmList1.add(film);
					//System.out.println(film);
					
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			for(Film film1:filmList1)
			System.out.println(film1);
			return filmList1;
		}
		
		//get multiple languages
		public List<Language> getLanguage(int filmId)
		{
			List<Language> languages=new ArrayList<>();
			int filmid=filmId;
			String sql="select language.language_Id,language.language_name from language where language_Id in(select language_id from film_language where film_id=" + filmid +")";

			
			Connection con=getConnection();
			try {
				PreparedStatement pst=con.prepareStatement(sql);
				ResultSet rs=pst.executeQuery();
				while(rs.next())
				{
					Language lang=new Language();
					lang.setLanguage_Id(rs.getInt(1));
					lang.setLanguage_Name(rs.getString(2));
					languages.add(lang);
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return languages;
			
		}
		
		
		
		//get multiple actors
		
		public List<Actor> getActors(int filmId)
		{
			List<Actor> actors=new ArrayList<>();
			int filmid=filmId;
			String sql="select actors.actor_id,actors.firstName,actors.lastName from actors where actor_id in(select actor_id from film_actors where film_id=" + filmid +")";

			
			Connection con=getConnection();
			try {
				PreparedStatement pst=con.prepareStatement(sql);
				ResultSet rs=pst.executeQuery();
				while(rs.next())
				{
					Actor actor=new Actor();
					actor.setActor_Id(rs.getInt(1));
					actor.setFirstName(rs.getString(2));
					actor.setLastName(rs.getString(3));
					
					actors.add(actor);
					
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return actors;
			
		}
		
		//delete film details by ratings
		
		@Override
		public boolean deleteFilmDetailByRatings(int ratings) {
			
			
			boolean flag=false;
			String sql="delete from film where ratings=?";
			
			
			   	 try {
						PreparedStatement pst= getConnection().prepareStatement(sql);
					
					pst.setInt(1,ratings);
					 
					 
					 int count=pst.executeUpdate();
					 

						if(count>0)
							flag=true;
						
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			
			return flag;
		}

		//delete film details by Title
		
				@Override
				public boolean deleteFilmDetailsByTitle(String title) {
					
					
					boolean flag=false;
					String sql="delete from film where title=?";
					
					
					   	 try {
								PreparedStatement pst= getConnection().prepareStatement(sql);
							
							pst.setString(1,title);
							 
							 
							 int count=pst.executeUpdate();
							 

								if(count>0)
									flag=true;
								
							} catch (SQLException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
					
					return flag;
				}
				
				
				
				//delete film by Release Year

				@Override
				public boolean deleteFilmDetailsByReleaseYear(java.util.Date releaseYear) {
					boolean flag=false;
					String sql="delete from film where releaseYear=?";
					
					
					   	 try {
								PreparedStatement pst= getConnection().prepareStatement(sql);
							
							pst.setDate(1,new Date(releaseYear.getTime()));
							 
							 
							 int count=pst.executeUpdate();
							 

								if(count>0)
									flag=true;
								
							} catch (SQLException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
					
					return flag;
				}

				
				
				//search film by FilmId
				@Override
				public List<Film> searchFilmDetailsById(Film film,int filmid) {
					Connection con=getConnection();
					int count=0;
					String sql="select * from film where";
					ArrayList<Film> films=new ArrayList<Film>();
				
					if(film!=null)
					{
						if(film.getFilm_Id()>0)
						{
							
							sql+=" filmid="+film.getFilm_Id();
							
							count=1;
						}
						
					
						try {
							PreparedStatement pst=con.prepareStatement(sql);
							ResultSet rs=pst.executeQuery();
						
							while(rs.next())
							{
								Film film1=new Film();
								film1.setFilm_Id(rs.getInt(1));
								film1.setFilm_Title(rs.getString(2));
								film1.setDescreption(rs.getString(3));
								film1.setRelease_Year(rs.getDate(4));
								
								
								
								
								
								String subsql;
								subsql="select language_name from language where language_Id="+rs.getInt(5);
								PreparedStatement pst1=con.prepareStatement(subsql);
								ResultSet rs3=pst1.executeQuery();
								Language lang=new Language();
								if(rs3.next())
								{
									lang.setLanguage_Id(rs.getInt(5));
									lang.setLanguage_Name(rs3.getString(1));
								}
								film1.setOriginal_Language(lang);
								film1.setRental_Duration(rs.getDate(6));
								film1.setLength(rs.getInt(7));
								film1.setReplacement_Cost(rs.getInt(8));
								film1.setRatings(rs.getInt(9));
								film1.setSpecial_Features(rs.getString(10));
								
								subsql="select category_name from category where category_id="+rs.getInt(11);
								PreparedStatement pst3=con.prepareStatement(subsql);
							    rs3=pst3.executeQuery();
								if(rs3.next())
								{
									Category cat=new Category();
									cat.setCategory_Id(rs.getInt(11));
									cat.setCategory_Name(rs3.getString(1));
									film1.setCategory(cat);
								}
								
								subsql="select language_id from film_language where film_id="+rs.getInt(1);
								//System.out.println(rs.getInt(1));
								pst3=con.prepareStatement(subsql);
							    rs3=pst3.executeQuery();
							    List<Language> languages=new ArrayList<>();
								while(rs3.next())
								{
															
									String subsql1="select language_name from language where language_Id="+rs3.getInt(1);
									PreparedStatement pst2=con.prepareStatement(subsql1);
									ResultSet rs1=pst2.executeQuery();
									while(rs1.next()){
										Language langs=new Language();
										langs.setLanguage_Id(rs3.getInt(1));
										langs.setLanguage_Name(rs1.getString(1));
										languages.add(langs);
										
									}
								}
								film1.setLanguages(languages);
								subsql="select actor_id from film_actors where film_id="+rs.getInt(1);
							
								pst3=con.prepareStatement(subsql);
							    rs3=pst3.executeQuery();
							    List<Actor> actors=new ArrayList<>();
								while(rs3.next())
								{
									String subsql1="select firstName,lastName from actors where actor_id="+rs3.getInt(1);
									PreparedStatement pst2=con.prepareStatement(subsql1);
									ResultSet rs1=pst2.executeQuery();
									while(rs1.next()){
										Actor actr=new Actor();
										actr.setFirstName(rs1.getString(1));
										actr.setLastName(rs1.getString(2));
										actr.setActor_Id(rs3.getInt(1));
										actors.add(actr);
										
									}
								}
								film1.setActors(actors);
								film1.setLanguages(languages);
								//System.out.println(film1);
								films.add(film1);
								
								
						} }catch (SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					
						
					}
					
				
					return films;
				}

				//search film by title
				@Override
				public List<Film> searchFilmDetailsByTitle(Film film,String title) {
					Connection con=getConnection();
					int count=0;
					String sql="select * from film where";
					ArrayList<Film> films=new ArrayList<Film>();
				
					if(film!=null)
					{
						if(film.getFilm_Title()!=null)
						{
							
								sql+=" title='"+film.getFilm_Title()+"'";
							
						
							//count=1;
						}
					}
					
					try {
						PreparedStatement pst=con.prepareStatement(sql);
						ResultSet rs=pst.executeQuery();
					
						while(rs.next())
						{
							Film film1=new Film();
							film1.setFilm_Id(rs.getInt(1));
							film1.setFilm_Title(rs.getString(2));
							film1.setDescreption(rs.getString(3));
							film1.setRelease_Year(rs.getDate(4));
							
							
							
							String subsql;
							subsql="select language_name from language where language_Id="+rs.getInt(5);
							PreparedStatement pst1=con.prepareStatement(subsql);
							ResultSet rs3=pst1.executeQuery();
							Language lang=new Language();
							if(rs3.next())
							{
								lang.setLanguage_Id(rs.getInt(5));
								lang.setLanguage_Name(rs3.getString(1));
							}
							film1.setOriginal_Language(lang);
							film1.setRental_Duration(rs.getDate(6));
							film1.setLength(rs.getInt(7));
							film1.setReplacement_Cost(rs.getInt(8));
							film1.setRatings(rs.getInt(9));
							film1.setSpecial_Features(rs.getString(10));
							
							subsql="select category_name from category where category_id="+rs.getInt(11);
							PreparedStatement pst3=con.prepareStatement(subsql);
						    rs3=pst3.executeQuery();
							if(rs3.next())
							{
								Category cat=new Category();
								cat.setCategory_Id(rs.getInt(11));
								cat.setCategory_Name(rs3.getString(1));
								film1.setCategory(cat);
							}
							
							subsql="select language_id from film_language where film_id="+rs.getInt(1);
							//System.out.println(rs.getInt(1));
							pst3=con.prepareStatement(subsql);
						    rs3=pst3.executeQuery();
						    List<Language> languages=new ArrayList<>();
							while(rs3.next())
							{
														
								String subsql1="select language_name from language where language_Id="+rs3.getInt(1);
								PreparedStatement pst2=con.prepareStatement(subsql1);
								ResultSet rs1=pst2.executeQuery();
								while(rs1.next()){
									Language langs=new Language();
									langs.setLanguage_Id(rs3.getInt(1));
									langs.setLanguage_Name(rs1.getString(1));
									languages.add(langs);
									
								}
							}
							film1.setLanguages(languages);
							subsql="select actor_id from film_actors where film_id="+rs.getInt(1);
						
							pst3=con.prepareStatement(subsql);
						    rs3=pst3.executeQuery();
						    List<Actor> actors=new ArrayList<>();
							while(rs3.next())
							{
								String subsql1="select firstName,lastName from actors where actor_id="+rs3.getInt(1);
								PreparedStatement pst2=con.prepareStatement(subsql1);
								ResultSet rs1=pst2.executeQuery();
								while(rs1.next()){
									Actor actr=new Actor();
									actr.setFirstName(rs1.getString(1));
									actr.setLastName(rs1.getString(2));
									actr.setActor_Id(rs3.getInt(1));
									actors.add(actr);
									
								}
							}
							film1.setActors(actors);
							film1.setLanguages(languages);
							//System.out.println("HI" + film1);
							films.add(film1);
					} }catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				
					 
				
				return films;
				}

			//Search film by Actor	
				@Override
				public List<Film> searchFilmDetailsByActor(Film film,String actor) {
					Connection con=getConnection();
					int count=0;
					String sql="select * from film where";
					ArrayList<Film> films=new ArrayList<Film>();
				
					if(film!=null)
					{
						if(film.getActors()!=null)
						{
							Actor actor1=new Actor();
							List<Actor> actors=film.getActors();
							for(Actor a:actors)
								actor1=a;
								sql+=" filmid In(Select film_id from film_actors where actor_id="+actor1.getActor_Id()+")";    
					      }
						}
					
					try {
						PreparedStatement pst=con.prepareStatement(sql);
						ResultSet rs=pst.executeQuery();
					
						while(rs.next())
						{
							Film film1=new Film();
							film1.setFilm_Id(rs.getInt(1));
							film1.setFilm_Title(rs.getString(2));
							film1.setDescreption(rs.getString(3));
							film1.setRelease_Year(rs.getDate(4));
							
							
							
							String subsql;
							subsql="select language_name from language where language_Id="+rs.getInt(5);
							PreparedStatement pst1=con.prepareStatement(subsql);
							ResultSet rs3=pst1.executeQuery();
							Language lang=new Language();
							if(rs3.next())
							{
								lang.setLanguage_Id(rs.getInt(5));
								lang.setLanguage_Name(rs3.getString(1));
							}
							film1.setOriginal_Language(lang);
							film1.setRental_Duration(rs.getDate(6));
							film1.setLength(rs.getInt(7));
							film1.setReplacement_Cost(rs.getInt(8));
							film1.setRatings(rs.getInt(9));
							film1.setSpecial_Features(rs.getString(10));
							
							subsql="select category_name from category where category_id="+rs.getInt(11);
							PreparedStatement pst3=con.prepareStatement(subsql);
						    rs3=pst3.executeQuery();
							if(rs3.next())
							{
								Category cat=new Category();
								cat.setCategory_Id(rs.getInt(11));
								cat.setCategory_Name(rs3.getString(1));
								film1.setCategory(cat);
							}
							
							subsql="select language_id from film_language where film_id="+rs.getInt(1);
							//System.out.println(rs.getInt(1));
							pst3=con.prepareStatement(subsql);
						    rs3=pst3.executeQuery();
						    List<Language> languages=new ArrayList<>();
							while(rs3.next())
							{
														
								String subsql1="select language_name from language where language_Id="+rs3.getInt(1);
								PreparedStatement pst2=con.prepareStatement(subsql1);
								ResultSet rs1=pst2.executeQuery();
								while(rs1.next()){
									Language langs=new Language();
									langs.setLanguage_Id(rs3.getInt(1));
									langs.setLanguage_Name(rs1.getString(1));
									languages.add(langs);
									
								}
							}
							film1.setLanguages(languages);
							subsql="select actor_id from film_actors where film_id="+rs.getInt(1);
						
							pst3=con.prepareStatement(subsql);
						    rs3=pst3.executeQuery();
						    List<Actor> actors=new ArrayList<>();
							while(rs3.next())
							{
								String subsql1="select firstName,lastName from actors where actor_id="+rs3.getInt(1);
								PreparedStatement pst2=con.prepareStatement(subsql1);
								ResultSet rs1=pst2.executeQuery();
								while(rs1.next()){
									Actor actr=new Actor();
									actr.setFirstName(rs1.getString(1));
									actr.setLastName(rs1.getString(2));
									actr.setActor_Id(rs3.getInt(1));
									actors.add(actr);
									
								}
							}
							film1.setActors(actors);
							film1.setLanguages(languages);
							//System.out.println(film1);
							films.add(film1);
					} }catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				
					
					
				return films;
				}

		//search film by Language		
				@Override
				public List<Film> searchFilmDetailsByLanguage(Film film,String language) {
					Connection con=getConnection();
					int count=0;
					String sql="select * from film where";
					ArrayList<Film> films=new ArrayList<Film>();
				
					if(film!=null)
					{
						if(film.getLanguages()!=null)
						{
						Language lang=new Language();
						
						List<Language> langs=film.getLanguages();
					
						for(Language l:langs)
							lang=l;
					
							sql+="  filmid In(Select film_id from film_language where language_id="+lang.getLanguage_Id()+") or filmid In( Select filmid from film where originalLanguage="+lang.getLanguage_Id()+"))";
						
					}
					}
					
					try {
						PreparedStatement pst=con.prepareStatement(sql);
						ResultSet rs=pst.executeQuery();
					
						while(rs.next())
						{
							Film film1=new Film();
							film1.setFilm_Id(rs.getInt(1));
							film1.setFilm_Title(rs.getString(2));
							film1.setDescreption(rs.getString(3));
							film1.setRelease_Year(rs.getDate(4));
							
							
							
							String subsql;
							subsql="select language_name from language where language_Id="+rs.getInt(5);
							PreparedStatement pst1=con.prepareStatement(subsql);
							ResultSet rs3=pst1.executeQuery();
							Language lang=new Language();
							if(rs3.next())
							{
								lang.setLanguage_Id(rs.getInt(5));
								lang.setLanguage_Name(rs3.getString(1));
							}
							film1.setOriginal_Language(lang);
							film1.setRental_Duration(rs.getDate(6));
							film1.setLength(rs.getInt(7));
							film1.setReplacement_Cost(rs.getInt(8));
							film1.setRatings(rs.getInt(9));
							film1.setSpecial_Features(rs.getString(10));
							
							subsql="select category_name from category where category_id="+rs.getInt(11);
							PreparedStatement pst3=con.prepareStatement(subsql);
						    rs3=pst3.executeQuery();
							if(rs3.next())
							{
								Category cat=new Category();
								cat.setCategory_Id(rs.getInt(11));
								cat.setCategory_Name(rs3.getString(1));
								film1.setCategory(cat);
							}
							
							subsql="select language_id from film_language where film_id="+rs.getInt(1);
							//System.out.println(rs.getInt(1));
							pst3=con.prepareStatement(subsql);
						    rs3=pst3.executeQuery();
						    List<Language> languages=new ArrayList<>();
							while(rs3.next())
							{
														
								String subsql1="select language_name from language where language_Id="+rs3.getInt(1);
								PreparedStatement pst2=con.prepareStatement(subsql1);
								ResultSet rs1=pst2.executeQuery();
								while(rs1.next()){
									Language langs=new Language();
									langs.setLanguage_Id(rs3.getInt(1));
									langs.setLanguage_Name(rs1.getString(1));
									languages.add(langs);
									
								}
							}
							film1.setLanguages(languages);
							subsql="select actor_id from film_actors where film_id="+rs.getInt(1);
						
							pst3=con.prepareStatement(subsql);
						    rs3=pst3.executeQuery();
						    List<Actor> actors=new ArrayList<>();
							while(rs3.next())
							{
								String subsql1="select firstName,lastName from actors where actor_id="+rs3.getInt(1);
								PreparedStatement pst2=con.prepareStatement(subsql1);
								ResultSet rs1=pst2.executeQuery();
								while(rs1.next()){
									Actor actr=new Actor();
									actr.setFirstName(rs1.getString(1));
									actr.setLastName(rs1.getString(2));
									actr.setActor_Id(rs3.getInt(1));
									actors.add(actr);
									
								}
							}
							film1.setActors(actors);
							film1.setLanguages(languages);
							//System.out.println(film1);
							films.add(film1);
					} }catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				
					
					
				return films;
				}

				//search film details by ratings 
				@Override
				public List<Film> searchFilmDetailsByRatings(Film film,int ratings) {
					Connection con=getConnection();
					int count=0;
					String sql="select * from film where";
					ArrayList<Film> films=new ArrayList<Film>();
				
					if(film!=null)
					{
						if(film.getRatings()>0)
						{
						
					
							sql+=" ratings="+film.getRatings();
						
					}
					}
					
					try {
						PreparedStatement pst=con.prepareStatement(sql);
						ResultSet rs=pst.executeQuery();
					
						while(rs.next())
						{
							Film film1=new Film();
							film1.setFilm_Id(rs.getInt(1));
							film1.setFilm_Title(rs.getString(2));
							film1.setDescreption(rs.getString(3));
							film1.setRelease_Year(rs.getDate(4));
							
							
							
							String subsql;
							subsql="select language_name from language where language_Id="+rs.getInt(5);
							PreparedStatement pst1=con.prepareStatement(subsql);
							ResultSet rs3=pst1.executeQuery();
							Language lang=new Language();
							if(rs3.next())
							{
								lang.setLanguage_Id(rs.getInt(5));
								lang.setLanguage_Name(rs3.getString(1));
							}
							film1.setOriginal_Language(lang);
							film1.setRental_Duration(rs.getDate(6));
							film1.setLength(rs.getInt(7));
							film1.setReplacement_Cost(rs.getInt(8));
							film1.setRatings(rs.getInt(9));
							film1.setSpecial_Features(rs.getString(10));
							
							subsql="select category_name from category where category_id="+rs.getInt(11);
							PreparedStatement pst3=con.prepareStatement(subsql);
						    rs3=pst3.executeQuery();
							if(rs3.next())
							{
								Category cat=new Category();
								cat.setCategory_Id(rs.getInt(11));
								cat.setCategory_Name(rs3.getString(1));
								film1.setCategory(cat);
							}
							
							subsql="select language_id from film_language where film_id="+rs.getInt(1);
							//System.out.println(rs.getInt(1));
							pst3=con.prepareStatement(subsql);
						    rs3=pst3.executeQuery();
						    List<Language> languages=new ArrayList<>();
							while(rs3.next())
							{
														
								String subsql1="select language_name from language where language_Id="+rs3.getInt(1);
								PreparedStatement pst2=con.prepareStatement(subsql1);
								ResultSet rs1=pst2.executeQuery();
								while(rs1.next()){
									Language langs=new Language();
									langs.setLanguage_Id(rs3.getInt(1));
									langs.setLanguage_Name(rs1.getString(1));
									languages.add(langs);
									
								}
							}
							film1.setLanguages(languages);
							subsql="select actor_id from film_actors where film_id="+rs.getInt(1);
						
							pst3=con.prepareStatement(subsql);
						    rs3=pst3.executeQuery();
						    List<Actor> actors=new ArrayList<>();
							while(rs3.next())
							{
								String subsql1="select firstName,lastName from actors where actor_id="+rs3.getInt(1);
								PreparedStatement pst2=con.prepareStatement(subsql1);
								ResultSet rs1=pst2.executeQuery();
								while(rs1.next()){
									Actor actr=new Actor();
									actr.setFirstName(rs1.getString(1));
									actr.setLastName(rs1.getString(2));
									actr.setActor_Id(rs3.getInt(1));
									actors.add(actr);
									
								}
							}
							film1.setActors(actors);
							film1.setLanguages(languages);
							//System.out.println(film1);
							films.add(film1);
					} }catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				
					 
				return films;
				}

				
				//search film by category
				@Override
				public List<Film> searchFilmDetailsByCategory(Film film, int category) {
					Connection con=getConnection();
					int count=0;
					String sql="select * from film where";
					ArrayList<Film> films=new ArrayList<Film>();
				
					if(film!=null)
					{
						if(film.getCategory()!=null)
						{
						
							sql+=" category="+film.getCategory();
						}
					
					}
					
					try {
						PreparedStatement pst=con.prepareStatement(sql);
						ResultSet rs=pst.executeQuery();
					
						while(rs.next())
						{
							Film film1=new Film();
							film1.setFilm_Id(rs.getInt(1));
							film1.setFilm_Title(rs.getString(2));
							film1.setDescreption(rs.getString(3));
							film1.setRelease_Year(rs.getDate(4));
							
							
							
							String subsql;
							subsql="select language_name from language where language_Id="+rs.getInt(5);
							PreparedStatement pst1=con.prepareStatement(subsql);
							ResultSet rs3=pst1.executeQuery();
							Language lang=new Language();
							if(rs3.next())
							{
								lang.setLanguage_Id(rs.getInt(5));
								lang.setLanguage_Name(rs3.getString(1));
							}
							film1.setOriginal_Language(lang);
							film1.setRental_Duration(rs.getDate(6));
							film1.setLength(rs.getInt(7));
							film1.setReplacement_Cost(rs.getInt(8));
							film1.setRatings(rs.getInt(9));
							film1.setSpecial_Features(rs.getString(10));
							
							subsql="select category_name from category where category_id="+rs.getInt(11);
							PreparedStatement pst3=con.prepareStatement(subsql);
						    rs3=pst3.executeQuery();
							if(rs3.next())
							{
								Category cat=new Category();
								cat.setCategory_Id(rs.getInt(11));
								cat.setCategory_Name(rs3.getString(1));
								film1.setCategory(cat);
							}
							
							subsql="select language_id from film_language where film_id="+rs.getInt(1);
							//System.out.println(rs.getInt(1));
							pst3=con.prepareStatement(subsql);
						    rs3=pst3.executeQuery();
						    List<Language> languages=new ArrayList<>();
							while(rs3.next())
							{
														
								String subsql1="select language_name from language where language_Id="+rs3.getInt(1);
								PreparedStatement pst2=con.prepareStatement(subsql1);
								ResultSet rs1=pst2.executeQuery();
								while(rs1.next()){
									Language langs=new Language();
									langs.setLanguage_Id(rs3.getInt(1));
									langs.setLanguage_Name(rs1.getString(1));
									languages.add(langs);
									
								}
							}
							film1.setLanguages(languages);
							subsql="select actor_id from film_actors where film_id="+rs.getInt(1);
						
							pst3=con.prepareStatement(subsql);
						    rs3=pst3.executeQuery();
						    List<Actor> actors=new ArrayList<>();
							while(rs3.next())
							{
								String subsql1="select firstName,lastName from actors where actor_id="+rs3.getInt(1);
								PreparedStatement pst2=con.prepareStatement(subsql1);
								ResultSet rs1=pst2.executeQuery();
								while(rs1.next()){
									Actor actr=new Actor();
									actr.setFirstName(rs1.getString(1));
									actr.setLastName(rs1.getString(2));
									actr.setActor_Id(rs3.getInt(1));
									actors.add(actr);
									
								}
							}
							film1.setActors(actors);
							film1.setLanguages(languages);
							//System.out.println(film1);
							films.add(film1);
					} }catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				
					  
					
				return films;
				}

				
				
				//Modify film by ratings
				@Override
				public int modifyFilmDetailsById(Film film, int filmid) {
					//System.out.println(id+"dao");
					int  count=0;
					Connection con=getConnection();
					String sql="update film set title=?,description=?,releaseYear=?,originalLanguage=?,rentalDuration=?,length=?,replacementCost=?,ratings=?,specialFeatures=?,category=? where filmid="+filmid;
					String sql1="delete from film_language where film_id="+filmid;
					String sql4="delete from film_actors where film_id="+filmid;
					
					try {
						PreparedStatement pst=con.prepareStatement(sql);
						//pst.setString(1, film.getTitle());
						pst.setString(1, film.getFilm_Title());
						pst.setString(2, film.getDescreption());
						pst.setDate(3, new Date(film.getRelease_Year().getTime()));
						int language=film.getOriginal_Language().getLanguage_Id();
						pst.setInt(4, language);
						pst.setDate(5, new Date(film.getRental_Duration().getTime()));
						pst.setInt(6, film.getLength());
						pst.setDouble(7,film.getReplacement_Cost());
						
						pst.setInt(8,film.getRatings());
						pst.setString(9,film.getSpecial_Features());
						int category=film.getCategory().getCategory_Id();
						pst.setInt(10,category);
						//pst.setInt(11, filmid);
						
						count=pst.executeUpdate();
						
						
						//delete from film_language
						PreparedStatement pst1=con.prepareStatement(sql1);
						//pst1.setInt(1, filmid);
					    count=pst1.executeUpdate();
					    
					  //delete from film_actors
						PreparedStatement pst4=con.prepareStatement(sql4);
						//pst4.setInt(1, filmid);
					    count=pst4.executeUpdate();
					    
					    //insert into film_language
					  //insert into film_languages
						String sql2="insert into film_language values(?,?)";
						PreparedStatement pst2=con.prepareStatement(sql2);
					     List<Language> lang=film.getLanguages();
					     //System.out.println(lang);
						for(Language lang1:lang){
						pst2.setInt(1, filmid);
						pst2.setInt(2,lang1.getLanguage_Id());
					    count=pst2.executeUpdate();
						}
					    
						String sql3="insert into film_actors values(?,?)";
						PreparedStatement pst3=con.prepareStatement(sql3);
					    List<Actor> actor=film.getActors();
						for(Actor act1:actor){
						pst3.setInt(1, filmid);
						pst3.setInt(2,act1.getActor_Id());
						 count=pst3.executeUpdate();
						}
						
						
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}




					return count;
				}

			/*	@Override
				public List<Film> modifyFilmDetailsByTitle(Film film, String title) {
					// TODO Auto-generated method stub
					return null;
				}

				@Override
				public List<Film> modifyFilmDetailsByReleaseYear(Film film, java.util.Date releaseYear) {
					// TODO Auto-generated method stub
					return null;
				}
	*/
}
