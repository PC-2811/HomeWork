package com.flp.fms.view;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import com.flp.fms.domain.Film;
import com.flp.fms.service.ActorServiceImpl;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IActorService;
import com.flp.fms.service.IFilmService;

public class BootClass {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int option;
		String choice;
		UserInteraction userInteraction=new UserInteraction();
		IFilmService filmService=new FilmServiceImpl();
		IActorService actorService=new ActorServiceImpl();
		
		do{
		menuSelection();
		System.out.println("Enter your option:[1-6]");
		option=sc.nextInt();
		switch(option){
			case 1://Add Film
				
				Film film=userInteraction.addFilm(filmService.getLanguages(),filmService.getCategory(),actorService.getActor());
				actorService.getActor();
				filmService.addFilm(film);
				//System.out.println(film);
				
				break;
				//modify film
			case 2: 
				do{
				          //modifyMenuSelection();
						//int choicem;
						//choicem=sc.nextInt();
						List<Film> filmList2=filmService.getAllFilms();
						//Collection<Film> lst2=filmList2.values();
						  userInteraction.modifyFilm(filmList2);
						//filmService.d;
						//Film newFilm=userInteraction.addFilm(filmService.getLanguages(),filmService.getcategory(),actorService.getActors());
						//filmService.addFilm(newFilm);
						System.out.println("Do you want to modify again(y/n)");
						choice=sc.next();
					}while(choice.charAt(0)=='y'||choice.charAt(0)=='Y');
					break;
			case 3://Delete Film
					do{
						deleteMenuSelection();
						int choice2;
						choice2=sc.nextInt();
						List filmList2=filmService.getAllFilms();
						//Collection<Film> lst2=filmList2.values();
						Film f=userInteraction.removeFilm(filmList2,choice2);
						//filmService.removeFilm(f);
						System.out.println("Do you want to delete again(y/n)");
						choice=sc.next();
					}while(choice.charAt(0)=='y'||choice.charAt(0)=='Y');
						break;
						
			case 4://search film
				    
				do{
			        searchtMenuSelection();
					int choice2;
					choice2=sc.nextInt();
					List<Film> filmList1=filmService.getAllFilms();
					//Collection<Film> lst1=filmList1.values();
					userInteraction.SearchFilm(filmList1,choice2);
					System.out.println("Do you want to search again(y/n)");
					choice=sc.next();
					}while(choice.charAt(0)=='y'||choice.charAt(0)=='Y');
					break;
		
			case 5:
				  //Get all film details
				List<Film>  film_lst= filmService.getAllFilms();
			  
				userInteraction.getAllFilm(film_lst);
				
				break;
			case 6:
				System.exit(0);
		}
		System.out.println("Wish to do more Operation?[y|n]");
		choice=sc.next();
		}while(choice.charAt(0)=='y'||choice.charAt(0)=='Y');
		
		}

	
	
	public static void menuSelection(){
		System.out.println("1.Add Film");
		System.out.println("2.Modify Film");
		System.out.println("3.Remove Film");
		System.out.println("4.Search Film");
		System.out.println("5.GetAll Film");
		System.out.println("6.Exit");
		
	}
	
	public static void searchtMenuSelection(){
		System.out.println("1.Search by ID");
		System.out.println("2.Search by Title");
		System.out.println("3.Search by Actor");
		System.out.println("4.Search by Category");
		System.out.println("5.Search by Language");
		System.out.println("6.Search by Ratings");
		System.out.println("7.Exit");
		
	}
	
	
	public static void deleteMenuSelection(){
		
		System.out.println("1.Delete by Rating");
		System.out.println("2.Delete by Title");
		System.out.println("3.Delete Release Year");
		System.out.println("4.Exit");
		
	}
	
	/*public static void modifyMenuSelection(){
		System.out.println("1.Modify Film by Ratings");
		System.out.println("2.Modify Film by Title");
		System.out.println("3.Modify Film by ReleaseDate");
		
	}*/

}
