package com.flp.fms.view;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.ActorServiceImpl;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IActorService;
import com.flp.fms.service.IFilmService;
import com.flp.fms.util.Validate;

public class UserInteraction {
	IFilmService filmService=new FilmServiceImpl();
	IActorService actorService=new ActorServiceImpl();
	Scanner sc=new Scanner(System.in);
	
	
	//Return fully qualified film object
		public Film addFilm(List<Language> languages,List<Category> category1,List<Actor> actor){
	
		
		Film film=new Film();
		boolean flag=true;
		
	//Get Title and validate it
		String title=null;
		do{
		System.out.println("Enter Film Title");
		
		title=sc.nextLine();
		
		flag=Validate.isValidTitle(title);
			if(!flag)
				System.out.println("Invalid Title. Please Enter Valid Title!");
		}while(!flag);
		film.setFilm_Title(title);
		
		
	//Get Description and validate it	
		String description=null;
		do{
		System.out.println("Enter Film Description");
		description=sc.nextLine();
		flag=Validate.isValidDescription(description);
			if(!flag)
				System.out.println("Invalid Title. Please Enter Valid Title!");
		}while(!flag);
		film.setDescreption(description);
		
	//Release Date Validation
			String releaseDate;
			boolean date_flag=false;
			Date release_Date=null;
			do{
	            //Verify Date Format
				do{
					System.out.println("Enter Release Date:");
					releaseDate=sc.next();
					flag=Validate.isValidReleaseDate(releaseDate);
					if(!flag)
						System.out.println("Please enter date in this Format(dd-MMM-yyyy)!");
					}while(!flag);
	            //Verifies Release Date  
					Date today=new Date();
					release_Date=new Date(releaseDate);
					if(release_Date.before(today)|| release_Date.equals(today))
						date_flag=true;
				
					if(!date_flag)
						System.out.println("Invalid Date! Date should be current date or Past Date!");
				}while(!date_flag);
	  film.setRelease_Year(release_Date);
				
			
	//Choose original Language
		System.out.println("Choose Original Language");
		Language language= addLanguages(languages);
		film.setOriginal_Language(language);
		
		
   //Add List of Other languages
		List<Language> languages2=new ArrayList<>();
		String choice;
		boolean flag_langs;
		do{
			System.out.println("Choose All other Languages for the Film:");
			Language language1= addLanguages(languages);
			
			
			flag_langs=Validate.checkDuplicateLanguage(languages2, language1);
			if(!flag_langs)
				languages2.add(language1);
			else
				System.out.println("Language already Exists. Please try other languages!");
			
			
			System.out.println("Wish to add More Languages?[y|n]");
			choice=sc.next();
		}while(choice.charAt(0)=='y'||choice.charAt(0)=='Y');
		
		film.setLanguages(languages2);
			
		
	//Add Rental Duration Date for film
				
				String rentalDate;
				boolean date_flag1=false;
				Date rental_Date=null;
				do{					
					//Verify Date Format
					do{
						System.out.println("Enter Rental Date:");
						rentalDate=sc.next();
						flag=Validate.isValidReleaseDate(rentalDate);
						if(!flag)
							System.out.println("Please enter date in this Format(dd-MMM-yyyy)!");
					}while(!flag);
					
					//Verifies Rental Date  
					
					rental_Date=new Date(rentalDate);
					Date dt=film.getRelease_Year();
					if(dt.after(release_Date))
						date_flag=true;
				
					if(!date_flag)
						System.out.println("Invalid Date! Date should be greater than release date!");
				}while(!date_flag);
				film.setRental_Duration(rental_Date);
		
				
		//Add Length of film
				int length;
				do{
				System.out.println("Enter length of film");
				length=sc.nextInt();
				flag=Validate.isValidLength(length);
				if(!flag)
					System.out.println("Invalid Length. Please Enter Valid Length(0-1000)");
			    }while(!flag);
				film.setLength(length);
			
		//Add Replacement cost
				double reple_cost;
				do{
				System.out.println("Enter Replacement Cost of Film");
				reple_cost=sc.nextDouble();
				flag=Validate.isValidCost(reple_cost);
				if(!flag)
					System.out.println("Invalid cost. Please Enter Valid cost(eg. 12451.00)");
			    }while(!flag);
				film.setReplacement_Cost(reple_cost);
				
		//Add ratings for film
				int ratings;
				do{
				System.out.println("Enter rating for film");
				ratings=sc.nextInt();
				flag=Validate.isValidLength(ratings);
				if(!flag)
					System.out.println("Invalid rating. Please Enter Valid rating(1-5)");
			    }while(!flag);
				film.setRatings(ratings);
				
				
		//Get Special feature and validate it	
				String special_fea=null;
				do{
				System.out.println("Enter Special feature");
				special_fea=sc.next();
				//Same as description validation
				flag=Validate.isValidDescription(special_fea);
					if(!flag)
						System.out.println("Invalid Special feature. Please Enter alpha numeric value!");
				}while(!flag);
				film.setSpecial_Features(special_fea);
				
				
		//Add actor to the film
				List<Actor> actor2=new ArrayList<>();
				String choiceActor;
				boolean flag_actor;
				do{
					System.out.println("Choose Actor for the Film:");
					Actor actor1=addActor(actor);
					actor2.add(actor1);					
					
					System.out.println("Wish to add More Actor?[y|n]");
					choice=sc.next();
				}while(choice.charAt(0)=='y'||choice.charAt(0)=='Y');	
				film.setActors(actor2);
				
				
		//Choose Category for film
				System.out.println("Choose Category");
				Category category=addCategory(category1);
				film.setCategory(category);
				
							
			return film;
			
	}
		
		
		
//---------------------Methods-----------------------------------------------------------------------------		
	
	//Choose Valid Language Object from the list of Languages
		public Language addLanguages(List<Language>  languages){
			
			Language sel_language=null;
			boolean flag;
			do{	
				//Print Langauge Details
				for(Language language:languages)
					System.out.println(language.getLanguage_Id() + "\t" + language.getLanguage_Name());
				
				System.out.println("Choose the Language:");
				int option=sc.nextInt();
				
				flag=false;
				
				//Check the Language Object
				for(Language language: languages)
				{
					if(option==language.getLanguage_Id())
					{
						sel_language=language;
						flag=true;
						break;
					}
				}
				
				//Print Error Message
				if(!flag)
					System.out.println("Please select valid Language Id");
			}while(!flag);	
			
			return sel_language;
		}
		
		
		
   public Category addCategory(List<Category>  categorys){
			
			Category sel_category=null;
			boolean flag;
			do{	
				//Print Category Details
				for(Category cate:categorys)
					System.out.println(cate.getCategory_Id() + "\t" + cate.getCategory_Name());
				
				System.out.println("Choose the Category:");
				int option=sc.nextInt();
				
				flag=false;
				
				//Check the Category Object
				for(Category cate:categorys)
				{
					if(option==cate.getCategory_Id())
					{
						sel_category=cate;
						flag=true;
						break;
					}
				}
				
				//Print Error Message
				if(!flag)
					System.out.println("Please select valid CategoryId");
			}while(!flag);	
			
			return sel_category;
		}


     //Choose Valid Actor Object from the list of Actor
		public Actor addActor(List<Actor>  actor){
		
			Actor sel_actor=null;
			//boolean flag;
			//do{	
				//Print Category Details
				for(Actor act:actor)
					System.out.println(act.getActor_Id() + "\t" + act.getFirstName() + "\t" + act.getLastName());
				
				System.out.println("Choose the Actor:");
				int option=sc.nextInt();
				
				//flag=false;
				for(Actor cate:actor)
				{
					if(option==cate.getActor_Id())
					{
						sel_actor=cate;
						
						break;
					}
				}
					
			
			return sel_actor;
		}
		
		
	//get all film details	
		public void getAllFilm(List<Film> lst) {
			
			DateFormat df=new SimpleDateFormat("dd-MMM-yyyy");
			
			System.out.println("Id" + "\t" +"Title" + "\t\t" + "Description"  +"\t\t"+"Release Date" +"\t\t\t"+
					"Original language"+"\t\t"+"Other language" +"\t\t"+"Rental duration"+"\t\t\t"+"Length"+"\t\t"+"ReplacementCost"+"\t\t"+"Rating"+
					"\t\t"+"SpecialFeature"+"\t\t"+"Actor"+"\t\t\t"+"category");
			  
			
			for(Film film:lst){
				 
				//get original language
				String languages="";
				for(Language language:film.getLanguages())
					languages=languages+language.getLanguage_Name()+",";
				
				
		
						
			String actors="";
			for(Actor act:film.getActors())
				actors=actors+act.getFirstName()+" "+act.getLastName()+",";
				
				
				
				
	
				
	    System.out.println(film.getFilm_Id() + "\t" +
						film.getFilm_Title() + "\t\t"+
						film.getDescreption()+ "\t\t\t" +
						df.format(film.getRelease_Year())+"\t\t\t"+
						film.getOriginal_Language().getLanguage_Name()+"\t\t\t\t"+
						
						
                         languages+"\t\t\t"+
					   df.format(film.getRental_Duration())+"\t\t\t"+
						film.getLength() + "\t\t\t" +
						film.getReplacement_Cost() + "\t\t" +
						film.getRatings()+"\t\t" +
					    film.getSpecial_Features() + "\t\t\t" +
						actors + "\t\t" +
					   
						 film.getCategory().getCategory_Name());
	    
	    
	 
	        
				}
			
			
		}
			
			
			

			//Delete Film
			
			
			public Film removeFilm(Collection<Film> lst,int choice)
			{
				
				
				//boolean flag1=false;
				int flag=0;
				switch(choice)
				{
				case 1:
						System.out.println("Enter the Rating");
						int rate=sc.nextInt();
						for(Film film:lst)
						{
							if(film.getRatings()==rate)
							{
								flag=1;
								
								filmService.deleteFilmDetailByRatings(rate);
								//lst.remove(film);
								/*if(flag1==true)
								     System.out.println("deleted");*/
								return film;
							}
						}
						if(flag==0)
						{
							System.out.println("Film not found");
						}
						break;
				case 2:
					System.out.println("Enter Film Name");
					String title=sc.next();
					for(Film film1:lst)
					{
					if(film1.getFilm_Title().equals(title))
					{
						flag=1;
						filmService.deleteFilmDetailsByTitle(title);
						return film1;
					}
					}
				if(flag==0)
				{
					System.out.println("Film not found");
				}
				break;
				case 3:
					System.out.println("Enter Release Date");
					String date=sc.next();
					Date releaseYear=new Date(date);
					for(Film film1:lst)
					{
					if(film1.getRelease_Year().equals(releaseYear))
					{
						flag=1;
						filmService.deleteFilmDetailsByReleaseYear(releaseYear);
						return film1;
					}
					}
				if(flag==0)
				{
					System.out.println("Film not found");
				}
				break;
				}
				return null;
			}
			

			
			
			//search film details
			//Search Film
			
			
			public void SearchFilm(Collection<Film> lst,int choice) 
			{
				
				//DateFormat df=new SimpleDateFormat("dd-MMM-yyyy");
				int flag=0;
				int id=0;


					switch(choice)
					{
					case 1:	//search film by id	
						System.out.println("Enter the film id");
						 id=sc.nextInt();
						
						
                             for(Film film:lst)
                              { 
                            	 if(film!=null)
                            	 {
		                              List<Film> films=filmService.searchFilmDetailsById(film,id);
		                              flag=1;
		                              
		                              getAllFilm(films);
                               	 }
        						    if(flag==0)
        						       {
        							      System.out.println("Film not found");
        						       }
                              }
		                         
						break;
					case 2://search film by title
						
						System.out.println("Enter Film Name");
						String title=sc.next();
						
						 for(Film film1:lst)
                         { 
                       	 if(film1!=null)
                       	 {
	                          List<Film> films=filmService.searchFilmDetailsByTitle(film1, title);
	                          flag=1;
	                        
	                          getAllFilm(films);
	                        
	                          
                       	 }
						    if(flag==0)
						       {
							      System.out.println("Film not found");
						       }
                         }
						break;
					case 3://search film by actor
						System.out.println("Enter Actor");
						String actor=sc.next();
						
						for(Film film2:lst)
						{				
							 if(film2!=null)
	                       	 {
								 List<Film> films=filmService.searchFilmDetailsByActor(film2, actor);
		                          flag=1;
		                          getAllFilm(films);
	                       	 }
							    if(flag==0)
							       {
								      System.out.println("Film not found");
							       }
	                         }
						break;
						
					case 4://search film by category
						System.out.println("Enter Category");
						String category=sc.next();
						 
						for(Film film3:lst)
						{
							
							 if(film3!=null)
	                       	 {
								 List<Film> films=filmService.searchFilmDetailsByActor(film3, category);
		                          flag=1;
	                       	 }
							    if(flag==0)
							       {
								      System.out.println("Film not found");
							       }
	                         }
						break;
					case 5://search by language
						System.out.println("Enter Lanugage");
						String lang=sc.next();
						
						
						for(Film film5:lst)
						{ if(film5!=null)
                      	 {
							List<Film> films= filmService.searchFilmDetailsByActor(film5, lang);
	                          flag=1;
                     	 }
						    if(flag==0)
						       {
							      System.out.println("Film not found");
						       }
						}
						break;
					case 6://search by ratings
						System.out.println("Enter Rating");
						int rating=sc.nextInt();
						
						for(Film film4:lst)
						{
							if(film4.getRatings()==rating)
							{
								 List<Film> films=filmService.searchFilmDetailsByRatings(film4, rating);
		                          flag=1;
							    getAllFilm(films);
							}
						}
						if(flag==0)
						{
							System.out.println("Film not found");
						}
						break;
					}
			}
			

			
			
			//Modify film details
			
		
			public void  modifyFilm(Collection<Film> lst)
			{
				int flag = 0;
				
						System.out.println("Enter the Film Id");
						int filmid=sc.nextInt();
						for(Film film:lst)
						{
							if(film.getFilm_Id()==filmid)
							{
								
								Film film1=addFilm(filmService.getLanguages(),filmService.getCategory(),actorService.getActor());
								int count=filmService.modifyFilmDetailsById(film1, filmid);
								flag=1;
								if(count==1)
								{
									System.out.println("Updated");
								}
								
							}
						}
						if(flag==0)
						{
							System.out.println("Film not found");
						}
			}
					
				

			
		}
	
		
		
		
		
	
