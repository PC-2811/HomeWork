package com.flp.fms.dao;

import java.util.List;
import java.util.*;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;

public interface IFilmDao {
	
	public List<Language> getLanguages();
	public List<Category> getCategory();
	
    public void addFilm(Film film);
	
	public List<Film> getAllFilms();
	
	//delete film details
	public boolean deleteFilmDetailByRatings(int ratings);
	public boolean deleteFilmDetailsByTitle(String title);
	public boolean deleteFilmDetailsByReleaseYear(Date releaseYear);
	
	
	//search film details
	
	public List<Film> searchFilmDetailsById(Film film,int filmid);
	public List<Film> searchFilmDetailsByTitle(Film film,String title);
	public List<Film> searchFilmDetailsByActor(Film film,String actor);
	public List<Film> searchFilmDetailsByCategory(Film film,int category);
	public List<Film> searchFilmDetailsByLanguage(Film film,String language);
	public List<Film> searchFilmDetailsByRatings(Film film,int ratings);
	
	
	
	//Modify film details
	public int modifyFilmDetailsById(Film film,int filmid);
	//public List<Film> modifyFilmDetailsByTitle(Film film,String title);
	//public List<Film> modifyFilmDetailsByReleaseYear(Film film,Date releaseYear);
	
}
