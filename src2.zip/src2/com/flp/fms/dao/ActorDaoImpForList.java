package com.flp.fms.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.flp.fms.domain.Actor;

import com.mysql.jdbc.PreparedStatement;

public class ActorDaoImpForList implements IActorDao {

	
public Connection getConnection(){
		
		Connection connection=null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection=(Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/film_management(phase2)","root","Pass1234");
			
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return connection;
	}
	
	
	
	@Override
	public List<Actor> getActor() {
		
		
		Connection con=getConnection();
		List<Actor> actor=new ArrayList<>();
		String sql="select * from actors";

		try {
			PreparedStatement pst=(PreparedStatement) con.prepareStatement(sql);
			ResultSet rs=pst.executeQuery();
					
			while(rs.next()){
				Actor actors=new Actor();
				actors.setActor_Id((rs.getInt(1)));             
				actors.setFirstName(rs.getString(2));       
				actors.setLastName(rs.getString(3)); 
				
				actor.add(actors);
							
			}
						
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return actor;
	}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
