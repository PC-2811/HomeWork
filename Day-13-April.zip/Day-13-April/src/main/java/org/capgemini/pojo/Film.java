package org.capgemini.pojo;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

       @Entity
	public class Film {
		//private fields
	
	
	
	
	
	           @Id
	           @GeneratedValue
				private int film_Id;
				//private String description;
				private String film_Title;
			   // private Date release_Year;
				//private List<Language> languages;
				//private Language original_Language;
				//private Date rental_Duration;
				private int length;
				//private double replacement_Cost;
				private int ratings;
				//private String special_Features;
				//private List<Actor> actors;
				//private Category category;
				
				
				
				
				

				@OneToMany(cascade=CascadeType.ALL,fetch=FetchType.LAZY,
						targetEntity=Actor.class,mappedBy="film1")
				private List<Actor> actor=new ArrayList<Actor>();
				
				
				
				
				//No argument constructor
				public Film(){}

				public Film( String film_Title, int length, int ratings) {
					super();
					//this.film_Id = film_Id;
					this.film_Title = film_Title;
					//this.original_Language = original_Language;
					this.length = length;
					this.ratings = ratings;
					//this.actor = actor;
				}

				public Film( int film_Id,String film_Title, int length, int ratings,List<Actor> actor) {
					super();
					this.film_Id = film_Id;
					this.film_Title = film_Title;
					//this.original_Language = original_Language;
					this.length = length;
					this.ratings = ratings;
					this.actor = actor;
				}
				
				

				public int getFilm_Id() {
					return film_Id;
				}

				public void setFilm_Id(int film_Id) {
					this.film_Id = film_Id;
				}

				public String getFilm_Title() {
					return film_Title;
				}

				public void setFilm_Title(String film_Title) {
					this.film_Title = film_Title;
				}

				/*public Language getOriginal_Language() {
					return original_Language;
				}

				public void setOriginal_Language(Language original_Language) {
					this.original_Language = original_Language;
				}
*/
				public int getLength() {
					return length;
				}

				public void setLength(int length) {
					this.length = length;
				}

				public int getRatings() {
					return ratings;
				}

				public void setRatings(int ratings) {
					this.ratings = ratings;
				}

				public List<Actor> getActor() {
					return actor;
				}

				public void setActor(List<Actor> actor) {
					this.actor = actor;
				}

				@Override
				public String toString() {
					return "Film [film_Id=" + film_Id + ", film_Title=" + film_Title + ", length=" + length
							+ ", ratings=" + ratings + ", actor=" + actor + "]";
				}

			
				

				
				
}
