package org.capgemini.pojo;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Language {
	//Private fields
	@Id
		private int language_Id;
		private String language_Name;
		
		public Language(){}

		public Language(int language_Id, String language_Name) {
			super();
			this.language_Id = language_Id;
			this.language_Name = language_Name;
		}

		public int getLanguage_Id() {
			return language_Id;
		}

		public void setLanguage_Id(int language_Id) {
			this.language_Id = language_Id;
		}

		public String getLanguage_Name() {
			return language_Name;
		}

		public void setLanguage_Name(String language_Name) {
			this.language_Name = language_Name;
		}

		@Override
		public String toString() {
			return "Language [language_Id=" + language_Id + ", language_Name=" + language_Name + "]";
		}
		
}
