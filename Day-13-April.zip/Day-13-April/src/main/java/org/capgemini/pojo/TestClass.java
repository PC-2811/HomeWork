package org.capgemini.pojo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.tool.hbm2ddl.SchemaExport;

public class TestClass {

	public static void main(String[] args) {
		AnnotationConfiguration config=new AnnotationConfiguration();
		config.addAnnotatedClass(Actor.class);
		config.addAnnotatedClass(Film.class);
		config.configure();
		
		new SchemaExport(config).create(true, true);
		
		SessionFactory factory= config.buildSessionFactory();
		Session session=factory.openSession();
		session.beginTransaction();
		
		Film fil1=new Film("Luck",500,5);
		Film fil2=new Film("Risk",600,4);
		
		Actor act1=new Actor(1, "Paul", "Walker",fil1);
		Actor act2=new Actor(2, "Vin", "Diesel",fil1);
		Actor act3=new Actor(3, "Leonardo", "DiCaprio",fil2);
		
		
		session.save(act1);
		session.save(act2);
		session.save(act3);
		

		session.getTransaction().commit();
		
		session.close();
		
		
		
	}
	}


