package org.capgemini.pojo;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Actor {
//private fields
	@Id
	private int actor_Id;
	private String firstName;
	private String lastName;
	
	
	
	@ManyToOne(cascade=CascadeType.ALL,fetch=FetchType.EAGER)
	@JoinColumn(name="film_Id_FK")
	private Film film1;
	
	//No argument constructor
	public Actor(){}

	public Actor(int actor_Id, String firstName, String lastName) {
		super();
		this.actor_Id = actor_Id;
		this.firstName = firstName;
		this.lastName = lastName;
	}
	public Actor(int actor_Id, String firstName, String lastName,Film film) {
		super();
		this.actor_Id = actor_Id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.film1=film;
	}

	public int getActor_Id() {
		return actor_Id;
	}

	public void setActor_Id(int actor_Id) {
		this.actor_Id = actor_Id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	@Override
	public String toString() {
		return "Actor [actor_Id=" + actor_Id + ", firstName=" + firstName + ", lastName=" + lastName + "]";
	}


}
