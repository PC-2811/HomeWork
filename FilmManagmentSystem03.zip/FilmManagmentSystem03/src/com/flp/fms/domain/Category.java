package com.flp.fms.domain;

public class Category {
	
	// private fields
	private int CategoryId;
	private String Name;
	
	
	// no argument constructor
	public Category() {}
	
	// constructor with arguments
	public Category(int CategoryId, String Name){
	
		super();
		this.CategoryId = CategoryId;
		this.Name = Name;
		
		
	}
     
	// Getter and Setter
	public int getCategoryId() {
		return CategoryId;
	}

	public void setCategoryId(int categoryId) {
		CategoryId = categoryId;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	

	@Override
	public String toString() {
		return "Category [CategoryId=" + CategoryId + ", Name=" + Name +    "]";
	}
	
	
}
