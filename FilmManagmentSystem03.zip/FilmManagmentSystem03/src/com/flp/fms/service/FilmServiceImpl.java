package com.flp.fms.service;
import java.util.ArrayList;
import java.util.List;

import com.flp.fms.dao.FilmDaoImplForList;
import com.flp.fms.dao.IFilmDao;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Language;
import com.flp.fms.domain.LoginUser;

import java.util.Map;
import java.util.Set;
import com.flp.fms.domain.Film;


public class FilmServiceImpl implements IFilmService{
	
	private IFilmDao filmDao=new FilmDaoImplForList();

	@Override
	public List<Language> getLanguages() {
		
		return filmDao.getLanguages();
	}

public List<Category> getCategory() {
		
		return filmDao.getCategory();
}
@Override
public int addFilm(Film film) {
	
	/*film.setFilmId(generate_Film_Id());
	filmDao.addFilm(film);*/
	return filmDao.addFilm(film);
	
}

/*
public int generate_Film_Id(){
	
	int filmId=0;
	
	//Verify filmId has been Duplicated or not
	do{
		double fid=Math.random()*1000;
		filmId=(int)fid;
	}while(checkDuplicateFilmId(filmId));
	
	
	return filmId;
}

@Override
public Map<Integer, Film> getAllFilms() {
	
	return filmDao.getAllFilms();
}





public boolean checkDuplicateFilmId(int filmId){
	
	Set<Integer> keys= getAllFilms().keySet();
	boolean flag=false;
	if(keys.isEmpty() || keys==null){
		flag= false;
	}else{
		for(Integer key:keys){
			if(key==filmId){
				flag=true;
				break;
			}
		}
	}
	
	return flag;
}*/
	public Map<Integer, Film> searchfilm() {
		
		return filmDao.searchfilm();
	
}
	
	@Override
	public Map<Integer, Film> removefilm() {
		// TODO Auto-generated method stub
		return filmDao.removefilm();
	}

	@Override
	public ArrayList<Film> getAllFilms() {
		// TODO Auto-generated method stub
		return filmDao.getAllFilms();
	}
	
    @Override
    public Boolean deleteFilm(int filmid) {
	// TODO Auto-generated method stub
	return filmDao.deleteFilm(filmid);
}

	@Override
	public ArrayList<Film> searchFilm(Film film) {
		// TODO Auto-generated method stub
		return filmDao.searchFilm(film);
		
		}

	@Override
	public Boolean modifyFilm(Film film) {
		// TODO Auto-generated method stub
		return filmDao.modifyFilm(film);
	}

	@Override
	public boolean isValidLogin(LoginUser loginUser) {
		// TODO Auto-generated method stub
		return filmDao.isValidLogin(loginUser);
	}
	}


