package org.film.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.film.pojo.Actor;



public class ActorDaoImpl implements ActorDao{

	
	FilmDaoImpl filmDao=new FilmDaoImpl();
	@Override
	public List<Actor> getActorList() {
		List<Actor> actor=new ArrayList<>();
		
		
		Connection con=filmDao.getConnection();
		
		String sql="select * from actors";
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			ResultSet rs=pst.executeQuery();
			
			while(rs.next())
			{
				Actor actor1=new Actor();
				actor1.setActor_Id(rs.getInt(1));
				actor1.setFirstName(rs.getString(2));
				actor1.setLastName(rs.getString(3));
				actor.add(actor1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return actor;
	}

	@Override
	public int addActor(Actor actor) {
		// TODO Auto-generated method stub
				//return getActorList();
		Connection con=filmDao.getConnection();
		String sql="insert into actors(firstName,lastName)values(?,?)";
		int count=0;
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			
			pst.setString(1, actor.getFirstName());
			pst.setString(2,actor.getLastName());
			
		 count=pst.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return count;
	}
//Remove actor from the database
	@Override
	public boolean deleteActorDetails(int actorid) {
		boolean flag=false;
		String sql="delete from actors where actor_id=?";
		Connection con=filmDao.getConnection();
		
		   	 try {
					PreparedStatement pst=con.prepareStatement(sql);
				
				pst.setInt(1,actorid);
				 
				 
				 int count=pst.executeUpdate();
				 

					if(count>0)
						flag=true;
					
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		   	 
		   	try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		return flag;
	}

	//search actor from the database
	@Override
	public List<Actor> searchActorDetails(Actor actor) {
		
		Connection con=filmDao.getConnection();
		
		int count=0;
		String sql="select * from actors where";
		List<Actor> actors=new ArrayList<Actor>();
		
		if(actor!=null)
		{
			if(actor.getActor_Id()>0)
			{
				
				sql+=" actor_id="+actor.getActor_Id();
				
				count=1;
			}
			
			if(actor.getFirstName()!=null)
			{
				if(count==1)
				{
					sql+=" and firstName='"+actor.getFirstName()+"'";
				}
				else
				{
					sql+=" firstName='"+actor.getFirstName()+"'";
				}
				count=2;
			}
		}
		
	
			
			try {
				PreparedStatement pst= con.prepareStatement(sql);
				ResultSet rs=pst.executeQuery();
				
				while(rs.next())
				{
					Actor actor1=new Actor();
					actor1.setActor_Id(rs.getInt(1));
					actor1.setFirstName(rs.getString(2));
					actor1.setLastName(rs.getString(3));
					
					actors.add(actor1);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		return actors;
	}

	//update actor
	@Override
	public int updateActorDetails(int actorid, Actor actor) {
		
         Connection con=filmDao.getConnection();
		System.out.println("DAO="+actorid);
		int count=0;
		
		String sql="update actors set firstName=?,lastName=? where actor_id="+actorid;
		
		
			
			try {
				PreparedStatement pst = con.prepareStatement(sql);
				
				pst.setString(1,actor.getFirstName());
				pst.setString(2, actor.getLastName());
				
				count=pst.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		return count;
	}

	@Override
	public Actor getSearchActorByID(int actorid)  {

		Connection con=filmDao.getConnection();
		
		Actor actor=new Actor();
		
		String sql="select * from actors where actor_id=?";
		
		
		try {
			PreparedStatement pst= con.prepareStatement(sql);
			pst.setInt(1, actorid);
			ResultSet rs=pst.executeQuery();
			
			while(rs.next()){
			
					actor.setActor_Id(rs.getInt(1));
					actor.setFirstName(rs.getString(2));
					actor.setLastName(rs.getString(3));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return actor;
	}

	

}
