package org.film.dao;

import java.util.List;

import org.film.pojo.Actor;
import org.film.pojo.Film;

public interface ActorDao {

	public int addActor(Actor actor);

	List<Actor> getActorList();
	
	public boolean deleteActorDetails(int actorid);
	
	public List<Actor> searchActorDetails(Actor actor);
	public Actor getSearchActorByID(int actorid);
	
	public int updateActorDetails(int actorid,Actor actor);
}
