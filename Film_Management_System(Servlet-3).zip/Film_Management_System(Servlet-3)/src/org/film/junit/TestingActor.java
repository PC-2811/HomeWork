package org.film.junit;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.film.dao.ActorDao;
import org.film.dao.ActorDaoImpl;
import org.film.pojo.Actor;
import org.junit.Test;

public class TestingActor {
	
	ActorDao actorDao=new ActorDaoImpl();
	    //TEST CASES FOR ACTOR 
		//1.Object is null
		//2.duplicate actor entry should not be allowed
		//3.Not Valid Actor
	    //4.get All Actors

	
	@Test
	public void isActorObjectIsNull() {
		
		Actor actor=null;
		assertNotEquals(actor, actorDao.getSearchActorByID(50));
		
	} 
	@Test
	public void noDuplicateActorEntry() {
	
		Actor actor=new Actor(1,"Sharukh","Khan");
		assertNotEquals(actor, actorDao.getSearchActorByID(2));
		
	}
	@Test
	public void isNotValidActor() {
		
		Actor actor=new Actor(15,"ABC","XYZ");
		assertNotEquals(actor, actorDao.getSearchActorByID(15));
		
	}
	
	
	@Test
	public void isNotValidActorEntry() {
		
		Actor actor=new Actor(15,"ABC","XYZ");
		assertEquals(1, actorDao.addActor(actor));
		
	}
	
	

	//TEST CASE FOR ACTOR LIST
	@Test
	public void testGetActor(){
		List<Actor> actor=new ArrayList<>();
		
		actor.add(new Actor(1, "Sharukh", "Khan"));
		actor.add(new Actor(2, "Ajay", "Devgan"));
		actor.add(new Actor(3, "Salman", "Khan"));
		actor.add(new Actor(4, "Akshay", "Kumar"));
		actor.add(new Actor(5, "Ranbir", "Kapoor"));
		actor.add(new Actor(6, "Ranvir", "Singh"));
		actor.add(new Actor(7, "Shahid", "Kapoor"));
		actor.add(new Actor(8, "Deepika", "Padukon"));
		actor.add(new Actor(9, "Katrina", "Kaif"));
		actor.add(new Actor(10, "Madhuri", "Nene"));
		
		assertEquals(actor, actorDao.getActorList());

	}
	
}
