package org.film.junit;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.film.dao.ActorDao;
import org.film.dao.ActorDaoImpl;
import org.film.pojo.Actor;
import org.film.pojo.Category;
import org.film.pojo.Film;
import org.film.pojo.Language;
import org.film.service.FilmService;
import org.film.service.FilmServiceImpl;
import org.junit.Test;

public class TestingFilm {
	
	FilmService filmService=new FilmServiceImpl();
   
	//TEST CASES FOR  FILM
	//1.Film object should not be null
	//2. Valid Film object to add
	//3.Film not present to search
	//4.Film not present to delete
	
	
	

	
	
	@Test
	public void filmObjectIsNullWhenSearchById()
	{
		 Film film=null;
        assertNotEquals(film, filmService.getSearchFilmByID(1));
	}

	@Test
	public void isValidFilmEntryToAdd()
	{
		
		
		 Film film=new Film();
		 film.setFilm_Id(1);
		 film.setFilm_Title("Three Idiots");
		 film.setDescreption("good");
		 
		 String date="29-may-2007";
		 Date dt=new Date(date);
		 film.setRelease_Year(dt);
		 
		
		 Language lang=new Language();
			 lang.setLanguage_Id(1);
		 film.setOriginal_Language(lang);
		 
		 String date1="19-may-2007";
		 Date dt1=new Date(date1);
		 film.setRental_Duration(dt1);
		 
		 film.setLength(50);
		 
		 film.setReplacement_Cost(200);
		 
		 film.setRatings(2);
		 
		 film.setSpecial_Features("very nice");
		 
		 Category cat1=new Category();
	     cat1.setCategory_Id(1);
		 film.setCategory(cat1);
		 
		 List<Language> langs=new ArrayList<>();
			Language lang1=new Language();
			lang1.setLanguage_Id(2);
			langs.add(lang);
	    	langs.add(lang1);
			film.setLanguages(langs);
			
			List<Actor> actors=new ArrayList<>();
			Actor actor1=new Actor();
			actor1.setActor_Id(1);
			Actor actor2=new Actor();
	    	actor2.setActor_Id(2);
			actors.add(actor1);
			actors.add(actor2);
	    	film.setActors(actors);
		
		
        assertEquals(1, filmService.AddFilmServlet(film));
	}
	

	
	@Test
	public void isFilmNotPresent()
	{
		 List<Film> films=filmService.getAllFilmDetails();
		 Film film1=new Film();
		 for(Film film:films)
			 film1=film;
        assertNotEquals(film1, filmService.searchFilmDetails(film1));
	}
	
	@Test
	public void isFilmNotPresentToDelete()
	{
		
		 assertFalse(filmService.deleteFilmDetails(50));
		
	}
	
}

	

