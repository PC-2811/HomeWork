package org.film.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.film.pojo.Actor;
import org.film.service.ActorService;
import org.film.service.ActorServiceImpl;

/**
 * Servlet implementation class DeleteActor
 */
public class DeleteActor extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out=response.getWriter();
		
		ActorService actorService=new ActorServiceImpl();
		
		String actorid=request.getParameter("actor_id");
		
		Actor actor=new Actor();
		
     boolean flag=actorService.deleteActorDetails(Integer.parseInt(actorid));
		
		if(flag){
			request.getRequestDispatcher("DeleteActorServlet").forward(request, response);
		}
	}

}
