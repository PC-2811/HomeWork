package org.film.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.film.pojo.Actor;
import org.film.service.ActorService;
import org.film.service.ActorServiceImpl;

/**
 * Servlet implementation class UpdateActor
 */
public class UpdateActor extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		ActorService actorService=new ActorServiceImpl();
		
		List<Actor> actors=actorService.getActorList();
		PrintWriter out=response.getWriter();
		
		

		out.println("<head>");
		out.print("<link rel='stylesheet' type='text/css' href='css/myStyle.css'>");
		out.println("</head>");
		
		
		out.println("<body>"
		
		    	+ "<h2 align='center'>List Of Actors</h2>"
				+ "<table border=2px>"
				+ "<tr>"
				+ "<th>Actor Id</th>"
				+ "<th>First Name</th>"
				+ "<th>Last Name</th>"
				
				+ "<th>Update</th>"
				+ "</tr>");
		
		for(Actor actor:actors){
			out.println("<tr>");
			out.println("<td>"+actor.getActor_Id()+"</td>");
			out.println("<td>"+actor.getFirstName()+"</td>");
			out.println("<td>"+actor.getLastName()+"</td>");
			
			
			out.println("<td><a href='UpdateActorServlet1?actor_id="+actor.getActor_Id()+"'>Update</a></td>");
			
			out.println("</tr>");
		}
			out.println("</table></body>");

			out.println("</html>");
	
	
		
		
	}

}
