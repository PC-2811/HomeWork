package org.capgemini.fms.pojo;

public class Language {

	//Private fields
	private int languageId;
	private String languageName;
	
	
	//No arg Constructer
	public Language(){}

	
	
	
	//Constructer with fields
	public Language(int languageId, String languageName) {
		super();
		this.languageId = languageId;
		this.languageName = languageName;
	}



	
	//Getters and Setters

	public int getLanguageId() {
		return languageId;
	}




	public void setLanguageId(int languageId) {
		this.languageId = languageId;
	}




	public String getLanguageName() {
		return languageName;
	}




	public void setLanguageName(String languageName) {
		this.languageName = languageName;
	}




	
	//toString method
	
	@Override
	public String toString() {
		return "Language [languageId=" + languageId + ", languageName=" + languageName + "]";
	}
	
	
	
	
	
	
	
	
	
}
