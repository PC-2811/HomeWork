package org.capgemini.fms.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.capgemini.fms.pojo.Actor;
import org.capgemini.fms.pojo.Category;
import org.capgemini.fms.pojo.Film;
import org.capgemini.fms.pojo.Language;

public class FilmDaoImpl implements FilmDao{
public Connection getConnection(){
		
		Connection connection=null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/film_management","root","Pass1234");
			
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}/*finally {
    try {
		connection.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}*/
		
		
		
		return connection;
	}

	
	@Override
	public void AddFilmServlet(Film film) {
	
		
			
			Connection con=getConnection();
			
			String sql="insert into film(title,description,releaseYear,rentalDuration,originalLanguage,length,replacementCost,ratings,specialFeatures,category)"+"values(?,?,?,?,?,?,?,?,?,?)";
			try {
				PreparedStatement pst=con.prepareStatement(sql);
				pst.setString(1, film.getFilmTitle());
				
				pst.setString(2, film.getDescription());
				
				pst.setDate(3, new Date(film.getReleaseYear().getTime()));
				
				pst.setDate(4, new Date(film.getRentalDuration().getTime()));
				
				pst.setObject(5,film.getOriginal_Language().getLanguageId());
			
				pst.setInt(6,film.getLength());
				pst.setDouble(7, film.getReplacementCost());
				pst.setInt(8, film.getRatings());
				pst.setString(9, film.getSpecialFeatures());
				pst.setObject(10, film.getCategory().getCategory_Id());
				
				
				
				int count=pst.executeUpdate();
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			//save data into film_actors
			String str1="select * from film order by filmid desc limit 1 ";
			
			int fid=0;
			
			try {
				PreparedStatement pst=con.prepareStatement(str1);
				ResultSet rs=pst.executeQuery();
				
				while(rs.next())
				{
				fid=rs.getInt(1);
				}
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			String str2="insert into film_actors(film_id,actor_id)values(?,?)";
			
			
			try {
				PreparedStatement pst=con.prepareStatement(str2);
				List<Actor> actors=film.getActors();
				
				
				for(Actor actor:actors)
				{
					pst.setInt(1, fid);
					pst.setObject(2,actor.getActor_Id());
					int count=pst.executeUpdate();
				}
				
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			
			//save data into film_language
			String str3="select * from film order by filmid desc limit 1 ";
			
			int filmid=0;
			
			try {
				PreparedStatement pst=con.prepareStatement(str3);
				ResultSet rs=pst.executeQuery();
				
				while(rs.next())
				{
				fid=rs.getInt(1);
				}
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			String str4="insert into film_language(film_id,language_id) values(?,?)";
			
			
			try {
				PreparedStatement pst=con.prepareStatement(str4);
				List<Language> languages=film.getLanguages();
				
				for(Language lang:languages)
				{
					pst.setInt(1, fid);
					pst.setObject(2,lang.getLanguageId());
					System.out.println(lang.getLanguageId());
					int count=pst.executeUpdate();
				}
				//System.out.println(languages);
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			
			
		}


	@Override

	public List<Language> getAllLanguages() {
		List<Language> languages=new ArrayList<>();
		String str="select * from language";
		Connection con=getConnection();
		
		try {
			PreparedStatement pst=con.prepareStatement(str);
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				Language lang=new Language();
				lang.setLanguageId(rs.getInt(1));
				lang.setLanguageName(rs.getString(2));
				
				
				
				
				//Adding the customer into arraylist
				languages.add(lang);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}/*finally {
	    try {
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}*/
		
		return languages;
	}


	@Override
	public List<Actor> getAllActors() {
		List<Actor> actors=new ArrayList<>();
		String str="select * from actors";
		Connection con=getConnection();
		
		try {
			PreparedStatement pst=con.prepareStatement(str);
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				Actor actor=new Actor();
				actor.setActor_Id(rs.getInt(1));
				actor.setFirstName(rs.getString(2));
				actor.setLastName(rs.getString(3));
				
				
				
				
				//Adding the customer into arraylist
				actors.add(actor);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}/*finally {
	    try {
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}*/
		
		return actors;
	}


	@Override
	public List<Category> getAllCategories() {
		List<Category> categories=new ArrayList<>();
		String str="select * from category";
		Connection con=getConnection();
		
		try {
			PreparedStatement pst=con.prepareStatement(str);
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				Category category=new Category();
				category.setCategory_Id(rs.getInt(1));
				category.setCategory_Name(rs.getString(2));
			   
				
				
				
				
				//Adding the customer into arraylist
				categories.add(category);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return categories;
	}


	@Override
	public List<Film> getAllFilms() {
		
		List<Film> films=new ArrayList<>();
		
		Connection con=getConnection();
		
		String sql="select film.filmid,film.title,film.description,film.releaseYear,language.language_name,film.rentalDuration,film.length,film.replacementCost,film.ratings,film.specialFeatures,category.category_name from film join category on(film.category=category.category_id) join language on(film.originalLanguage=language.language_Id)";
		
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			ResultSet rs=pst.executeQuery();
	
			while(rs.next())
			{
				Film film=new Film();
				
				film.setFilm_Id(rs.getInt(1));
				film.setFilmTitle(rs.getString(2));
				film.setDescription(rs.getString(3));
				film.setReleaseYear(rs.getDate(4).valueOf(rs.getDate(4).toString()));
				
				Language lang=new Language();
				lang.setLanguageName(rs.getString(5));
				//lang.setLanguage_Id(rs.getInt(5));
				film.setOriginal_Language(lang);
				
				film.setRentalDuration(rs.getDate(6).valueOf(rs.getDate(6).toString()));
				film.setLength(rs.getInt(7));
				film.setReplacementCost(rs.getDouble(8));
				film.setRatings(rs.getInt(9));
				film.setSpecialFeatures(rs.getString(10));
				
				Category category=new Category();
				category.setCategory_Name(rs.getString(11));
				film.setCategory(category);
				
				//get multiple languages
				List<Language> languages=getLanguage(rs.getInt(1));
				film.setLanguages(languages);
				
				//get multiple actors
				List<Actor> actors=getActors(rs.getInt(1));
				film.setActors(actors);
				
				films.add(film);
				System.out.println(film);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}/*finally {
	    try {
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}*/
		return films;
	}

	public List<Language> getLanguage(int filmId)
	{
		List<Language> languages=new ArrayList<>();
		int filmid=filmId;
		String sql="select language.language_Id,language.language_name from language where language_Id in(select language_id from film_language where film_id=" + filmid +")";

		
		Connection con=getConnection();
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				Language lang=new Language();
				lang.setLanguageId(rs.getInt(1));
				lang.setLanguageName(rs.getString(2));
				languages.add(lang);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}/*finally {
	    try {
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}*/
		
		return languages;
		
	}
	
	
	
	//get multiple actors
	
	public List<Actor> getActors(int filmId)
	{
		List<Actor> actors=new ArrayList<>();
		int filmid=filmId;
		String sql="select actors.actor_id,actors.firstName,actors.lastName from actors where actor_id in(select actor_id from film_actors where film_id=" + filmid +")";

		
		Connection con=getConnection();
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				Actor actor=new Actor();
				actor.setActor_Id(rs.getInt(1));
				actor.setFirstName(rs.getString(2));
				actor.setLastName(rs.getString(3));
				
				actors.add(actor);
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}/*finally {
	    try {
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}*/
		
		return actors;
		
	}
	

	@SuppressWarnings("unchecked")
	@Override
	public List<Film> searchAllFilms(Film film) {

		
		Connection con=getConnection();
		int count=0;
		String sql="select * from film where";
		ArrayList<Film> films=new ArrayList<Film>();
		System.out.println(film);
		if(film!=null)
		{
			if(film.getFilmId()>0)
			{
				
				sql+=" filmid="+film.getFilmId();
				
				count=1;
			}
			
			if(film.getFilmTitle()!=null)
			{
				if(count==1)
				{
					sql+=" and title='"+film.getFilmTitle()+"'";
				}
				else
				{
					sql+=" title='"+film.getFilmTitle()+"'";
				}
				count=2;
			}
		

			if(film.getRatings()>0)
			{
				if(count==1||count==2)
				{
					sql+=" and ratings="+film.getRatings();
				}
				else
				{
					sql+=" ratings="+film.getRatings();
				}
				count=3;
			}
			if(film.getActors()!=null)
			{
				Actor actor=new Actor();
				List<Actor> actors=film.getActors();
				for(Actor a:actors)
					actor=a;
				if(count==1||count==2||count==3)
				{
					sql+=" and filmid In(Select film_id from film_actors where actor_id="+actor.getActor_Id()+")";
					
				}else
				{
				sql+=" filmid In(Select film_id from film_actors where actor_id="+actor.getActor_Id()+")";
				}
				count=4;
			}
			if(film.getLanguages()!=null)
			{
				Language lang=new Language();
				List<Language> langs=film.getLanguages();
			
				for(Language l:langs)
					lang=l;
				if(count==1||count==2||count==3||count==4)
				{
					sql+=" and( filmid In(Select film_id from film_language where language_id="+lang.getLanguageId()+") or filmid In( Select filmid from film where originalLanguage="+lang.getLanguageId()+"))";
					
				}else
				{
				sql+=" ( filmid In(Select film_id from film_language where language_id="+lang.getLanguageId()+") or filmid In (Select filmid from film where originalLanguage="+lang.getLanguageId()+"))";
				
				}
				count=5;
			}
		
			 
			if(film.getReleaseYear()!=null)
			{
				if(count==1||count==2||count==3||count==4||count==5)
				{
					sql+=" and releaseYear='"+new java.sql.Date(film.getReleaseYear().getTime())+"'";
				}
				else
				{
					sql+=" releaseYear='"+new java.sql.Date(film.getReleaseYear().getTime())+"'";
				}
				count=6;
			}
			System.out.println(sql);
			try {
				PreparedStatement pst=con.prepareStatement(sql);
				ResultSet rs=pst.executeQuery();
			
				while(rs.next())
				{
					Film film1=new Film();
					film1.setFilm_Id(rs.getInt(1));
					film1.setFilmTitle(rs.getString(2));
					film1.setDescription(rs.getString(3));
					film.setReleaseYear(rs.getDate(4));
					
					
					
					
					
					String subsql;
					subsql="select language_name from language where language_Id="+rs.getInt(5);
					PreparedStatement pst1=con.prepareStatement(subsql);
					ResultSet rs3=pst1.executeQuery();
					Language lang=new Language();
					if(rs3.next())
					{
						lang.setLanguageId(rs.getInt(5));
						lang.setLanguageName(rs3.getString(1));
					}
					film1.setOriginal_Language(lang);
					film1.setRentalDuration(rs.getDate(6));
					film1.setLength(rs.getInt(7));
					film1.setReplacementCost(rs.getInt(8));
					film1.setRatings(rs.getInt(9));
					film1.setSpecialFeatures(rs.getString(10));
					
					subsql="select category_name from category where category_id="+rs.getInt(11);
					PreparedStatement pst3=con.prepareStatement(subsql);
				    rs3=pst3.executeQuery();
					if(rs3.next())
					{
						Category cat=new Category();
						cat.setCategory_Id(rs.getInt(11));
						cat.setCategory_Name(rs3.getString(1));
						film1.setCategory(cat);
					}
					
					subsql="select language_id from film_language where film_id="+rs.getInt(1);
					System.out.println(rs.getInt(1));
					pst3=con.prepareStatement(subsql);
				    rs3=pst3.executeQuery();
				    List<Language> languages=new ArrayList<>();
					while(rs3.next())
					{
												
						String subsql1="select language_name from language where language_Id="+rs3.getInt(1);
						PreparedStatement pst2=con.prepareStatement(subsql1);
						ResultSet rs1=pst2.executeQuery();
						while(rs1.next()){
							Language langs=new Language();
							langs.setLanguageId(rs3.getInt(1));
							langs.setLanguageName(rs1.getString(1));
							languages.add(langs);
							
						}
					}
					film1.setLanguages(languages);
					subsql="select actor_id from film_actors where film_id="+rs.getInt(1);
				
					pst3=con.prepareStatement(subsql);
				    rs3=pst3.executeQuery();
				    List<Actor> actors=new ArrayList<>();
					while(rs3.next())
					{
						String subsql1="select firstName,lastName from actors where actor_id="+rs3.getInt(1);
						PreparedStatement pst2=con.prepareStatement(subsql1);
						ResultSet rs1=pst2.executeQuery();
						while(rs1.next()){
							Actor actr=new Actor();
							actr.setFirstName(rs1.getString(1));
							actr.setLastName(rs1.getString(2));
							actr.setActor_Id(rs3.getInt(1));
							actors.add(actr);
							
						}
					}
					film1.setActors(actors);
					film1.setLanguages(languages);
					System.out.println(film1);
					films.add(film1);
			} }catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
			
		}/*finally {
	    try {
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}*/
		
		return films;
	}
		


	@Override
	public boolean deleteAllFilms(int filmid) {
		
		
		boolean flag=false;
		String sql="delete from film where filmid=?";
		
		
		   	 try {
					PreparedStatement pst= getConnection().prepareStatement(sql);
				
				pst.setInt(1,filmid);
				 
				 
				 int count=pst.executeUpdate();
				 

					if(count>0)
						flag=true;
					
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		
		return flag;
	}


	@Override
	public int updateFilmDetails(int filmid,Film film) {
		
		//System.out.println(id+"dao");
		int  count=0;
		Connection con=getConnection();
		String sql="update film set title=?,description=?,releaseYear=?,originalLanguage=?,rentalDuration=?,length=?,replacementCost=?,ratings=?,specialFeatures=?,category=? where filmid=?";
		String sql1="delete from film_language where film_id=?";
		String sql4="delete from film_actors where film_id=?";
		
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			//pst.setString(1, film.getTitle());
			pst.setString(1, film.getFilmTitle());
			pst.setString(2, film.getDescription());
			pst.setDate(3, new Date(film.getReleaseYear().getTime()));
			int language=film.getOriginal_Language().getLanguageId();
			pst.setInt(4, language);
			pst.setDate(5, new Date(film.getRentalDuration().getTime()));
			pst.setInt(6, film.getLength());
			pst.setDouble(7,film.getReplacementCost());
			
			pst.setInt(8,film.getRatings());
			pst.setString(9,film.getSpecialFeatures());
			int category=film.getCategory().getCategory_Id();
			pst.setInt(10,category);
			pst.setInt(11, filmid);
			
			count=pst.executeUpdate();
			
			
			//delete from film_language
			PreparedStatement pst1=con.prepareStatement(sql1);
			pst1.setInt(1, filmid);
		    count=pst1.executeUpdate();
		    
		  //delete from film_actors
			PreparedStatement pst4=con.prepareStatement(sql4);
			pst4.setInt(1, filmid);
		    count=pst4.executeUpdate();
		    
		    //insert into film_language
		  //insert into film_languages
			String sql2="insert into film_language values(?,?)";
			PreparedStatement pst2=con.prepareStatement(sql2);
		     List<Language> lang=film.getLanguages();
		     System.out.println(lang);
			for(Language lang1:lang){
			pst2.setInt(1, filmid);
			pst2.setInt(2,lang1.getLanguageId());
		    count=pst2.executeUpdate();
			}
		    
			String sql3="insert into film_actors values(?,?)";
			PreparedStatement pst3=con.prepareStatement(sql3);
		    List<Actor> actor=film.getActors();
			for(Actor act1:actor){
			pst3.setInt(1, filmid);
			pst3.setInt(2,act1.getActor_Id());
			 count=pst3.executeUpdate();
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}/*finally {
	    try {
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}*/




		return count;
	}

	public Film getSearchFilmByID(int id) {
		Connection con=getConnection();
		Film film=new Film();
		String sql="select * from film where filmid=?";
		
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			pst.setInt(1, id);
			ResultSet rs=pst.executeQuery();
			while(rs.next()){
			/*	Film film=new Film();*/
				film.setFilm_Id(rs.getInt(1));
				film.setFilmTitle(rs.getString(2));
				film.setDescription(rs.getString(3));
				film.setReleaseYear(rs.getDate(4).valueOf(rs.getDate(4).toString()));
				//Original Language
				Language lang=new Language();
				lang.setLanguageName(rs.getString(5));
				film.setOriginal_Language(lang);
				
				//Rental Duration
				film.setRentalDuration(rs.getDate(6).valueOf(rs.getDate(6).toString()));
				
				//length
				film.setLength(rs.getInt(7));
				
				//replacementCost
				film.setReplacementCost(rs.getDouble(8));
				
				//rating
				film.setRatings(rs.getInt(9));
				
				//Special Features
				film.setSpecialFeatures(rs.getString(10));
				
				Category category=new Category();
				category.setCategory_Name(rs.getString(11));
				film.setCategory(category);
				
				//get multiple languages
				List<Language> languages=getLanguage(rs.getInt(1));
				film.setLanguages(languages);
				
				//get multiple actors
				List<Actor> actors=getActors(rs.getInt(1));
				film.setActors(actors);
				
				
				
				
				
			}
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return film;
	}

}
