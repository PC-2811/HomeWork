package org.capgemini.fms.service;

import java.util.List;

import org.capgemini.fms.dao.ActorDao;
import org.capgemini.fms.dao.ActorDaoImpl;
import org.capgemini.fms.pojo.Actor;

public class ActorServiceImpl implements ActorService{
	ActorDao actorDao=new ActorDaoImpl();
	@Override
	public List<Actor> addActor() {
		// TODO Auto-generated method stub
		return actorDao.addActor();
	}

	@Override
	public List<Actor> getActorList() {
		// TODO Auto-generated method stub
		return actorDao.getActorList();
	}
}
