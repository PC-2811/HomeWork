package org.film.service;

import java.util.ArrayList;
import java.util.List;

import org.film.dao.FilmDao;
import org.film.dao.FilmDaoImpl;
import org.film.pojo.Actor;
import org.film.pojo.Category;
import org.film.pojo.Film;
import org.film.pojo.Language;

public class FilmServiceImpl implements FilmService{

	FilmDao filmDao=new FilmDaoImpl();
	
	@Override
	public int AddFilmServlet(Film film) {
		
		return filmDao.AddFilmServlet(film);
	}

	@Override
	public List<Language> getAllLanguages() {
		// TODO Auto-generated method stub
		return filmDao.getAllLanguages();
	}

	@Override
	public List<Actor> getAllActors() {
		// TODO Auto-generated method stub
		return filmDao.getAllActors();
	}

	@Override
	public List<Category> getAllCategories() {
		// TODO Auto-generated method stub
		return filmDao.getAllCategories();
	}

	@Override
	public List<Film> getAllFilmDetails() {
		
		return filmDao.getAllFilmDetails();
	}

	@Override
	public List<Film> searchFilmDetails(Film film) {
		// TODO Auto-generated method stub
		return filmDao.searchFilmDetails(film);
	}

	@Override
	public boolean deleteFilmDetails(int filmid) {
		// TODO Auto-generated method stub
		return filmDao.deleteFilmDetails(filmid);
	}

	@Override
	public int updateFilmDetails(int filmid, Film film) {
		// TODO Auto-generated method stub
		return filmDao.updateFilmDetails(filmid, film);
	}
	
	public Film getSearchFilmByID(int id) {
		// TODO Auto-generated method stub
		return filmDao.getSearchFilmByID(id);
	}

}
