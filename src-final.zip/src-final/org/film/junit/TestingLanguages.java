package org.film.junit;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.film.dao.ActorDao;
import org.film.dao.ActorDaoImpl;
import org.film.pojo.Actor;
import org.film.pojo.Category;
import org.film.pojo.Language;
import org.film.service.FilmService;
import org.film.service.FilmServiceImpl;
import org.junit.Test;

public class TestingLanguages {

	
	  //TEST CASES FOR Language
			//1.Object is null
			//2.duplicate Language entry should not be allowed
			//3.Not Valid Language
	        //4.get all Languages
	FilmService filmService=new FilmServiceImpl();
/*
	@Test
	public void isLanguageObjectIsNull() {
		
		Language language=null;
		assertNotEquals(language, filmService.getAllLanguages());
		
	} 
	@Test
	public void noDuplicateLanguageEntry() {
		
		Language language=new Language(3,"English");
		assertNotEquals(language,filmService.getAllLanguages());
		
	}
	@Test
	public void isNotValidLanguage() {
		
		Language language=new Language(20,"ABC");
		assertNotEquals(language,filmService.getAllLanguages());
		
	}
	
	*/
	//TEST CASE FOR LIST OF LANGUAGES
		@Test
		public void GetAllLanguages(){
			

			List<Language>languages=new ArrayList<>();
			
			languages.add(new Language(1, "Marathi"));
			languages.add(new Language(2, "Hindi"));
			languages.add(new Language(3, "English"));
			languages.add(new Language(4, "Telugu"));
			languages.add(new Language(5, "Punjabi"));
			languages.add(new Language(6, "Tamil"));
			languages.add(new Language(7, "French"));
			languages.add(new Language(8, "Japanese"));
			languages.add(new Language(9, "Spanish"));
			languages.add(new Language(10, "German"));
			assertEquals(languages, filmService.getAllLanguages());
			
		}

}
