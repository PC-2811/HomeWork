package org.film.junit;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.film.dao.ActorDao;
import org.film.dao.ActorDaoImpl;
import org.film.pojo.Actor;
import org.film.pojo.Category;
import org.film.service.FilmService;
import org.film.service.FilmServiceImpl;
import org.junit.Test;

public class TestingCategory {

	 //TEST CASES FOR Category
	//1.Object is null
	//2.duplicate category entry should not be allowed
	//3.Not Valid category
	//4.Get all Category

FilmService filmService=new FilmServiceImpl();

@Test
public void isCategoryObjectIsNull() {
	
	Category category=null;
	assertNotEquals(category, filmService.getAllCategories());
	
} 

@Test
public void noDuplicateActorEntry() {
	
	Category category=new Category(1,"Comedy");
	assertNotEquals(category,filmService.getAllCategories());
	
}

@Test
public void isNotValidCategory() {
	
	Category category=new Category(20,"ABC");
	assertNotEquals(category,filmService.getAllCategories());
	
}


//TEST CASE FOR LIST FOR CATEGORY
	@Test
	public void testGetCategory(){
		
		List<Category> category=new ArrayList<>();
		
		category.add(new Category(1, "Comedy"));
		category.add(new Category(2, "Romantic"));
		category.add(new Category(3, "Adventures"));
		category.add(new Category(4, "Horror"));
		category.add(new Category(5, "Action"));
		category.add(new Category(6, "Thriller"));
		category.add(new Category(7, "Suspense"));
		category.add(new Category(8, "Scifi"));
		
		
		assertEquals(category, filmService.getAllCategories());
		
	}


}
