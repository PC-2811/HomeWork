package org.film.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.film.pojo.Actor;
import org.film.service.ActorService;
import org.film.service.ActorServiceImpl;

/**
 * Servlet implementation class UpdateActorServlet1
 */
public class UpdateActorServlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out=response.getWriter();
		
		ActorService actorService=new ActorServiceImpl();
		
      int id=Integer.parseInt(request.getParameter("actor_id"));
		System.out.println("update1="+id);
		Actor actor=actorService.getSearchActorByID(id);
		
		out.print("<head>");
		out.print("<link rel='stylesheet' type='text/css' href='../css/myStyle.css'>"+
                     "<script type='text/javascript' src='../scripts/Validate.js'></script>"+
                     "<link href='http://code.jquery.com/ui/1.10.4/themes/ui-lightness/jquery-ui.css' rel='stylesheet'>"+
           		 "     <script src='http://code.jquery.com/jquery-1.10.2.js'></script>"+
           		    "  <script src='http://code.jquery.com/ui/1.10.4/jquery-ui.js'></script>"+ 
                    "<link rel='stylesheet' type='text/css' href='../css/jquery-ui-1.9.2.custom.min.css'>"+
                     "<script type='text/javascript' src='../scripts/jquery-1.8.3.js'></script>"+
                     "<script type='text/javascript' src='../scripts/jquery-ui-1.9.2.custom.min.js'></script>"+
                     "     <script src='http://code.jquery.com/jquery-1.10.2.js'></script>"+
         		    "  <script src='http://code.jquery.com/ui/1.10.4/jquery-ui.js'></script>");
		
		
       out.print("</head>");
		
		out.print("<html>");
		out.print("<body>");
		out.print("<form name='film' method='get' action='UpdateActorServlet2'>");
		out.print("<h1 align='center'>Fill The Details of Actor</h1>");
		out.println("<center> "
				+ "<table>"
				+ "<tr>"
				+ "<td><label>First Name</label></td>"
				+ "<td>:</td>"
				+ "<td><input type='text' name='actorname' value='"+actor.getFirstName()+"'>"
				+ "<div id='actorErr'></div>"
				+ "</td>"
				+ "</tr>");
		out.print("<tr>"
				+ "<td><label>Last Name</label></td>"
				+ "<td>:</td>"
				+ "<td><input type='text' name='lname' value='"+actor.getLastName()+"'>"
			    + "</td>"
				+ "</tr>");
		
		out.print("</select></td></tr>"
				+ "<tr><td><input type='hidden' name='actor_id' value='"+id+"'");
		
		out.print("<tr><td></td>"
				+ "<td><input type='submit' value='Submit'</td>"
				+ "</tr>");
				
		
				
				
			
			out.print("</html");
	}

}
