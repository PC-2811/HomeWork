package org.film.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.film.pojo.Actor;
import org.film.service.ActorService;
import org.film.service.ActorServiceImpl;

/**
 * Servlet implementation class UpdateActorServlet2
 */
public class UpdateActorServlet2 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		 PrintWriter out=response.getWriter();
		 ActorService actorService=new ActorServiceImpl();	
			int actorid=Integer.parseInt(request.getParameter("actor_id"));
			System.out.println("update2="+actorid);
			Actor actor=new Actor();
			
			actor.setFirstName(request.getParameter("actorname"));
			actor.setLastName(request.getParameter("lname"));
			
			int count=actorService.updateActorDetails(actorid, actor);
			
			if(count>0)
				 
				  //request.getRequestDispatcher("EditServlet").forward(request, response);
				  
				  response.sendRedirect("UpdateActor");
		
	}

}
