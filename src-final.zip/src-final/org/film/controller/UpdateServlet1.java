package org.film.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.film.pojo.Actor;
import org.film.pojo.Category;
import org.film.pojo.Film;
import org.film.pojo.Language;
import org.film.service.ActorServiceImpl;
import org.film.service.FilmServiceImpl;

/**
 * Servlet implementation class UpdateServlet1
 */
public class UpdateServlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
           PrintWriter out=response.getWriter();
		
		FilmServiceImpl filmService=new FilmServiceImpl();
        ActorServiceImpl actorService=new ActorServiceImpl();
		
		
		
		List<Actor> actor=actorService.getActorList();
		List<Language> languages=filmService.getAllLanguages();
		List<Category> category=filmService.getAllCategories();
		
		
		int id=Integer.parseInt(request.getParameter("id"));
		
		Film film=filmService.getSearchFilmByID(id);
		
		List<Actor> actFilm=film.getActors();
		List<Language>langFilm=film.getLanguages();
		DateFormat df=new SimpleDateFormat("dd-MMM-yyyy");
		
		//System.out.println("edit");
		//System.out.println(film);
		
		out.print("<head>");
		out.print("<link rel='stylesheet' type='text/css' href='../css/myStyle.css'>"+
                     "<script type='text/javascript' src='../scripts/Validate.js'></script>"+
                    //"<link rel='stylesheet' type='text/css' href='../css/jquery-ui-1.9.2.custom.css'>"+
                     "<link href='http://code.jquery.com/ui/1.10.4/themes/ui-lightness/jquery-ui.css' rel='stylesheet'>"+
           		 "     <script src='http://code.jquery.com/jquery-1.10.2.js'></script>"+
           		    "  <script src='http://code.jquery.com/ui/1.10.4/jquery-ui.js'></script>"+ 
                    "<link rel='stylesheet' type='text/css' href='../css/jquery-ui-1.9.2.custom.min.css'>"+
                     "<script type='text/javascript' src='../scripts/jquery-1.8.3.js'></script>"+
                     "<script type='text/javascript' src='../scripts/jquery-ui-1.9.2.custom.min.js'></script>"+
                     "     <script src='http://code.jquery.com/jquery-1.10.2.js'></script>"+
         		    "  <script src='http://code.jquery.com/ui/1.10.4/jquery-ui.js'></script>"+
		 "    <script>"
  		  +"       $(function() {"
  		     +"       $( '#datepicker1' ).datepicker({maxDate:'0', dateFormat:'dd-MM-yy'});"
  		        +"    $( '#datepicker1' ).datepicker('show');"
  		         +"});"
  		         +"$(function() {"
  		           +  "$( '#datepicker2' ).datepicker({dateFormat:'dd-MM-yy'});"
  		            +" $( '#datepicker2' ).datepicker('show');"
  		         +" });"
  		      +"</script>");
	out.print("</head>");
		
		out.print("<html>");
		out.print("<body>");
		out.print("<form name='film' method='get' action='UpdateServlet2'>");
		out.print("<h1 align='center'>Fill The Details of Film</h1>");
		out.println("<center> "
				+ "<table>"
				+ "<tr>"
				+ "<td><label>Film Title</label></td>"
				+ "<td>:</td>"
				+ "<td><input type='text' name='title' onmouseout='return validateDetails()' value='"+film.getFilm_Title()+"'>"
				+ "<div id='titleErr'></div>"
				+ "</td>"
				+ "</tr>");
		out.print("<tr>"
				+ "<td><label>Description</label></td>"
				+ "<td>:</td>"
				+ "<td><textarea rows='4' name='desc' cols='25'>"+film.getDescreption()+"</textarea></td><"
				+ "/tr>");
		
		out.print("<tr>"
				+ "<td>Release Year</td>"
				+ "<td>:</td><td>"
				+ "	<input type='text' name='release'  id='datepicker1' value='"+df.format(film.getRelease_Year())+"' />"
				+ "</td>"
				+ "</tr>");
		

		out.print("<tr><td>Original Language</td><td>:</td>"
				+ "<td><select name='orgLang'>");
		for(Language lang:languages){
			if(lang.getLanguage_Name().equals(film.getOriginal_Language().getLanguage_Name())){
				out.print("<option value='"+lang.getLanguage_Id()+"' selected>"+lang.getLanguage_Id()+" "+lang.getLanguage_Name()+"</option>");
				
			}
			else
			out.print("<option value='"+lang.getLanguage_Id()+"'>"+lang.getLanguage_Id()+" "+lang.getLanguage_Name()+"</option>");
		}
		
		out.print("<tr>"
				+ "<td>Rental Duration</td>"
				+ "<td>:</td><td>"
				+ "	<input type='text' name='rentD'  id='datepicker2' value='"+df.format(film.getRental_Duration())+"' />"
				+ "</td>"
				+ "</tr>");
		
		out.print("<tr>"
				+ "<td>Length Of Film</td>"
				+ "<td>:</td>"
				+ "<td><input type='text' name='length' size='20' value='"+film.getLength()+"'></td>"
				+ "</tr>");
		
		out.print("<tr>"
				+ "<td>Replacement Cost</td>"
				+ "<td>:</td>"
				+ "<td><input type='text' name='cost' size='20' value='"+film.getReplacement_Cost()+"'></td>"
				+ "</tr>");
		
		out.print("<tr>"
				+ "<td>Ratings</td>"
				+ "<td>:</td>"
				+ "<td><select name='rating' onchange='return isratingSelected()'>");
			for(int i=0;i<=5;i++){
				if(i==film.getRatings()){
					out.print("<option value='"+i+"' selected>"+i+"</option>");
					}
				else
					out.print("<option value='"+i+"' >"+i+"</option>");
			}
				
				out.print( "</select></td>"
				+ "</tr>");
		
	out.print("</select></td></tr>");
		out.print("<tr>"
				+ "<td><label>Special Features:</td>"
				+ "<td>:</td>"
				+ "<td><textarea rows='4' name='spec' cols='25'>"+film.getSpecial_Features()+"</textarea></td>"
				+ "</tr>");
	
	
		
		
	//FOR CATEGORY
	out.print("<tr><td>Category</td><td>:</td>"
			+ "<td><select name='category'>"
			+ "<option value=''>Select category</option>");
	for(Category category1:category){
		if(category1.getCategory_Name().equals(film.getCategory().getCategory_Name())){
		out.print("<option value='"+category1.getCategory_Id()+"' selected>"+category1.getCategory_Id()+" "+category1.getCategory_Name()+"</option>");
		}
		else
			out.print("<option value='"+category1.getCategory_Id()+"'>"+category1.getCategory_Id()+" "+category1.getCategory_Name()+"</option>");
	}
   out.print("</select></td></tr>");

   //FOR ACTORS
	out.print("<tr><td>Actor</td><td>:</td>"
			+ "<td><select name='actor' multiple=''>"
			+ "<option value''>Select actors</option>");
	boolean flag=false;
	int id1=0;
	for(Actor actor1:actor){
		for(Actor actt:actFilm){
			
		if(actor1.getFirstName().equals(actt.getFirstName()) && actor1.getLastName().equals(actt.getLastName())){
			flag=true;
			 id1=actor1.getActor_Id();
		}
			//out.print("<option value='"+actor1.getActor_Id()+"' selected>"+actor1.getActor_Id()+" "+actor1.getActor_Fname()+" "+actor1.getActor_Lname()+"</option>");
	}
		if(flag==true && id1==actor1.getActor_Id())
			out.print("<option value='"+actor1.getActor_Id()+"' selected>"+actor1.getActor_Id()+" "+actor1.getFirstName()+" "+actor1.getLastName()+"</option>");
		else
			out.print("<option value='"+actor1.getActor_Id()+"' >"+actor1.getActor_Id()+" "+actor1.getFirstName()+" "+actor1.getLastName()+"</option>");
		
	}
	out.print("</select></td></tr>");
	
	
	
		out.print("<tr><td>Other Language</td><td>:</td>"
				+ "<td><select name='othrlang' multiple='' class='ui fluid dropdown'>"
				+ "<option value=''>Select languages</option>");
		boolean flag1=false;
		int id2=0;
		for(Language lang:languages){
			
			for(Language lng:langFilm){
				
				if(lang.getLanguage_Name().equals(lng.getLanguage_Name())){
					flag1=true;
					 id2=lang.getLanguage_Id();
				}
					//out.print("<option value='"+actor1.getActor_Id()+"' selected>"+actor1.getActor_Id()+" "+actor1.getActor_Fname()+" "+actor1.getActor_Lname()+"</option>");
			}
				if(flag1==true && id2==lang.getLanguage_Id())
					out.print("<option value='"+lang.getLanguage_Id()+"' selected>"+lang.getLanguage_Id()+" "+lang.getLanguage_Name()+"</option>");
				else
					out.print("<option value='"+lang.getLanguage_Id()+"'>"+lang.getLanguage_Id()+" "+lang.getLanguage_Name()+"</option>");
				
			
		}
	out.print("</select></td></tr>"
			+ "<tr><td><input type='hidden' name='film_id' value='"+id+"'");
	
	out.print("<tr><td></td>"
			+ "<td><input type='submit' value='Submit'</td>"
			+ "</tr>");
			
	
			
			
		
		out.print("</html");
	}
	}


