package org.film.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.film.pojo.Actor;
import org.film.pojo.Category;
import org.film.pojo.Film;
import org.film.pojo.Language;
import org.film.service.FilmService;
import org.film.service.FilmServiceImpl;

/**
 * Servlet implementation class DisplayFilmServlet
 */
public class DisplayFilmServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		FilmService filmService=new FilmServiceImpl();
		String filmid=request.getParameter("filmid");
		String title=request.getParameter("title");
		String ratings=request.getParameter("ratings");
		
		Film film1=new Film();
		
		film1.setFilm_Id(Integer.parseInt(filmid));
		film1.setFilm_Title(title);
		
		film1.setRatings(Integer.parseInt(ratings));
		
		List<Film> films=filmService.searchFilmDetails(film1);
		
		PrintWriter out=response.getWriter();
		
		out.println("<html>");
		out.println("<head>List All Films Details</head>"
				+ "<body>"
				
				
				+ "<table border='1'>"
				+ "<tr>"
				+ "<th>Film Id</th>"
				+ "<th>Title</th>"
				+ "<th>Description</th>"
				+ "<th>ReleaseYear</th>"
				+ "<th>OriginalLanguage</th>"
				+ "<th>RentalDuration</th>"
				+ "<th>Length</th>"
				+ "<th>ReplacementCost</th>"
				+ "<th>Ratings</th>"
				+ "<th>SpecialFeatures</th>"
				+ "<th>Category</th>"
				+ "<th>Languages</th>"
				+ "<th>Actors</th>"
				+ "</tr>");
		
			for(Film film:films){
				out.println("<tr>");
				out.println("<td>"+film.getFilm_Id()+"</td>");
				out.println("<td>"+film.getFilm_Title()+"</td>");
				out.println("<td>"+film.getDescreption()+"</td>");
				out.println("<td>"+film.getRelease_Year()+"</td>");
				out.println("<td>"+film.getOriginal_Language().getLanguage_Name()+"</td>");
				//out.println("<td>"+film.getOriginal_Language().getLanguage_Id()+"</td>");
				out.println("<td>"+film.getRental_Duration()+"</td>");
				out.println("<td>"+film.getLength()+"</td>");
				out.println("<td>"+film.getReplacement_Cost()+"</td>");
				out.println("<td>"+film.getRatings()+"</td>");
				out.println("<td>"+film.getSpecial_Features()+"</td>");
				out.println("<td>"+film.getCategory().getCategory_Name()+"</td>");
				out.println("<td>");
				//get multiple languages
				List<Language> languages=film.getLanguages();
						
				for(int i=0;i<languages.size();i++)
				{
					 Language lang=languages.get(i);
					out.println(""+lang.getLanguage_Name()+"");
				}
				out.println("</td>");
				
				//get multiple actors
				out.println("<td>");
				List<Actor> actors=film.getActors();
				
				for(int j=0;j<actors.size();j++)
				{
					Actor actor=actors.get(j);
					out.println(""+actor.getFirstName()+" "+actor.getLastName());
					
				}
				
				out.println("</td>");
				//out.println("<td>"+film.getCategory().getCategory_Id()+"</td>");
				out.println("</tr>");
			}
				out.println("</table></body>");
	
				out.println("</html>");
		
		
		
	
		
		
	}
		
	}


