package org.film.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.film.pojo.Actor;
import org.film.pojo.Category;
import org.film.pojo.Film;
import org.film.pojo.Language;
import org.film.service.FilmService;
import org.film.service.FilmServiceImpl;

/**
 * Servlet implementation class SaveFilmServlet
 */
public class SaveFilmServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		
		PrintWriter out=response.getWriter();
		FilmService filmService=new FilmServiceImpl();
		
		Film film=new Film();
		
		film.setFilm_Title(request.getParameter("fname"));
		film.setDescreption(request.getParameter("description"));
		
		String releaseyear=request.getParameter("releaseyear");
		Date releaseYear=new Date(releaseyear);
		film.setRelease_Year(releaseYear);
		
		//original language
		
		Language lang=new Language();
		lang.setLanguage_Id(Integer.parseInt(request.getParameter("orgLang")));
		film.setOriginal_Language(lang);
		
		//other languages
		String[] str=request.getParameterValues("otherLang");
		ArrayList<Language> languages=new ArrayList();
		for(String str1:str){
		Language language=new Language();
		language.setLanguage_Id(Integer.parseInt(str1));
		languages.add(language);
		}
		
		film.setLanguages(languages);
		
		
		//rental duration
		String rentalduration=request.getParameter("rentalduration");
		Date rentalDuration=new Date(rentalduration);
		film.setRental_Duration(rentalDuration);
		
		//length
		film.setLength(Integer.parseInt(request.getParameter("length")));
		
		film.setReplacement_Cost(Double.parseDouble(request.getParameter("replacementcost")));
		
		film.setRatings(Integer.parseInt(request.getParameter("ratings")));
		
		film.setSpecial_Features(request.getParameter("specialfeature"));
		
		//category
		Category category=new Category();
		category.setCategory_Id(Integer.parseInt(request.getParameter("category")));
		film.setCategory(category);
		
		
		//Actors
				String[] str1=request.getParameterValues("actor");
				List<Actor> actors=new ArrayList();
				for(String str2:str){
				Actor actor=new Actor();
				actor.setActor_Id(Integer.parseInt(str2));
				
				actors.add(actor);
				}
				
				film.setActors(actors);
		
		 System.out.println(film);
		//Persist employee Object into DataBase
				filmService.AddFilmServlet(film);
				
				//response.sendRedirect("SaveEmployeeServlet");
				request.getRequestDispatcher("pages/filmdetails.html").forward(request, response);
		
	
	

		
	}

}
