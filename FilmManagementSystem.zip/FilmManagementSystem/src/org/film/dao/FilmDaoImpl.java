package org.film.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.film.pojo.Actor;
import org.film.pojo.Category;
import org.film.pojo.Film;
import org.film.pojo.Language;

public class FilmDaoImpl implements FilmDao{
	
	

public Connection getConnection(){
		
		Connection connection=null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/film_management","root","Pass1234");
			
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		return connection;
	}

	
	@Override
	public void AddFilmServlet(Film film) {
	
		
			
			Connection con=getConnection();
			
			String sql="insert into film(title,description,releaseYear,rentalDuration,originalLanguage,length,replacementCost,ratings,specialFeatures,category)"+"values(?,?,?,?,?,?,?,?,?,?)";
			try {
				PreparedStatement pst=con.prepareStatement(sql);
				pst.setString(1, film.getFilm_Title());
				
				pst.setString(2, film.getDescreption());
				
				pst.setDate(3, new Date(film.getRelease_Year().getTime()));
				
				pst.setDate(4, new Date(film.getRental_Duration().getTime()));
				
				pst.setObject(5,film.getOriginal_Language().getLanguage_Id());
			
				pst.setInt(6,film.getLength());
				pst.setDouble(7, film.getReplacement_Cost());
				pst.setInt(8, film.getRatings());
				pst.setString(9, film.getSpecial_Features());
				pst.setObject(10, film.getCategory().getCategory_Id());
				
				
				
				int count=pst.executeUpdate();
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			//save data into film_actors
			String str1="select * from film order by filmid desc limit 1 ";
			
			int fid=0;
			
			try {
				PreparedStatement pst=con.prepareStatement(str1);
				ResultSet rs=pst.executeQuery();
				
				while(rs.next())
				{
				fid=rs.getInt(1);
				}
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			String str2="insert into film_actors(film_id,actor_id)values(?,?)";
			
			
			try {
				PreparedStatement pst=con.prepareStatement(str2);
				List<Actor> actors=film.getActors();
				
				
				for(Actor actor:actors)
				{
					pst.setInt(1, fid);
					pst.setObject(2,actor.getActor_Id());
					int count=pst.executeUpdate();
				}
				
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			
			//save data into film_language
			String str3="select * from film order by filmid desc limit 1 ";
			
			int filmid=0;
			
			try {
				PreparedStatement pst=con.prepareStatement(str3);
				ResultSet rs=pst.executeQuery();
				
				while(rs.next())
				{
				fid=rs.getInt(1);
				}
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			String str4="insert into film_language(film_id,language_id) values(?,?)";
			
			
			try {
				PreparedStatement pst=con.prepareStatement(str4);
				List<Language> languages=film.getLanguages();
				
				for(Language lang:languages)
				{
					pst.setInt(1, fid);
					pst.setObject(2,lang.getLanguage_Id());
					System.out.println(lang.getLanguage_Id());
					int count=pst.executeUpdate();
				}
				//System.out.println(languages);
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			
			
		}


	@Override

	public List<Language> getAllLanguages() {
		List<Language> languages=new ArrayList<>();
		String str="select * from language";
		Connection con=getConnection();
		
		try {
			PreparedStatement pst=con.prepareStatement(str);
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				Language lang=new Language();
				lang.setLanguage_Id(rs.getInt(1));
				lang.setLanguage_Name(rs.getString(2));
				
				
				
				
				//Adding the customer into arraylist
				languages.add(lang);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return languages;
	}


	@Override
	public List<Actor> getAllActors() {
		List<Actor> actors=new ArrayList<>();
		String str="select * from actors";
		Connection con=getConnection();
		
		try {
			PreparedStatement pst=con.prepareStatement(str);
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				Actor actor=new Actor();
				actor.setActor_Id(rs.getInt(1));
				actor.setFirstName(rs.getString(2));
				actor.setLastName(rs.getString(3));
				
				
				
				
				//Adding the customer into arraylist
				actors.add(actor);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return actors;
	}


	@Override
	public List<Category> getAllCategories() {
		List<Category> categories=new ArrayList<>();
		String str="select * from category";
		Connection con=getConnection();
		
		try {
			PreparedStatement pst=con.prepareStatement(str);
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				Category category=new Category();
				category.setCategory_Id(rs.getInt(1));
				category.setCategory_Name(rs.getString(2));
			   
				
				
				
				
				//Adding the customer into arraylist
				categories.add(category);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return categories;
	}


	@Override
	public List<Film> getAllFilmDetails() {
		
		List<Film> films=new ArrayList<>();
		
		Connection con=getConnection();
		
		String sql="select film.filmid,film.title,film.description,film.releaseYear,language.language_name,film.rentalDuration,film.length,film.replacementCost,film.ratings,film.specialFeatures,category.category_name from film join category on(film.category=category.category_id) join language on(film.originalLanguage=language.language_Id)";
		
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			ResultSet rs=pst.executeQuery();
	
			while(rs.next())
			{
				Film film=new Film();
				
				film.setFilm_Id(rs.getInt(1));
				film.setFilm_Title(rs.getString(2));
				film.setDescreption(rs.getString(3));
				film.setRelease_Year(rs.getDate(4).valueOf(rs.getDate(4).toString()));
				
				Language lang=new Language();
				lang.setLanguage_Name(rs.getString(5));
				//lang.setLanguage_Id(rs.getInt(5));
				film.setOriginal_Language(lang);
				
				film.setRental_Duration(rs.getDate(6).valueOf(rs.getDate(6).toString()));
				film.setLength(rs.getInt(7));
				film.setReplacement_Cost(rs.getDouble(8));
				film.setRatings(rs.getInt(9));
				film.setSpecial_Features(rs.getString(10));
				
				Category category=new Category();
				category.setCategory_Name(rs.getString(11));
				//category.setCategory_Id(rs.getInt(11));
				film.setCategory(category);
				//get multiple languages
				List<Language> languages=getLanguage(rs.getInt(1));
				film.setLanguages(languages);
				
				//get multiple actors
				List<Actor> actors=getActors(rs.getInt(1));
				film.setActors(actors);
				
				films.add(film);
				System.out.println(film);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return films;
	}

	public List<Language> getLanguage(int filmId)
	{
		List<Language> languages=new ArrayList<>();
		int filmid=filmId;
		String sql="select language.language_Id,language.language_name from language where language_Id in(select language_id from film_language where film_id=" + filmid +")";

		
		Connection con=getConnection();
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				Language lang=new Language();
				lang.setLanguage_Id(rs.getInt(1));
				lang.setLanguage_Name(rs.getString(2));
				languages.add(lang);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return languages;
		
	}
	
	
	
	//get multiple actors
	
	public List<Actor> getActors(int filmId)
	{
		List<Actor> actors=new ArrayList<>();
		int filmid=filmId;
		String sql="select actors.actor_id,actors.firstName,actors.lastName from actors where actor_id in(select actor_id from film_actors where film_id=" + filmid +")";

		
		Connection con=getConnection();
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				Actor actor=new Actor();
				actor.setActor_Id(rs.getInt(1));
				actor.setFirstName(rs.getString(2));
				actor.setLastName(rs.getString(3));
				
				actors.add(actor);
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return actors;
		
	}
	

	@Override
	public List<Film> searchFilmDetails(Film film) {

		System.out.println(film);
         List<Film> films=new ArrayList<>();
         
         String sql="select * from film where ";
         sql+="filmid=?";
         System.out.println(sql);
         if(film!=null)
         {
        	 if(film.getFilm_Title()!=null && film.getFilm_Title().length()!=0)
        	 {
        		 sql+=" and title=? ";
        	 }
        	 else
        	 {
        		 sql+="";
        	 }
        	 //System.out.println(sql);
         }
         sql+=" and ratings=?";
        
         System.out.println(sql);
         try {
			PreparedStatement pst=getConnection().prepareStatement(sql);
			pst.setInt(1, film.getFilm_Id());
			
			 if(film.getFilm_Title()!=null && film.getFilm_Title().length()!=0)
			  pst.setString(2,film.getFilm_Title());
			 
			 pst.setInt(2, film.getRatings());
			 
			 ResultSet rs=pst.executeQuery();
			 
			 while(rs.next())
			 {
				 Film film1=new Film();
				 film1.setFilm_Id(rs.getInt(1));
				 film1.setFilm_Title(rs.getString(2));
				 film1.setDescreption(rs.getString(3));
					film.setRelease_Year(rs.getDate(4).valueOf(rs.getDate(4).toString()));
					
					Language lang=new Language();
					lang.setLanguage_Id(rs.getInt(5));
					film1.setOriginal_Language(lang);
					
					film1.setRental_Duration(rs.getDate(6).valueOf(rs.getDate(6).toString()));
					film1.setLength(rs.getInt(7));
					film1.setReplacement_Cost(rs.getDouble(8));
					film1.setRatings(rs.getInt(9));
					film1.setSpecial_Features(rs.getString(10));
					
					Category category=new Category();
					category.setCategory_Id(rs.getInt(11));
					film1.setCategory(category);
					
					//get multiple languages
					List<Language> languages=getLanguage(rs.getInt(1));
					film1.setLanguages(languages);
					
					//get multiple actors
					List<Actor> actors=getActors(rs.getInt(1));
					film1.setActors(actors);
					
					
					
					films.add(film1);
					
					System.out.println(films);
			 }
			 
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
         //System.out.println(films);
		return films;
	}


	@Override
	public boolean deleteFilmDetails(int filmid) {
		
		
		boolean flag=false;
		String sql="delete from film where filmid=?";
		
		
		   	 try {
					PreparedStatement pst= getConnection().prepareStatement(sql);
				
				pst.setInt(1,filmid);
				 
				 
				 int count=pst.executeUpdate();
				 

					if(count>0)
						flag=true;
					
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		
		return flag;
	}

/*
	@Override
	public boolean updateFilmDetails(Film film) {
		
		boolean flag=false;
		String sql="update from film set where filmid=?";
		
		
		   	 try {
					PreparedStatement pst= getConnection().prepareStatement(sql);
				
				pst.setInt(1,filmid);
				 
				 
				 int count=pst.executeUpdate();
				 

					if(count>0)
						flag=true;
					
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		
		return flag;
	}*/


	
}


