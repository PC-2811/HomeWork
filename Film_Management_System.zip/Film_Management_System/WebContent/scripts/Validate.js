
function validateField1(){
	
	//validation for title
	var flag=true;
	//var filmname=film.fname.value;
	
	var filmtitle=film.fname.value;
	var letters = /^[A-Za-z]+$/; 
	if(!filmtitle.match(letters)||filmtitle==""||filmtitle==null)  
	{  
		document.getElementById("titleErr").innerHTML="*Title is mandatory and should only contain alphabet"; 
		filmtitle.focus(); 
		return true;  
	}  
	else  
	{  
		document.getElementById("titleErr").innerHTML="";
		 
		return false;  
	}  
}		
	/*	
		//validation for ratings
	var rating=film.ratings.value;
	
	if(rating<=0 || rating>=5 )
		{
		  
          document.getElementById("ratingsErr").innerHTML="*Invalid Ratings.Please enter ratings fom 1 t0 5" ;
		
		flag=false;
		}else
			document.getElementById("ratingsErr").innerHTML="";
	
	*/
	//validation for length
	function validateField2(){
		var flag=true;
	var length=film.length.value;
	
	if(length<=0 || length>1000)
		{
		 document.getElementById("lengthErr").innerHTML="*Invalid Length.Please enter length from 1 to 1000" ;
			
			flag=false;
			}else
				{
				document.getElementById("lengthErr").innerHTML="";
	    return flag;
				}
}
		
	
	//validation for rental duration
	function validateField3(){
		var flag=true;
	var releaseyear=film.releaseyear.value;
	var rentalduration=film.rentalduration.value;
	
	if(releaseyear>=rentalduration)
		{
		 document.getElementById("rentaldurationErr").innerHTML="*Invalid Rental Duration.Rental Duration should be greater than Release Year" ;
	
	flag=false;
	}else
		{
		document.getElementById("rentaldurationErr").innerHTML="";
	
	return flag;
	}
}


function displayFilmDetails(){
//alert("hello");
var filmid1=f1.filmid.value;	

var title1=f1.title.value;
var ratings1=f1.ratings.value;
	
	//Ajax Code 
	var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4) {
            var data = xhr.responseText;
             document.getElementById('displayFilm').innerHTML=data;
        }
    }
    xhr.open('GET', 'DisplayFilmServlet?filmid='+filmid1 +'&title='+title1  +'&ratings='+ratings1, true);
  
    xhr.send(null);
	
   
}