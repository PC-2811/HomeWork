package org.capgemini.fms.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.capgemini.fms.pojo.Film;
import org.capgemini.fms.service.FilmService;
import org.capgemini.fms.service.FilmServiceImpl;

/**
 * Servlet implementation class DeleteFilmServlet2
 */
public class DeleteFilmServlet2 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		FilmService filmService=new FilmServiceImpl();
        
        String empid=request.getParameter("empid");
		Film film=new Film();
		
	
		boolean flag=filmService.deleteAllFilms(Integer.parseInt(empid));
		
		if(flag){
			request.getRequestDispatcher("DeleteFilmServlet").forward(request, response);
		}
		
	}
	

}
