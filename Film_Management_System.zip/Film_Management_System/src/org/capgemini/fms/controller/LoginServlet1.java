package org.capgemini.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.capgemini.fms.pojo.LoginUser;
import org.capgemini.fms.service.FilmService;
import org.capgemini.fms.service.FilmServiceImpl;

/**
 * Servlet implementation class LoginServlet1
 */
public class LoginServlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
PrintWriter out=response.getWriter();
		
		String userName=request.getParameter("uname");
		String userPwd=request.getParameter("upwd");
		
		LoginUser loginUser=new LoginUser();
		loginUser.setUserName(userName);
		loginUser.setUserPwd(userPwd);
		
		
		FilmService filmService=new FilmServiceImpl();
		
		
		
		if(filmService.isValidLogin(loginUser)){
			//response.sendRedirect("pages/success.html");
			

			//HttpSession session=request.getSession(true);
			
			//session.setAttribute("userName", loginUser.getUserName());
				
			
			request.getRequestDispatcher("../pages/filmdetails.html").forward(request, response);
			
		}//else
			//response.sendRedirect("../pages/Login.html");
		
	}
}
