package org.capgemini.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.capgemini.fms.pojo.Actor;
import org.capgemini.fms.pojo.Category;
import org.capgemini.fms.pojo.Film;
import org.capgemini.fms.pojo.Language;
import org.capgemini.fms.service.FilmServiceImpl;

/**
 * Servlet implementation class UpdateFilmServlet3
 */
public class UpdateServlet2 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
PrintWriter out=response.getWriter();
		
		int filmid=Integer.parseInt(request.getParameter("film_id"));
		  FilmServiceImpl filmService=new FilmServiceImpl();
		  Film film=new Film();
		  
		  film.setFilmTitle(request.getParameter("title"));
		  film.setDescription(request.getParameter("desc"));
		  

			/*String releaseyear=request.getParameter("release");
			System.out.println(releaseyear+"before ");
			Date relDate=new Date(releaseyear);
		    
			film.setRelease_Year(relDate);*/
		  
		 
		  
		  film.setReleaseYear(new Date(request.getParameter("release")));
		  film.setSpecialFeatures(request.getParameter("spec"));
		  film.setLength(Integer.parseInt(request.getParameter("length")));
		  film.setReplacementCost(Double.parseDouble(request.getParameter("cost")));
		  film.setRatings(Integer.parseInt(request.getParameter("rating")));
		  
		  /*String rentalduration=request.getParameter("rentD");
			Date rentalDuration=new Date(rentalduration);
			film.setRental_Duration(rentalDuration);*/
		  
		  film.setRentalDuration(new Date(request.getParameter("rentD")));
		  
		  Language lang=new Language();
		  lang.setLanguageId(Integer.parseInt(request.getParameter("orgLang")));
		  film.setOriginal_Language(lang);
		  
		  
		  Category category=new Category();
		  category.setCategory_Id(Integer.parseInt(request.getParameter("category")));
		  film.setCategory(category);
		  
		
		  
		  String [] actors=request.getParameterValues("actor");
		  List<Actor> actor1=new ArrayList<>();
		  
		  for(String str:actors){
			  Actor act=new Actor();
			  act.setActor_Id(Integer.parseInt(str));
			  actor1.add(act);
			  
		  }
		   film.setActors(actor1);
		   
		   
		   String [] lang1=request.getParameterValues("othrlang");
		   List<Language> langs=new ArrayList<>();
		   for(String lang2:lang1)
		   {
			   Language lang3=new Language();
			   lang3.setLanguageId(Integer.parseInt(lang2));
			   langs.add(lang3);
		   }
		  film.setLanguages(langs);
		   System.out.println("update");
		   System.out.println(filmid);
		   System.out.println(film);
		   
		  int c= filmService.updateFilmDetails(filmid, film);
		  if(c>0)
			 
			  //request.getRequestDispatcher("EditServlet").forward(request, response);
			  
			  response.sendRedirect("UpdateServlet");
	}

}
