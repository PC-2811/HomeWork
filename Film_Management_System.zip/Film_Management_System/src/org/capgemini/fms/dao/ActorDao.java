package org.capgemini.fms.dao;

import java.util.List;

import org.capgemini.fms.pojo.Actor;

public interface ActorDao {

	public List<Actor>addActor();

	List<Actor> getActorList();
}
