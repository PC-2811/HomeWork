package org.capgemini.fms.dao;

import java.util.List;

import org.capgemini.fms.pojo.Actor;
import org.capgemini.fms.pojo.Category;
import org.capgemini.fms.pojo.Film;
import org.capgemini.fms.pojo.Language;
import org.capgemini.fms.pojo.LoginUser;

public interface FilmDao {
	public void AddFilmServlet(Film film);
	public List<Language> getAllLanguages();
	public List<Actor> getAllActors();
	public List<Category> getAllCategories();
	public List<Film> getAllFilms();
	public List<Film> searchAllFilms(Film film);
	public boolean deleteAllFilms(int filmid);
	//public boolean updateFilmDetails(int filmid);
	public int updateFilmDetails(int filmid,Film film);
	public Film getSearchFilmByID(int id);
	public boolean isValidLogin(LoginUser loginUser) ;

}
