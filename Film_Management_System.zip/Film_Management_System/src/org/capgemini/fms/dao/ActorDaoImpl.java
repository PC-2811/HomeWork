package org.capgemini.fms.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.capgemini.fms.pojo.Actor;

public class ActorDaoImpl implements ActorDao{
	@Override
	public List<Actor> getActorList() {
		List<Actor> actor=new ArrayList<>();
		
		FilmDaoImpl filmDao=new FilmDaoImpl();
		Connection con=filmDao.getConnection();
		
		String sql="select * from actors";
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			ResultSet rs=pst.executeQuery();
			
			while(rs.next())
			{
				Actor actor1=new Actor();
				actor1.setActor_Id(rs.getInt(1));
				actor1.setFirstName(rs.getString(2));
				actor1.setLastName(rs.getString(3));
				actor.add(actor1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return actor;
	}

	@Override
	public List<Actor> addActor() {
		// TODO Auto-generated method stub
				return getActorList();
	}

	
//	
//public static Connection getConnection(){
//		
//		Connection connection=null;
//		
//		try {
//			Class.forName("com.mysql.jdbc.Driver");
//		System.out.println("connection essablished");
//			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/film_management","root","Pass1234");
//			System.out.println("Driver Registered");
//			
//		} catch (ClassNotFoundException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		
//		return connection;
//	}
//	
}
