package org.capgemini.fms.service;

import java.util.List;


import org.capgemini.fms.dao.FilmDao;
import org.capgemini.fms.dao.FilmDaoImpl;
import org.capgemini.fms.pojo.Actor;
import org.capgemini.fms.pojo.Category;
import org.capgemini.fms.pojo.Film;
import org.capgemini.fms.pojo.Language;

public class FilmServiceImpl implements FilmService{

	FilmDao filmDao=new FilmDaoImpl();
	
	@Override
	public void AddFilmServlet(Film film) {
		
		filmDao.AddFilmServlet(film);
	}

	@Override
	public List<Language> getAllLanguages() {
		// TODO Auto-generated method stub
		return filmDao.getAllLanguages();
	}

	@Override
	public List<Actor> getAllActors() {
		// TODO Auto-generated method stub
		return filmDao.getAllActors();
	}

	@Override
	public List<Category> getAllCategories() {
		// TODO Auto-generated method stub
		return filmDao.getAllCategories();
	}

	@Override
	public List<Film> getAllFilms() {
		
		return filmDao.getAllFilms();
	}

	@Override
	public List<Film> searchAllFilms(Film film) {
		// TODO Auto-generated method stub
		return filmDao.searchAllFilms(film);
	}

	@Override
	public boolean deleteAllFilms(int filmid) {
		// TODO Auto-generated method stub
		return filmDao.deleteAllFilms(filmid);
	}
	@Override
	public int updateFilmDetails(int filmid, Film film) {
		// TODO Auto-generated method stub
		return filmDao.updateFilmDetails(filmid, film);
	}
	
	public Film getSearchFilmByID(int id) {
		// TODO Auto-generated method stub
		return filmDao.getSearchFilmByID(id);
	}

}
