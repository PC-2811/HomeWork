package org.capgemini.fms.service;

import java.util.List;

import org.capgemini.fms.pojo.Actor;

public interface ActorService {

	public List<Actor>addActor();

	List<Actor> getActorList();

}
