package org.capgemini.fms.pojo;

import java.util.Date;
import java.util.List;

public class Film {
	
	//private fields
			private int filmId;
			private String description;
			private String filmTitle;
		    private Date releaseYear;
			private List<Language> languages;
			private Language original_Language;
			private Date rentalDuration;
			private int length;
			private double replacementCost;
			private int ratings;
			private String specialFeatures;
			private List<Actor> actors;
			private Category category;
			
			
			
			//No argument constructor
			public Film(){}


//Constructer with fields
			public Film(int filmId, String description, String filmTitle, Date releaseYear, List<Language> languages,
					Language original_Language, Date rentalDuration, int length, double replacementCost, int ratings,
					String specialFeatures, List<Actor> actors, Category category) {
				super();
				this.filmId = filmId;
				this.description = description;
				this.filmTitle = filmTitle;
				this.releaseYear = releaseYear;
				this.languages = languages;
				this.original_Language = original_Language;
				this.rentalDuration = rentalDuration;
				this.length = length;
				this.replacementCost = replacementCost;
				this.ratings = ratings;
				this.specialFeatures = specialFeatures;
				this.actors = actors;
				this.category = category;
			}


			
			
			
			
			//Getters and Setters
			public int getFilmId() {
				return filmId;
			}


			public void setFilm_Id(int filmId) {
				this.filmId = filmId;
			}


			public String getDescription() {
				return description;
			}


			public void setDescription(String description) {
				this.description = description;
			}


			public String getFilmTitle() {
				return filmTitle;
			}


			public void setFilmTitle(String filmTitle) {
				this.filmTitle = filmTitle;
			}


			public Date getReleaseYear() {
				return releaseYear;
			}


			public void setReleaseYear(Date releaseYear) {
				this.releaseYear = releaseYear;
			}


			public List<Language> getLanguages() {
				return languages;
			}


			public void setLanguages(List<Language> languages) {
				this.languages = languages;
			}


			public Language getOriginal_Language() {
				return original_Language;
			}


			public void setOriginal_Language(Language original_Language) {
				this.original_Language = original_Language;
			}


			public Date getRentalDuration() {
				return rentalDuration;
			}


			public void setRentalDuration(Date rentalDuration) {
				this.rentalDuration = rentalDuration;
			}


			public int getLength() {
				return length;
			}


			public void setLength(int length) {
				this.length = length;
			}


			public double getReplacementCost() {
				return replacementCost;
			}


			public void setReplacementCost(double replacementCost) {
				this.replacementCost = replacementCost;
			}


			public int getRatings() {
				return ratings;
			}


			public void setRatings(int ratings) {
				this.ratings = ratings;
			}


			public String getSpecialFeatures() {
				return specialFeatures;
			}


			public void setSpecialFeatures(String specialFeatures) {
				this.specialFeatures = specialFeatures;
			}


			public List<Actor> getActors() {
				return actors;
			}


			public void setActors(List<Actor> actors) {
				this.actors = actors;
			}


			public Category getCategory() {
				return category;
			}


			public void setCategory(Category category) {
				this.category = category;
			}

//toString method
			@Override
			public String toString() {
				return "Film [filmId=" + filmId + ", description=" + description + ", filmTitle=" + filmTitle
						+ ", releaseYear=" + releaseYear + ", languages=" + languages + ", original_Language="
						+ original_Language + ", rentalDuration=" + rentalDuration + ", length=" + length
						+ ", replacementCost=" + replacementCost + ", ratings=" + ratings + ", specialFeatures="
						+ specialFeatures + ", actors=" + actors + ", category=" + category + "]";
			}
			
			
			
			
			
			
			
			
}
