/* The FilmDaoForDB class contains various methods that interact with the database layer*/

package com.flp.fms.dao;
import java.sql.Connection;
import java.sql.*;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;


public class FilmDaoImplForDB implements IFilmDao 
{

	//*****************************************************************************

		

	

	//*****************************************************************************

	// Save the Film Details into the Film Database
	/* Method to insert the film data into the Film Table and Actor and Language details into the third party table*/	


	public void saveFilm(Film film)
	{
		ConnectionClass connclass=new ConnectionClass();
		Connection con=connclass.getConnection();

		String sql="INSERT INTO film (title,description,releaseyear,originalLanguage,rentalDuration,LENGTH,replacementCost,ratings,specialFeatures,category)"
				+ "	 values(?,?,?,?,?,?,?,?,?,?)";

		int id = 0;
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			pst.setString(1, film.getTitle());
			pst.setString(2, film.getDescription());
			pst.setDate(3,new Date(film.getRelease_Date().getTime()));
			pst.setInt(4,film.getOriginalLanguage().getLanguage_Id());
			pst.setDate(5,new Date(film.getRental_Duration().getTime()));
			pst.setInt(6, film.getLength());
			pst.setDouble(7, film.getReplacement_Cost());
			pst.setInt(8, film.getRatings());
			pst.setString(9, film.getSpecial_Features());
			pst.setInt(10, film.getCategory().getCategory_Id());
			int count=pst.executeUpdate();

			// Extract the id of the Title inserted

			Connection con1=connclass.getConnection();
			String sql1="Select filmid from film where Title = ?";
			PreparedStatement pst1=con1.prepareStatement(sql1);				
			pst1.setString(1,film.getTitle());
			ResultSet rs=pst1.executeQuery();

			if(rs.next())
				id = rs.getInt(1);


		} 
		catch (SQLException e)
		{

			e.printStackTrace();
		}		
		//*****************************************************************************
		// Add multiple languages into the third party table

		try {
			int count = 0;
			for(Language language: film.getLanguages()){

				String sql1="INSERT INTO film_language (film_id,language_Id)"
						+ "	 values(?,?)";

				PreparedStatement pst=con.prepareStatement(sql1);
				pst.setInt(1, id);
				pst.setInt(2, language.getLanguage_Id());
				int count1=pst.executeUpdate();

			}
		} 
		catch (Exception e) {}
		//*****************************************************************************

		// Add multiple Actors into the third party table	

		try {
			int count = 0;

			for(Actor actor: film.getActors())
			{

				String sql1="INSERT INTO film_actors (film_id,actor_id)"
						+ "	 values(?,?)";
				PreparedStatement pst=con.prepareStatement(sql1);
				pst.setInt(1, id);
				pst.setInt(2, actor.getActor_Id());
				int count1=pst.executeUpdate();
			}
			con.close();
		} 
		catch (Exception e) {}
	}

	//*****************************************************************************

	//Get All the data from the film table

	public ArrayList<Film> getAllFilms() 
	{
		ArrayList<Film> filmdetailsList=new ArrayList<>();

		String sql="SELECT film.filmid,film.title,film.description,film.releaseYear,language.language_name,film.rentalDuration,film.length,film.replacementCost,film.ratings,film.specialFeatures,category.category_name FROM film,category,LANGUAGE WHERE category.category_id = film.category AND language.language_Id = film.originalLanguage";
		ConnectionClass connclass=new ConnectionClass();
		Connection con=connclass.getConnection();
		try  
		{
			PreparedStatement pst=con.prepareStatement(sql);
			System.out.println("Inside Execution");	
			ResultSet rs=pst.executeQuery();	

			while(rs.next())
			{
				Film film = new Film();

				film.setFilm_Id(rs.getInt(1));
				film.setTitle(rs.getString(2));
				film.setDescription(rs.getString(3));
				film.setRelease_Date(rs.getDate(4));

				Language lang = new Language();
				lang.setLanguage_Name(rs.getString(5));
				film.setOriginalLanguage(lang);

				film.setRental_Duration(rs.getDate(6));
				film.setLength(rs.getInt(7));
				film.setReplacement_Cost(rs.getDouble(8));
				film.setRatings(rs.getInt(9));
				film.setSpecial_Features(rs.getString(10));

				Category catg = new Category();
				catg.setCategory_Name(rs.getString(11));
				film.setCategory(catg);		

				filmdetailsList.add(film); 

			}
			con.close();


		} 
		catch (SQLException e)
		{

			e.printStackTrace();
		}

		return filmdetailsList;

	}
	//*****************************************************************************

	//Function to get all the languages of the film.

	public ArrayList<Language> getLanguage(int fid) 
	{
		ArrayList<Language> filmdetailsList=new ArrayList<>();

		ConnectionClass connclass=new ConnectionClass();
		Connection con=connclass.getConnection();
		try 
		{
			String sql2 = "SELECT language.language_name FROM LANGUAGE WHERE language.language_Id IN(SELECT film_language.language_id FROM film_language WHERE film_language.film_id =?)";
			PreparedStatement pst1=con.prepareStatement(sql2);
			pst1.setInt(1, fid);
			ResultSet rs1=pst1.executeQuery();
			while(rs1.next())
			{
				Language lang = new Language();		
				lang.setLanguage_Name(rs1.getString(1));			
				filmdetailsList.add(lang);
			}
			con.close();


		} 
		catch (SQLException e)
		{

			e.printStackTrace();
		}

		return filmdetailsList;

	}
	//*****************************************************************************

	//Function to get all the Actors of the film.

	public ArrayList<Actor> getActor(int fid) 
	{

		ArrayList<Actor> filmdetailsList=new ArrayList<>();
		ConnectionClass connclass=new ConnectionClass();
		Connection con=connclass.getConnection();
		try {
			
			//String sql2 = "SELECT  * FROM actors WHERE actors.actor_id IN(SELECT film_actors.actor_id FROM film_actors WHERE film_actors.film_id =?)";
String sql2 = "SELECT  * FROM actors where film_id=?";
			PreparedStatement pst1=con.prepareStatement(sql2);
			pst1.setInt(1, fid);
			ResultSet rs1=pst1.executeQuery();

			while(rs1.next())
			{
				Actor actor = new Actor();
				actor.setFirst_Name(rs1.getString(1));
				actor.setLast_Name(rs1.getString(2));
				filmdetailsList.add(actor);	

			}

			con.close();

		}
		catch (SQLException e) 
		{

			e.printStackTrace();
		}
		return filmdetailsList;

	}

	//******************************************************************************
	//Extract all the Actor data from database

	public ArrayList<Actor> getAllActor() 
	{
		ArrayList<Actor> actorList=new ArrayList<>();

		String sql="SELECT * FROM actors ";
		ConnectionClass connclass=new ConnectionClass();

		Connection con=connclass.getConnection();
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			ResultSet rs=pst.executeQuery();

			while(rs.next())
			{
				Actor actor=new Actor();
				actor.setActor_Id(rs.getInt(1));
				actor.setFirst_Name(rs.getString(2));
				actor.setLast_Name(rs.getString(3));
				//Adding Actor into List
				actorList.add(actor);
			}

			con.close();
		} 
		catch (SQLException e)
		{

			e.printStackTrace();
		}


		return actorList;
	}

	//******************************************************************************

	//Extract FilmId data from database

	public ArrayList<Film> getAllFilmId() 
	{
		ArrayList<Film> filmList=new ArrayList<>();

		String sql="SELECT filmid FROM film";		
		ConnectionClass connclass=new ConnectionClass();

		Connection con=connclass.getConnection();
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			ResultSet rs=pst.executeQuery();

			while(rs.next())
			{
				Film film = new Film();
				film.setFilm_Id(rs.getInt(1));
				//Adding Actor into List
				filmList.add(film);
			}
			con.close();
		} 
		catch (SQLException e) 
		{

			e.printStackTrace();
		}


		return filmList;
	}
	//******************************************************************************

	//Extract all the Languages  from database


	public ArrayList<Language> getAllLanguage() 
	{
		ArrayList<Language> languageList=new ArrayList<>();

		String sql="SELECT * FROM LANGUAGE ORDER BY language_name ASC";
		ConnectionClass connclass=new ConnectionClass();

		Connection con=connclass.getConnection();
		try 
		{
			PreparedStatement pst=con.prepareStatement(sql);
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				Language lang = new Language();
				lang.setLanguage_Id(rs.getInt(1));
				lang.setLanguage_Name(rs.getString(2));
				//Adding Language into List
				languageList.add(lang);

			}
			con.close();


		}
		catch (SQLException e) 
		{

			e.printStackTrace();
		}


		return languageList;
	}
	//******************************************************************************
	//Extract All the Category  from database to display on Add Servlet drop down

	public ArrayList<Category> getAllCategory()
	{

		ArrayList<Category> categoryList=new ArrayList<>();

		String sql="SELECT * FROM category ORDER BY category_name";
		ConnectionClass connclass=new ConnectionClass();

		Connection con=connclass.getConnection();
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			ResultSet rs=pst.executeQuery();

			while(rs.next())
			{
				Category categ = new Category();
				categ.setCategory_Id(rs.getInt(1));
				categ.setCategory_Name(rs.getString(2));

				//Adding Language into List

				categoryList.add(categ);
			}

		} 
		catch (SQLException e) 
		{

			e.printStackTrace();
		}


		return categoryList;


	}

	//**************************************************************************
	// Function to get all the languages of the film into the control from database

	public ArrayList<Language> getLanguageList(int fid)
	{		
		ArrayList<Language> filmdetails=new ArrayList<>();
		ConnectionClass connclass=new ConnectionClass();

		Connection con=connclass.getConnection();

		try {			

			String sql2 = "SELECT language.language_name FROM LANGUAGE WHERE language.language_Id IN(SELECT film_language.language_id FROM film_language WHERE film_language.film_id =?)";


			PreparedStatement pst1=con.prepareStatement(sql2);
			pst1.setInt(1, fid);			
			ResultSet rs1=pst1.executeQuery();			

			while(rs1.next())
			{			

				Language lang = new Language();		
				lang.setLanguage_Name(rs1.getString(1));
				filmdetails.add(lang);			
			}


		} 
		catch (SQLException e) 
		{

			e.printStackTrace();
		}


		return filmdetails;

	}
	//********************************************************************************
	//Function to get all the Actors of the film.

	public ArrayList<Actor> getActorList(int fid) {



		ArrayList<Actor> filmdetails=new ArrayList<>();
		
		ConnectionClass connclass=new ConnectionClass();
Connection con=connclass.getConnection();

		try 
		{


			String sql2 = "SELECT  actors.firstName , actors.lastName FROM actors WHERE actors.actor_id IN(SELECT film_actors.actor_id FROM film_actors WHERE film_actors.film_id =?)";		
			PreparedStatement pst1=con.prepareStatement(sql2);
			pst1.setInt(1, fid);			
			ResultSet rs1=pst1.executeQuery();		

			while(rs1.next())
			{				

				Actor actor = new Actor();
				actor.setFirst_Name(rs1.getString(1));
				actor.setLast_Name(rs1.getString(2));	      
				filmdetails.add(actor);					


			}


		} 
		catch (SQLException e) 
		{

			e.printStackTrace();
		}


		return filmdetails;

	}

	//*********************************************************************************
	// Function to perform search in the film database based on various parameters.

	public ArrayList<Film> searchAllFilm(Film film,String categoryValue,String language,int Actor)
	{


		ArrayList<Film> filmlist=new ArrayList<>();

		int count=0;
		int flag=0;


		String sql="select * from film where";	


		if(film!=null){

			//Title
			if(film.getTitle()!=null){

				sql+=" title='" +film.getTitle()+"'" ;
				count=count+1;
			}else
			{
				sql+="";
			}

			//FilmId

			if(film.getFilm_Id()!=0){

				if(count!=0)
				{sql+=" and";}

				sql+=" filmid='" +film.getFilm_Id()+"'" ;
				count=count+1;
			}else
			{
				sql+="";
			}



			//Ratings


			if(film.getRatings()!=0)
			{

				if(count!=0)
				{sql+=" and";}

				sql+=" ratings="+film.getRatings();	
				count=count+1;


			}else
			{
				sql+="";
			}

			//Category


			if(categoryValue!=null)
			{

				if(count!=0)
				{sql+=" and";}

				sql+="   film.category IN (SELECT category.category_id FROM category WHERE category.category_name = '"+categoryValue+"')";
				count=count+1;


			}else
			{
				sql+="";
			}

			// Search for Language

			if(language!=null&&flag==0)
			{

				if(count!=0)
				{sql+=" and";}

				sql+="  originallanguage IN (SELECT language.language_Id FROM LANGUAGE WHERE language.language_name = '"+language+"') OR film.filmid IN(SELECT film_language.film_id FROM film_language WHERE film_language.language_id IN(SELECT language.language_Id FROM LANGUAGE WHERE language.language_name like '"+language+"'))";



				count=count+1;


			}else
			{
				sql+="";
			}

			// Search for Actors

			if(Actor!=0)
			{

				if(count!=0)
				{sql+=" and";}

				sql+="  filmid IN (SELECT film_actors.film_id FROM film_actors WHERE film_actors.actor_id IN (SELECT actors.actor_id FROM actors WHERE actor_id = "+Actor+") )";
				count=count+1;


			}else
			{
				sql+="";
			}
		}

		try {
			ConnectionClass connclass=new ConnectionClass();

			PreparedStatement pst=connclass.getConnection().prepareStatement(sql);

			System.out.println(sql);
			ResultSet rs=pst.executeQuery();

			while(rs.next()){
				Film film1 = new Film();
				film1.setFilm_Id(rs.getInt(1));
				film1.setTitle(rs.getString(2));
				film1.setDescription(rs.getString(3));
				film1.setRelease_Date(rs.getDate(4));
				Language lang = new Language();
				lang.setLanguage_Name(rs.getString(5));
				film1.setOriginalLanguage(lang);
				film1.setRental_Duration(rs.getDate(6));
				film1.setLength(rs.getInt(7));
				film1.setReplacement_Cost(rs.getDouble(8));
				film1.setRatings(rs.getInt(9));
				film1.setSpecial_Features(rs.getString(10));
				Category catg = new Category();
				catg.setCategory_Name(rs.getString(11));
				film1.setCategory(catg);

				filmlist.add(film1);
			}


		} 
		catch (SQLException e) 
		{

			e.printStackTrace();
		}


		return filmlist;

	}

	//**************************************************************************
	// Method to Delete the records in the Film Table and the third pary table

	public boolean deleteFilm(int filmId)
	{
		ConnectionClass connclass=new ConnectionClass();

		Connection con=connclass.getConnection();		
		boolean flag=false;

		String sql="delete from film where filmid =?";
		String sql1="delete from film_language where film_id = ?";
		String sql2="delete from film_actors where film_id = ?";

		try {
			PreparedStatement pst=con.prepareStatement(sql);
			PreparedStatement pst1=con.prepareStatement(sql1);
			PreparedStatement pst2=con.prepareStatement(sql2);
			pst.setInt(1, filmId);
			pst1.setInt(1, filmId);
			pst2.setInt(1, filmId);            
			int count=pst.executeUpdate();
			int count1=pst1.executeUpdate();
			int count2=pst2.executeUpdate();

			if(count>0||count1>0||count>0)
				flag=true;
			 con.close();

		    } 
		catch (SQLException e)
		{

			e.printStackTrace();
		}	
       

		return flag;
	}

	//********************************************************************************
	// Method to search film to be updated in the database

	public ArrayList<Film> searchFilm(Film film)
	{

		ArrayList<Film> filmdetails=new ArrayList<>();
		String sql="SELECT film.filmid,film.title,film.description,film.releaseYear,language.language_name,film.rentalDuration,film.length,film.replacementCost,film.ratings,film.specialFeatures,category.category_name FROM film,category,LANGUAGE WHERE category.category_id = film.category AND language.language_Id = film.originalLanguage and film.filmid=?";

		ConnectionClass connclass=new ConnectionClass();

		Connection con=connclass.getConnection();
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			System.out.println(sql);			
			pst.setInt(1, film.getFilm_Id());
			System.out.println(film.getFilm_Id());

			ResultSet rs=pst.executeQuery();

			while(rs.next())
			{
				Film film1 = new Film();

				film1.setFilm_Id(rs.getInt(1));
				film1.setTitle(rs.getString(2));
				film1.setDescription(rs.getString(3));
				film1.setRelease_Date(rs.getDate(4));

				Language lang = new Language();
				lang.setLanguage_Name(rs.getString(5));
				film1.setOriginalLanguage(lang);

				film1.setRental_Duration(rs.getDate(6));
				film1.setLength(rs.getInt(7));
				film1.setReplacement_Cost(rs.getDouble(8));
				film1.setRatings(rs.getInt(9));
				film1.setSpecial_Features(rs.getString(10));

				Category catg = new Category();
				catg.setCategory_Name(rs.getString(11));
				film1.setCategory(catg);

				filmdetails.add(film1);
			}


		} catch (SQLException e) 
		{

			e.printStackTrace();
		}
		return filmdetails;

	}
	//

	//**************************************************************************

	//Update the Film data in the database based on the different parameters.

	public void updateFilm(Film film)
	{

		ConnectionClass connclass=new ConnectionClass();

		Connection con=connclass.getConnection();
		
		
		String sql = "UPDATE film"
				+ "	SET title='"+film.getTitle()+"',"
				+ "	description='"+film.getDescription()+"',"
				+ "	releaseyear='"+new Date(film.getRelease_Date().getTime())+"',"
				+ "	originalLanguage="+film.getOriginalLanguage().getLanguage_Id()+","
				+ "	rentalDuration='"+new Date(film.getRental_Duration().getTime())+"' ,"
				+ "	LENGTH="+film.getLength()+","
				+ "	replacementCost="+film.getReplacement_Cost()+","
				+ "	ratings="+film.getRatings()+","
				+ "	specialFeatures='"+film.getSpecial_Features()+"',"
				+ "	category="+film.getCategory().getCategory_Id()+""
				+ " WHERE filmid="+film.getFilm_Id()+";";
		
		try{
			
			PreparedStatement pst=con.prepareStatement(sql);
			System.out.println(sql);
			int count=pst.executeUpdate();  
		   }
		catch (Exception e) {}



		// Update multiple languages into the third party table	



		try {
			int count = 0;
			// Delete Existing record in language record

			String sql1="delete from  film_language"				
					+ " WHERE film_id="+film.getFilm_Id()+"";

			PreparedStatement pst1=con.prepareStatement(sql1);
			int count1=pst1.executeUpdate();
			System.out.println("no="+count1);


			// Delete Existing Actor Data in Actor table

			String sql4="delete from  film_actors"				
					+ " WHERE film_id="+film.getFilm_Id()+"";


			PreparedStatement pst4=con.prepareStatement(sql4);
			int count4=pst4.executeUpdate();
			System.out.println("no="+count4);
		} 
		catch (Exception e) {}

		// Update Record in the Language Table

		try{

			for(Language lan: film.getLanguages()){

				String sql2="INSERT INTO film_language"
						+ "	 values("+film.getFilm_Id()+","+lan.getLanguage_Id()+")";
				

				PreparedStatement pst2=con.prepareStatement(sql2);

				System.out.println(sql2);
				int count2=pst2.executeUpdate();

			}

		} 
		catch (Exception e) {}
		//// Update Record in the Actor Table
		try {
			int count = 0;

			for(Actor act: film.getActors()){

				String sql5="INSERT INTO film_actors"
						+ "	 values("+film.getFilm_Id()+","+act.getActor_Id()+")";

				PreparedStatement pst5=con.prepareStatement(sql5);

				int count1=pst5.executeUpdate();
			}

		} 
		catch (Exception e) {}
	}

	

}

