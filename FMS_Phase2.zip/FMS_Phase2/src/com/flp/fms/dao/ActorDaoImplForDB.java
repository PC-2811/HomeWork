package com.flp.fms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.flp.fms.domain.Actor;

public class ActorDaoImplForDB implements IActorDao{
	//Function to get all the Actors of the film.

		public ArrayList<Actor> getActor(int fid) 
		{
			ConnectionClass connclass=new ConnectionClass();
			ArrayList<Actor> filmdetailsList=new ArrayList<>();
			//ConnectionClass conClass = new ConnectionClass();
			Connection con= connclass.getConnection();
			try {
				
				//String sql2 = "SELECT  * FROM actors WHERE actors.actor_id IN(SELECT film_actors.actor_id FROM film_actors WHERE film_actors.film_id =?)";
	String sql2 = "SELECT  * FROM actors where film_id=?";
				PreparedStatement pst1=con.prepareStatement(sql2);
				pst1.setInt(1, fid);
				ResultSet rs1=pst1.executeQuery();

				while(rs1.next())
				{
					Actor actor = new Actor();
					actor.setFirst_Name(rs1.getString(1));
					actor.setLast_Name(rs1.getString(2));
					filmdetailsList.add(actor);	

				}

				con.close();

			}
			catch (SQLException e) 
			{

				e.printStackTrace();
			}
			return filmdetailsList;

		}

	
}
