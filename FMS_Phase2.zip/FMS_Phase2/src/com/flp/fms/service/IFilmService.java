package com.flp.fms.service;

import java.util.ArrayList;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;

public interface IFilmService 
{
	
	public void saveFilm(Film film);
	//public ArrayList<Actor> getAllActor();
	public ArrayList<Language> getAllLanguage();
	public ArrayList<Category> getAllCategory();
	public ArrayList<Film> getAllFilms();
	public ArrayList<Language> getLanguageList(int fid);
	public ArrayList<Film> searchAllFilm(Film film,String categoryValue,String language,int Actor);
	public boolean deleteFilm(int filmId);
	public void updateFilm(Film film);
	public ArrayList<Film> searchFilm(Film film);
	
}
