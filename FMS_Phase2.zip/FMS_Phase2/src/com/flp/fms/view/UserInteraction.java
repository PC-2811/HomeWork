package com.flp.fms.view;
import com.flp.fms.domain.Film;
import com.flp.fms.util.Validate;
import com.flp.fms.domain.Language;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Actor;
import java.util.*;

public class UserInteraction 
{	
	boolean flag = true;
	String title;
	String releaseDate;
	Double cost;
	int length,rating;


	// Returns fully qualified film object



	// Method for accepting Film Object Data

	public Film addFilm(ArrayList<Language> languages,ArrayList<Category>category,ArrayList<Actor> arrayList)
	{
		Film film = new Film();
		FilmServiceImpl filmservice = new FilmServiceImpl();
		
		Scanner sc = new Scanner(System.in);
		//-----------------------------------------------------------------------------------   
		// Title Field

		System.out.println("Enter the Film Title:");

		do{

			title = sc.nextLine();	
			flag = Validate.isValidFilmName(title);
			if(flag==false)
				System.out.println("Invalid Title ! Enter the Film Title again :");
		} while(!flag);
		film.setTitle(title);
		//------------------------------------------------------------------------------------
		// Description Field

		System.out.println("Enter the Film Description:");
		film.setDescription(sc.nextLine());
		//----------------------------------------------------------------------------------------


		// Description Field

		System.out.println("Enter the Film Special Features:");
		film.setSpecial_Features(sc.nextLine());
		//----------------------------------------------------------------------------------------
		// Release Date

		boolean dateformat = true;
		Date release_Date;

		do{ 
			do{
				System.out.println("Enter the Film Release Date:");
				releaseDate = sc.next();
				flag = Validate.isValidReleaseDate(releaseDate);
				if(!flag)
					System.out.println("Invalid Date! Enter in the dd-mmm-yyyy format.");
			}while(!flag);

			Date today = new Date();
			release_Date = new Date(releaseDate);
			if(release_Date.before(today)|| release_Date.equals(today))
				dateformat = true;
			else
				System.out.println("Invalid Date! Enter in the dd-mmm-yyyy format.");
		}while(!dateformat);

		film.setRelease_Date(release_Date);



		//----------------------------------------------------------------------------------------
		// Rental Duration

		boolean dateformat1 = true;
		String rental_Date;
		Date rental_Date1;

		do{ 

			do{
				System.out.println("Enter the Film Rental Date:");
				rental_Date = sc.next();
				flag = Validate.isValidRentalDurationDate(rental_Date);
				if(!flag)
					System.out.println("Invalid Rental Date! Enter in the dd-mmm-yyyy format.");
			}while(!flag);

			Date today = new Date();
			rental_Date1 = new Date(rental_Date);

			if(rental_Date1.after(release_Date))
				dateformat1 = true;
			else
				System.out.println("Tnvalid Rental Date ! Rental date should after Release Date.");
		}while(!dateformat1);

		film.setRental_Duration(rental_Date1);
		//----------------------------------------------------------------------------------------  

		//Length of the Film

		do{
			System.out.println("Enter the lenth of the film:");

			length = sc.nextInt();
			flag = Validate.isValidlength(length);
			if(flag==false)
				System.out.println("Invalid length! Please enter valid length:");


		}while(!flag);
		film.setLength(length);
		//---------------------------------------------------------------------------------------- 
		// Cost of the film
		System.out.println("Enter the Replacement Cost of the film:");

		do{


			cost = sc.nextDouble();
			flag = Validate.isValidCost(cost);
			if(flag==false)
				System.out.println("Invalid Cost! Please enter valid Replacement Cost:");


		}while(!flag);
		film.setReplacement_Cost(cost);
		//----------------------------------------------------------------------------------------
		// Ratings

		System.out.println("Enter the Rating for the film (1-5):");

		do{


			rating = sc.nextInt();
			flag = Validate.isValidRate(rating);
			if(flag==false)
				System.out.println("Invalid Rating! Please enter valid Rating between(1-5):");


		}while(!flag);
		film.setRatings(rating);;


		//---------------------------------------------------------------------------------------- 

		//Choose Language
		System.out.println("Choose Original Language");
		Language language= selectLanguage(languages);
		film.setOriginalLanguage(language);

		//----------------------------------------------------------------------------------------
		// Choose other languages of the film

		//Add all languages
		List<Language> languages2=new ArrayList<>();
		Language lang = new Language();
		String choice;
		boolean flag_langs;
		do{
			System.out.println("Choose All Languages for the Film:");
			Language language1= selectLanguage(languages);


			flag_langs=Validate.checkDuplicateLanguage(languages2, language1);
			if(!flag_langs){
				languages2.add(language1);
			    lang.setLanguage_Id(language1.getLanguage_Id());}
			else
				System.out.println("Language already Exists. Please try other languages!");


			System.out.println("Wish to add More Languages?[y|n]");
			choice=sc.next();
		}while(choice.charAt(0)=='y'||choice.charAt(0)=='Y');
		film.setLanguages(languages2);

		//----------------------------------------------------------------------------------------		

		// Choose Category of Films


		System.out.println("Choose Film Category");
		Category categor = selectCategory(category);	  		
		film.setCategory(categor);

       //-------------------------------------------------------------------
		// Choose Actors for the film
		//Add all Actors
		//HashSet<Actor> actor1=new HashSet<>();
		Actor actor = new Actor();
		List<Actor> actor2=new ArrayList<>();

		String choice1;
		//Actor actor2=null;
		boolean flag_actor;
		do{


			System.out.println("Choose Actor");
			Actor actor1=selectActor(arrayList) ;
			actor2.add(actor1);
			film.setActors(actor2);
			
			actor.setActor_Id(actor1.getActor_Id());
			/*System.out.println("Choose All Actors for the Film:");
				 actor2= selectActor(actor);			
				  actor1.add(actor2);*/


			System.out.println("Wish to add More Actors?[y|n]");
			choice=sc.next();
		}while(choice.charAt(0)=='y'||choice.charAt(0)=='Y');
		
		
		
		

		return film;
	}

	//----------------------------------------------------------------------------------------



	//Choose Valid Language Object from the list of Languages
	public Language selectLanguage(List<Language>  languages){

		Language sel_language=null;
		boolean flag;
		do{	
			//Print Langauge Details
			for(Language language:languages)
				System.out.println(language.getLanguage_Id() + "\t" + language.getLanguage_Name());

			System.out.println("Choose the Language:");
			Scanner sc = new Scanner(System.in);
			int option=sc.nextInt();

			flag=false;

			//Check the Language Object
			for(Language language: languages)
			{
				if(option==language.getLanguage_Id())
				{
					sel_language=language;
					flag=true;
					break;
				}
			}

			//Print Error Message
			if(!flag)
				System.out.println("Please select valid Language Id");
		}while(!flag);	

		return sel_language;
	}

	//----------------------------------------------------------------------------------------

	//Choose Valid Category Object from the list of Category
	public Category selectCategory(List<Category>  category){

		Category sel_category=null;

		boolean flag;
		do{	
			//Print Category Details
			for(Category categor :category)
				System.out.println(categor.getCategory_Id() + "\t" + categor.getCategory_Name());

			System.out.println("Choose the Category:");
			Scanner sc = new Scanner(System.in);
			int option=sc.nextInt();

			flag=false;

			//Check the Category Object
			for(Category categor: category)
			{
				if(option==categor.getCategory_Id())
				{
					sel_category=categor;
					flag=true;
					break;
				}
			}

			//Print Error Message
			if(!flag)
				System.out.println("Please select valid Category Id");
		}while(!flag);	

		return sel_category;
	}



	//----------------------------------------------------------------------------------------

	//Choose Valid Category Object from the list of Category
	public Actor selectActor(ArrayList<Actor> arrayList){

		Actor sel_actor=null;

		boolean flag;
		do{	
			//Print Category Details
			for(Actor actor1 : arrayList)
				System.out.println(actor1.getActor_Id()+""+actor1.getFirst_Name()+""+actor1.getLast_Name());

			System.out.println("Choose the Actor:");
			Scanner sc = new Scanner(System.in);
			int option=sc.nextInt();

			flag=false;

			//Check the Category Object
			for(Actor actor1: arrayList)
			{
				if(option==actor1.getActor_Id())
				{
					sel_actor=actor1;
					flag=true;
					break;
				}
			}

			//Print Error Message
			if(!flag)
				System.out.println("Please select valid Actor Id");
		}while(!flag);	

		return sel_actor;
	}
	//----------------------------------------------------------------------------------------
	//Method to list all the items from the map

	public void getAllFilm(Collection<Film> lst) {



		for(Film film:lst){

			//Language List
			String languages="";
			for(Language language:film.getLanguages())
				languages=languages+language.getLanguage_Name()+",";
			// Actor List
			String actors="";
			for(Actor actor:film.getActors())
				actors=actors+actor.getFirst_Name()+actor.getLast_Name() +",";

			System.out.println("|FILM ID| \t FILM TITLE| \t FILM DESCRIPTION| \t FILM LENGTH| \t FILM RATING| \t FILM SPECIAL FEATURES| \t ORIGINAL LANGUAGE| \t REPLACEMENT LANGUAGE |\t RELEASE DATE| \t RENTAL DURATION |\t CATEGORY| \t OTHER LANGUAGES| \t  ACTORS|" );
			System.out.println(film.getFilm_Id() + "\t" +
					film.getTitle() + "\t"+
					film.getDescription() + "\t"+
					film.getLength()+"\t"+
					film.getRatings()+"\t"+
					film.getSpecial_Features()+"\t"+
					film.getOriginalLanguage()+"\t"+
					film.getReplacement_Cost()+"\t"+
					film.getRelease_Date()+"\t"+
					film.getRental_Duration()+"\t"+
					film.getCategory()+"\t"+languages+"\t"+actors);
		}
	}


	//-------------------------------------------------------------------		

	

}

