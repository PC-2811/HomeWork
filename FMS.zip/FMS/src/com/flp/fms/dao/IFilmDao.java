package com.flp.fms.dao;
import java.util.*;
import com.flp.fms.domain.*;




public interface IFilmDao {
	
	public List<Category> getCategory();
	public List<Language> getLanguages();
	
	public void addFilm(Film film); // Add Film 
	
	public Map<Integer, Film> getAllFilms();// Display Film
	
	public void searchby_id(Collection<Film> lst);
	
	public void searchby_name(Collection<Film> lst);
	
	public void searchby_rate(Collection<Film> lst);
	
    public void removeby_id(Collection<Film> lst);
	
	public void removeby_rate(Collection<Film> lst);
	public void removeby_name(Collection<Film> lst);
	
	public void update(Collection<Film> lst);
	
	
	
	
	
}
