package com.flp.fms.dao;

import java.util.HashSet;
import java.util.Set;

import com.flp.fms.domain.Actor;

public class ActorDaoImplForList implements IActorDao {
	
	@Override
	public Set<Actor> getActor() 
	{
		Set<Actor> actor=new HashSet<>();
		actor.add(new Actor(101, "Sharuk", "Khan"));
		actor.add(new Actor(102, "Mohan", "Lal"));
		actor.add(new Actor(103, "Dulqer", "Salman"));
		actor.add(new Actor(104, "Manju", "Warrier"));
		actor.add(new Actor(105, "Nazriya", "Nazim"));
		actor.add(new Actor(106, "Nivin", "Pauly"));
		
	
		return actor;
	}
	
	
	

}
