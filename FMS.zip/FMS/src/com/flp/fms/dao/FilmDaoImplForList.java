package com.flp.fms.dao;
import java.util.*;
import com.flp.fms.domain.*;

public class FilmDaoImplForList implements IFilmDao {
	
	Film film = new Film();
	//Film film1 = new Film();
	
	
	private Map<Integer, Film> film_Repository=new HashMap<>();
	
	@Override
	public List<Language> getLanguages() 
	{
		List<Language> languages=new ArrayList<>();

		languages.add(new Language(1, "English"));
		languages.add(new Language(2, "Malayalam"));
		languages.add(new Language(3, "Hindi"));
		languages.add(new Language(4, "Marati"));
		languages.add(new Language(5, "Tamil"));
		languages.add(new Language(6, "Telegu"));
		languages.add(new Language(7, "Kannada"));
		
		
		return languages;
	}
	//CURD Operation
		@Override
		public void addFilm(Film film) {
			film_Repository.put(film.getFilm_Id(), film);
			
		}


		@Override
		public Map<Integer, Film> getAllFilms() {
			
			return film_Repository;
		}
		
		public void searchby_id(Collection<Film> lst)
		{
				int flag = 0;
				
				System.out.println("Please Enter Film Id you want to Search");
				Scanner sc = new Scanner(System.in);
				int f_id=sc.nextInt();
				
				
			for(Film film:lst)
			{
				
				
				if(f_id==film.getFilm_Id())
				{
					System.out.println("Element  Found");
					System.out.println(film);
					
				}
					
				

			}
	}
					
		public void searchby_name(Collection<Film> lst)
		{
				int flag = 0;
				
				System.out.println("Please Enter Film Name you want to Search");
				Scanner sc = new Scanner(System.in);
				String fname=sc.next();
				
				
			for(Film film:lst)
			{
				
				
				if(fname.equals(film.getTitle()))
				{
					System.out.println("Element  Found");
					System.out.println(film);
					
				}
					
				

			}
			}
		
		
		public void searchby_rate(Collection<Film> lst)
		{
				int flag = 0;
				
				System.out.println("Please Enter Film Rating that you want to Search");
				Scanner sc = new Scanner(System.in);
				int rate=sc.nextInt();
				
				
			for(Film film:lst)
			{
				
				
				if(rate==film.getRatings())
				{
					System.out.println("Element  Found");
					System.out.println(film);
					
				}
					
				

			}
			}
			
		//--------------------------------------------------------------------
		// Remove the data from the list
			
			public void removeby_id(Collection<Film> lst)
			{
					
					
					System.out.println("Please Enter Film Id you want to delete");
					Scanner sc = new Scanner(System.in);
					int f_id=sc.nextInt();
					
					
				for(Film film:lst)
				{
					
					
					if(f_id==film.getFilm_Id())
					{
						System.out.println("Element  Found");
						lst.remove(film);
						
					}
						
					

				}
				  
				}
			
		//------------------------------------------------------------------------------
			
			public void removeby_rate(Collection<Film> lst)
			{
					int flag = 0;
					
					System.out.println("Please Enter Film Rating that you want to Remove");
					Scanner sc = new Scanner(System.in);
					int rate=sc.nextInt();
					
					
				for(Film film:lst)
				{
					
					
					if(rate==film.getRatings())
					{
						System.out.println("Element  Found");
						lst.remove(film);
						
					}
						
					

				}
				}
			//--------------------------------------------------------------------	
			
			// Remove the data from the list
			
				public void removeby_name(Collection<Film> lst)
				{
						
						
						System.out.println("Please Enter Film Title you want to delete");
						Scanner sc = new Scanner(System.in);
						String fname=sc.next();
						
						
					for(Film film:lst)
					{
						
						
						if(fname.equals(film.getTitle()))
						{
							System.out.println("Element  Found");
							lst.remove(film);
							
						}
							
						

					}
					  
					}
				
			//------------------------------------------------------------------------------
		
			

         public void update(Collection<Film> lst)
         {
        	 
        	 
        	 int flag = 0;
				
				System.out.println("Please Enter Film Id you want to Update");
				Scanner sc = new Scanner(System.in);
				int f_id=sc.nextInt();
				
				
			for(Film film:lst)
			{
				
				
				if(f_id==film.getFilm_Id())
				{
					System.out.println("Element  Found");
					lst.remove(film);
					
				}
					
				

			}
			
			
			
        	 
        	 
         }
		
		
			@Override
			public List<Category> getCategory() 
			{
				List<Category> category=new ArrayList<>();
				category.add(new Category(1,"Comedy"));
				category.add(new Category(2,"Romantic"));
				category.add(new Category(3,"Horror"));
				category.add(new Category(4,"Action"));
				category.add(new Category(5,"Family-Drama"));
				
				
				
				return category;
			}


}
