package com.flp.fms.service;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import com.flp.fms.domain.Category;
import com.flp.fms.domain.Language;
import com.flp.fms.domain.Film;
import com.flp.fms.dao.FilmDaoImplForList;

import com.flp.fms.dao.IFilmDao;

public class FilmServiceImpl implements IFilmService {
	
	
	private IFilmDao filmDao=new FilmDaoImplForList();
	//private CategoryDaoImplForList IcatDao=new CategoryDaoImplForList();

	@Override
	public List<Language> getLanguages() 
	{
		
		return filmDao.getLanguages();

    }
	
	@Override
	public List<Category> getCategory()
	
	{
		
		
		return filmDao.getCategory();
		
	}
	
	//-----------------------------------------------
	@Override
	public void addFilm(Film film) {
		
		film.setFilm_Id(generate_Film_Id());
		filmDao.addFilm(film);		
	}
	
	
	//-------------------------------------------------
	
	
	//-------------------------------------------------
	public int generate_Film_Id(){
		
		int filmId=0;
		
		//Verify filmId has been Duplicated or not
		do{
			double fid=Math.random()*1000;
			filmId=(int)fid;
		}while(checkDuplicateFilmId(filmId));
		
		
		return filmId;
	}
	//------------------------------------------------

	@Override
	public Map<Integer, Film> getAllFilms() {
		
		return filmDao.getAllFilms();
	}
	
	//-----------------------------------------------
	
	
	
	public boolean checkDuplicateFilmId(int filmId){
		
		Set<Integer> keys= getAllFilms().keySet();
		boolean flag=false;
		if(keys.isEmpty() || keys==null){
			flag= false;
		}else{
			for(Integer key:keys){
				if(key==filmId){
					flag=true;
					break;
				}
			}
		}
		
		return flag;
		
	}
//-------------------------------------------------------	
	
	
	//----------------------------------------------------------------------------------
	
	
	public void searchby_id(Collection<Film> lst)
   {
		
		filmDao.searchby_id(lst);
		
	}

//------------------------------------------------------------------------------

	public void searchby_name(Collection<Film> lst)
	{
			filmDao.searchby_name(lst);
	}
	//--------------------------------------------------------------------
	
	//------------------------------------------------------------------------------
	
	public void searchby_rate(Collection<Film> lst)
	{
		filmDao.searchby_rate(lst);
		}
	//--------------------------------------------------------------------
// Remove the data from the list
	
	public void removeby_id(Collection<Film> lst)
	{
			
			filmDao.removeby_id(lst);
		}
	
//------------------------------------------------------------------------------
	
	public void removeby_rate(Collection<Film> lst)
	{
			filmDao.removeby_rate(lst);
		}
	//--------------------------------------------------------------------	
	
	// Remove the data from the list
	
		public void removeby_name(Collection<Film> lst)
		{
				
			filmDao.removeby_name(lst);
			  
			}
		
	//------------------------------------------------------------------------------
		
		
		public void update(Collection<Film> lst)
		{
			
			filmDao.update(lst);
		}
		
}
	
