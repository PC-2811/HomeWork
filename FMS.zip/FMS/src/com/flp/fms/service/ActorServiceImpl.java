package com.flp.fms.service;
import java.util.Set;
import com.flp.fms.domain.*;
import com.flp.fms.dao.*;

public class ActorServiceImpl implements IActorService {
	
	private IActorDao actorDao=new ActorDaoImplForList();
	
	public Set<Actor> getActor()
	{
		
		
		return actorDao.getActor();
	}

}
