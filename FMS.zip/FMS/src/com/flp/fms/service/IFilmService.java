package com.flp.fms.service;
import java.util.*;
import com.flp.fms.domain.*;

public interface IFilmService {
	
	
	
	public List<Language> getLanguages();
	public List<Category> getCategory();
	
	
	public void addFilm(Film film);
	public Map<Integer, Film> getAllFilms();
	public void searchby_id(Collection<Film> lst1);

	public void searchby_name(Collection<Film> lst);
	
	public void searchby_rate(Collection<Film> lst);
	
	public void removeby_id(Collection<Film> lst);
	
	public void removeby_rate(Collection<Film> lst);
	public void removeby_name(Collection<Film> lst);
	
	public void update(Collection<Film> lst);
	
}