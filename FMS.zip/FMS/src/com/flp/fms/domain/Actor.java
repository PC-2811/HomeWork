package com.flp.fms.domain;


// private fields 
public class Actor {
	
	private int actor_Id;
	private String first_Name;
	private String last_Name;
	
	// Default Constructor
	
	public Actor()
	{
		
		
	}
	// Fully Overloaded Constructor
	
	public Actor(int id,String fname,String lname)
	{
		actor_Id = id;
		first_Name  = fname;
		last_Name = lname;
		
	}
	
	// Getters and Setters

	public int getActor_Id() {
		return actor_Id;
	}

	public void setActor_Id(int actor_Id) {
		this.actor_Id = actor_Id;
	}

	public String getFirst_Name() {
		return first_Name;
	}

	public void setFirst_Name(String first_Name) {
		this.first_Name = first_Name;
	}

	public String getLast_Name() {
		return last_Name;
	}

	public void setLast_Name(String last_Name) {
		this.last_Name = last_Name;
	}

	@Override
	public String toString() {
		return "Actor [actor_Id=" + actor_Id + ", first_Name=" + first_Name + ", last_Name=" + last_Name + "]";
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + actor_Id;
		result = prime * result + ((first_Name == null) ? 0 : first_Name.hashCode());
		result = prime * result + ((last_Name == null) ? 0 : last_Name.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof Actor)) {
			return false;
		}
		Actor other = (Actor) obj;
		if (actor_Id != other.actor_Id) {
			return false;
		}
		if (first_Name == null) {
			if (other.first_Name != null) {
				return false;
			}
		} else if (!first_Name.equals(other.first_Name)) {
			return false;
		}
		if (last_Name == null) {
			if (other.last_Name != null) {
				return false;
			}
		} else if (!last_Name.equals(other.last_Name)) {
			return false;
		}
		return true;
	}
	
	
	

}
