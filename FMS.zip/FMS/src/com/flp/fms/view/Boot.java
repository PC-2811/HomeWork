package com.flp.fms.view;
import com.flp.fms.service.*;
import java.util.*;
import com.flp.fms.domain.Film;


public class Boot {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int choice;
		int choice_search=0;
		
		
		
		UserInteraction U = new UserInteraction();
		IFilmService filmService=new FilmServiceImpl();
		
		ActorServiceImpl actorServices=new ActorServiceImpl();
		do{
			selection();
			System.out.println("Enter your choice:");
			Scanner sc = new Scanner(System.in);
			choice = sc.nextInt();
	
		switch(choice)
		{
		case 1:
			 Film film = U.addFilm(filmService.getLanguages(),filmService.getCategory(),actorServices.getActor());
		    
		    filmService.addFilm(film);
		    System.out.println(film);
		   
		    break;
		 
		case 2:
			Map<Integer, Film>  film_lst4= filmService.getAllFilms();
			Collection<Film> lst4=film_lst4.values();
			filmService.update(lst4);
			
			Film film1 = U.addFilm(filmService.getLanguages(),filmService.getCategory(),actorServices.getActor());
			filmService.addFilm(film1);
			System.out.println(film1);
			
			
			
			break;
		case 3:		
			Map<Integer, Film>  film_lst2= filmService.getAllFilms();
			Collection<Film> lst2=film_lst2.values();
			
			
			do{
				switch(choice_search)
				{
				
				case 1:
					filmService.removeby_id(lst2);
					U.getAllFilm(lst2);
					break;
				case 2:				
					
					filmService.removeby_name(lst2);
					break;
				case 3:
					filmService.removeby_rate(lst2);
					U.getAllFilm(lst2);
					
					break;
				case 4:
					System.exit(0);
					break;
				
				
				}
				
				
				
			}while(choice_search!=4);
		
			
			
			
			break;
		case 4:
			
			search_Selection();
			
			Map<Integer, Film>  film_lst1= filmService.getAllFilms();
			Collection<Film> lst1=film_lst1.values();
			
			do{
				System.out.println("Enter your choice of search:");			
				choice_search = sc.nextInt();
				switch(choice_search)
				{
				
				case 1:					
					
					filmService.searchby_id(lst1);
					break;
				case 2:				
					
					filmService.searchby_name(lst1);
					break;
				case 3:
					filmService.searchby_rate(lst1);
					break;
				case 4:
					System.exit(0);
					break;
				
				
				}
				
				
			}while(choice_search!=4);
			
			//------------------------------End of SubSearch----------------
			
			break;
		case 5:
			 Map<Integer, Film>  film_lst= filmService.getAllFilms();
				Collection<Film> lst=film_lst.values();		    
			    U.getAllFilm(lst);
			break;
		case 6:
			System.exit(0);
			
	
		}
		}while(choice!=6);
	}
	
	// Static Method to display the Film Menu
	
	public static void selection()
	{
		
		System.out.println("------------------------MENU--------------------------");
		System.out.println("1. AddFilm");
		System.out.println("2. UpdateFilm");
		System.out.println("3. RemoveFilm");
		System.out.println("4. SearchFilm");
		System.out.println("5. getAllFilm");
		System.out.println("--------------------------------------------------");		
		
		
	}
	
	
	
	
	//SubSelection for the search option 
	
	
	
	public static void search_Selection()
	{
		
		System.out.println("------------------------SEARCH SUB MENU--------------------------");
		System.out.println("1. Search By Film Id" );
		System.out.println("2. Search By Film Title");
		System.out.println("3. Search By Film Ratings");
		System.out.println("4. exit");
		System.out.println("-----------------------------------------------------------------");		
		
		
	}
	
	//SubSelection for the remove option
	
	
	
		public static void remove_Selection()
		{
			
			System.out.println("------------------------SEARCH SUB MENU--------------------------");
			System.out.println("1.Remove By Film Id" );
			System.out.println("2. Remove By Film Title");
			System.out.println("3.Remove By Film Ratings");		
			System.out.println("-----------------------------------------------------------------");		
			
			
		}
		
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
