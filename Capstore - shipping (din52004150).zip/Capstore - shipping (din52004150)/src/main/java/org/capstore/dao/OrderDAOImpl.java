package org.capstore.dao;

import java.util.List;

import javax.management.Query;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionEvent;

import org.capstore.controller.MainController;
import org.capstore.pojo.product;
import org.capstore.pojo.shipping_address_details;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public class OrderDAOImpl implements OrderDAO{

	
	
	MainController controller=new MainController();
	@Autowired
	private SessionFactory sessionFactory;
	
	@Override
	@Transactional
	public void saveShippingAddress(shipping_address_details shipaddress){
		sessionFactory.getCurrentSession().save(shipaddress);
		
	}
	
	
	
	
	
	@Override
	@Transactional
	public void getCustomerDetails() {
		sessionFactory.getCurrentSession().createQuery("select * from customer where cart_id ");
		
		
	}
	
	
	

	@Override
	@Transactional
	public void getProductDetails() {
		Session session=sessionFactory.getCurrentSession();
		
		
		
	}

	@Override
	@Transactional
	public shipping_address_details getShippingAddress(int shipping_address_id) {
		
		Session session=sessionFactory.getCurrentSession();
		session.beginTransaction();
		
		
 //return ((shipping_address_details)sessionfactory.getCurrentSession().get(shipping_address_details.class, shipping_address_id));

return (shipping_address_details)session.createQuery("from shipping_address_details where shipping_address_id="+shipping_address_id);
	}

	
	@Override
	@Transactional
	public List getAllAddress() {
		
		//return sessionFactory.getCurrentSession().createQuery("from shipping_address_details").list();
		
		Session session = this.sessionFactory.getCurrentSession();
		session.beginTransaction();
		
		List<shipping_address_details> address = sessionFactory.getCurrentSession().createQuery("from shipping_address_details").list();
		
		return address;

	}

	@Override
	@Transactional
	public int getCartNo(HttpServletRequest request) {
		Integer cartNo=0;
		HttpSession httpsession=request.getSession();
		int customerId=controller.getCustomerId(request);
		Session session=this.sessionFactory.getCurrentSession();
		session.beginTransaction();
	List<Integer> cartIds=(session.createQuery("select cart_id from customer where cart_id="+customerId)).list();
		for(Integer cartId:cartIds){
			 cartNo=cartId;
		}
	return cartNo;
	}	
	
	
	
	
	@Override
	@Transactional
	public List<String> getProductName(HttpServletRequest request){
		Session session=this.sessionFactory.getCurrentSession();
		int cartNo=getCartNo(request);
		List<String> prodNames=null;
		List<Integer> products=(session.createQuery("select product_id from cart where cart_id="+cartNo)).list();
for(Integer prod:products){
	prodNames=(session.createQuery("select product_name from product where product_id="+prod)).list();
}
	
		return prodNames;
	}
		
		
		
		
		
		
	
	


}
