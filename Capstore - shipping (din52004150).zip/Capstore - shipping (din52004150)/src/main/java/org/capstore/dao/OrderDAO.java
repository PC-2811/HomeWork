package org.capstore.dao;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.capstore.pojo.shipping_address_details;

public interface OrderDAO {
	
	
	
public void getCustomerDetails();

public void getProductDetails();

public org.capstore.pojo.shipping_address_details getShippingAddress(int shipping_address_id);

public List getAllAddress();
	
public int getCartNo(HttpServletRequest request);
//public int getNetAmount();

public void saveShippingAddress(org.capstore.pojo.shipping_address_details shipaddress);

public List<String> getProductName(HttpServletRequest request);
//public void getCustomerId(HttpServletRequest request);

}
