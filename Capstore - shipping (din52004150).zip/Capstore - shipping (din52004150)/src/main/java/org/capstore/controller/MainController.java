package org.capstore.controller;



import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.capstore.dao.OrderDAO;
import org.capstore.dao.OrderDAOImpl;
import org.capstore.pojo.shipping_address_details;

import org.capstore.service.OrderService;
import org.capstore.service.OrderServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/link")
public class MainController {

	@Autowired
	OrderService orderService;
	//rderService orderService=new OrderServiceImpl();


	//	@RequestMapping("/shipaddress")
	//public String getShhipingAddress(Map<String, Object> map){
	//	shipping_address_details shipping_address=new shipping_address_details();
	//	
	//	map.put("shippingAddress", shipping_address);
	//	map.put("shippingAddresslist", orderService.getAllAddress());
	//
	//	
	//	return 	"ShippingAddress";
	//}

	//@RequestMapping(value="/address",method=RequestMethod.GET)
	//public void saveShippingAddress(Map<>){
	//	
	//}


public int getCustomerId(HttpServletRequest request){
		HttpSession httpsession=request.getSession();

		httpsession.setAttribute("custId", 420);
		
          int custId=(int) httpsession.getAttribute("custId");
          return custId;
	}





	@RequestMapping(value="/address",method=RequestMethod.GET,
			produces={"application/json"})
	public @ResponseBody List<shipping_address_details> getAllAddress(HttpServletRequest request)
	{
		List<shipping_address_details> addresses=orderService.getAllAddress();
		System.out.println(addresses);
		List<String> prodNames=orderService.getProductName(request);
		for(String names:prodNames){
			System.out.println(names);
		}
		HttpSession httpsession=request.getSession();
		
		return addresses;

		//@RequestMapping(value="/address.do", method=RequestMethod.POST)
		//public String doaction(@ModelAttribute shipping_address_details shipping_address,BindingResult result,
		//@RequestParam String action, Map<String, Object> map){
		//	shipping_address_details addressresult=new shipping_address_details();
		//	
		//	
		//	
		//}
	}
}