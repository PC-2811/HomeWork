package org.capstore.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.capstore.dao.OrderDAO;
import org.capstore.dao.OrderDAOImpl;
import org.capstore.pojo.shipping_address_details;

public interface OrderService  {

	
	
	
public shipping_address_details getShippingAddress(int shipping_address_id);
	
public List getAllAddress();

public void getCustomerId(HttpServletRequest request);

public List<String> getProductName(HttpServletRequest request);





}
	
	

