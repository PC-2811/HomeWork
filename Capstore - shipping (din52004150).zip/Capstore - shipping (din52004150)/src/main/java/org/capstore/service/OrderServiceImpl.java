package org.capstore.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.capstore.dao.OrderDAO;
import org.capstore.dao.OrderDAOImpl;
import org.capstore.pojo.shipping_address_details;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


@Service
public class OrderServiceImpl implements OrderService{

	@Autowired
	OrderDAO orderdao;

	@Override
	@Transactional
	public shipping_address_details getShippingAddress(int shipping_address_id) {
		
		return orderdao.getShippingAddress(shipping_address_id);
	}

	@Override
	@Transactional
	public List getAllAddress() {
		
		return orderdao.getAllAddress();
	}
	
	
	@Override
	@Transactional
	public void getCustomerId(HttpServletRequest request){
		
		
		System.out.println(request.getAttribute("cust")+"ID");
	}

	@Override
	@Transactional
	public List<String> getProductName(HttpServletRequest request) {
	
		return orderdao.getProductName(request);
	}
	
	
	
}
