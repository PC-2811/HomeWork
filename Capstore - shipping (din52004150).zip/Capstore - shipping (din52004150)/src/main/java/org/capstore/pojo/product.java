package org.capstore.pojo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity 
public class product {

	@Id
	@GeneratedValue
	private int product_id;
	private String product_name;
	private double price;
	private int stock;
	
	//************EMPTY CONSTRUCTOR****************//
	public product() {
		super();
	}

	//************FULLY LOADED CONSTRUCTOR****************//
	public product(int product_id, String product_name, double price, int stock) {
		super();
		this.product_id = product_id;
		this.product_name = product_name;
		this.price = price;
		this.stock = stock;
	}
	
	//************GETTERS AND SETTERS****************//
	public int getProduct_id() {
		return product_id;
	}
	public void setProduct_id(int product_id) {
		this.product_id = product_id;
	}
	public String getProduct_name() {
		return product_name;
	}
	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getStock() {
		return stock;
	}
	public void setStock(int stock) {
		this.stock = stock;
	}


	//************TOSTRING METHOD****************//
	@Override
	public String toString() {
		return "Product [product_id=" + product_id + ", product_name=" + product_name + ", price=" + price + ", stock="
				+ stock + "]";
	}
	
	
	
}
