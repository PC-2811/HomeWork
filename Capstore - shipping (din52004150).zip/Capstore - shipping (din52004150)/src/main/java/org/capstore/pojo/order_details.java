package org.capstore.pojo;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;


@Entity
public class order_details {

	@Id
	@GeneratedValue
	private int order_id;
		
//	@OneToOne(cascade=CascadeType.ALL,fetch=FetchType.EAGER, targetEntity=shipping_address_details.class )
	private double cart_id;
	
//	@OneToMany(cascade=CascadeType.ALL,fetch=FetchType.EAGER)
	private double discount_coupon_id;
	
	private Date order_date;
	
	private double net_amount;
	
	@OneToOne(cascade=CascadeType.ALL,fetch=FetchType.EAGER)
	@JoinColumn(name="shipping_address_id_FK")
	private shipping_address_details ship_address_details;
	
	
	//************EMPTY CONSTRUCTOR****************//
	
	public order_details() {}


	//************FULLY LOADED CONSTRUCTOR****************//
	public order_details(int order_id, double cart_id, double discount_coupon_id, Date order_date, double net_amount,
			shipping_address_details ship_address_details) {
		super();
		this.order_id = order_id;
		this.cart_id = cart_id;
		this.discount_coupon_id = discount_coupon_id;
		this.order_date = order_date;
		this.net_amount = net_amount;
		this.ship_address_details = ship_address_details;
	}


	//************GETTERS AND SETTERS****************//
	public int getOrder_id() {
		return order_id;
	}



	public void setOrder_id(int order_id) {
		this.order_id = order_id;
	}



	public double getCart_id() {
		return cart_id;
	}



	public void setCart_id(double cart_id) {
		this.cart_id = cart_id;
	}



	public double getDiscount_coupon_id() {
		return discount_coupon_id;
	}



	public void setDiscount_coupon_id(double discount_coupon_id) {
		this.discount_coupon_id = discount_coupon_id;
	}



	public Date getOrder_date() {
		return order_date;
	}



	public void setOrder_date(Date order_date) {
		this.order_date = order_date;
	}



	public double getNet_amount() {
		return net_amount;
	}



	public void setNet_amount(double net_amount) {
		this.net_amount = net_amount;
	}



	public shipping_address_details getShip_address_details() {
		return ship_address_details;
	}



	public void setShip_address_details(shipping_address_details ship_address_details) {
		this.ship_address_details = ship_address_details;
	}


	//************TOSTRING METHOD****************//

	@Override
	public String toString() {
		return "order_details [order_id=" + order_id + ", cart_id=" + cart_id + ", discount_coupon_id="
				+ discount_coupon_id + ", order_date=" + order_date + ", net_amount=" + net_amount
				+ ", ship_address_details=" + ship_address_details + "]";
	}
	
	
	
	
	
	
	

	
	
}
	
	
	
	
	
	
	
	
	
	
	
	
	

