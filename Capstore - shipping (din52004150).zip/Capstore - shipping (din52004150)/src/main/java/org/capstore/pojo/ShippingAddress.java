package org.capstore.pojo;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class ShippingAddress {
@Id
private int shipping_address_id;
private String door_no;
private String street_name;
private String area_name;
private String city;
private String landmark;
private String state;
private int pincode;
	
	//No argument constructor
	public ShippingAddress(){}
	
	
	
	//constructer using fields
	public ShippingAddress(int shipping_address_id, String door_no, String street_name, String area_name,
			String city, String landmark, String state, int pincode) {
		super();
		
		this.shipping_address_id = shipping_address_id;
		this.door_no = door_no;
		this.street_name = street_name;
		this.area_name = area_name;
		this.city = city;
		this.landmark = landmark;
		this.state = state;
		this.pincode = pincode;
	}

	
	
	
	//getters and setters
	
	//public String getTitle() {
		//return title;
	//}

	//public void setTitle(String title) {
	//	this.title = title;
	//}

	public int getShipping_address_id() {
		return shipping_address_id;
	}

	public void setShipping_address_id(int shipping_address_id) {
		this.shipping_address_id = shipping_address_id;
	}

	public String getDoor_no() {
		return door_no;
	}

	public void setDoor_no(String door_no) {
		this.door_no = door_no;
	}

	public String getStreet_name() {
		return street_name;
	}

	public void setStreet_name(String street_name) {
		this.street_name = street_name;
	}

	public String getArea_name() {
		return area_name;
	}

	public void setArea_name(String area_name) {
		this.area_name = area_name;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getLandmark() {
		return landmark;
	}

	public void setLandmark(String landmark) {
		this.landmark = landmark;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public int getPincode() {
		return pincode;
	}

	public void setPincode(int pincode) {
		this.pincode = pincode;
	}
	
	
	
	
	//to-string 

	@Override
	public String toString() {
		return "ShippingAddress [ shipping_address_id=" + shipping_address_id + ", door_no="
				+ door_no + ", street_name=" + street_name + ", area_name=" + area_name + ", city=" + city
				+ ", landmark=" + landmark + ", state=" + state + ", pincode=" + pincode + "]";
	}

	
	
	
	
	

}
