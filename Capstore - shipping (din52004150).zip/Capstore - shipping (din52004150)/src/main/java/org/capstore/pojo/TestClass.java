package org.capstore.pojo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.tool.hbm2ddl.SchemaExport;

public class TestClass {

	public static void main(String[] args) {
		
		AnnotationConfiguration config=new AnnotationConfiguration();
		config.addAnnotatedClass(order_details.class);
		config.configure();
		
		
		
		new SchemaExport(config).create(true, true);
		
		
//		
////		
////		
////		
////		
////		//Session Factory
////				SessionFactory factory= config.buildSessionFactory();
////				
////				//Session and Transaction
////				Session session=factory.openSession();
////				
////				
////				
//////				Order od=new Order(1,2);
//////				Order ord=new Order(2,2000);
//////				Order ord1=new Order(3,2000);
//////				Order ord2=new Order(4,4000);
////				
////				session.beginTransaction();
//////				session.save(od);
//////				session.save(ord);
//////				session.save(ord1);
//////				session.save(ord2);
////				
////				
////				session.getTransaction().commit();
//////				session.close();
////
////	}
////		AnnotationConfiguration config=new AnnotationConfiguration();
//
//	
//		
//		
////		config.addAnnotatedClass(Customer.class);
////		config.configure();
////		new SchemaExport(config).create(true, true);
//		
////AnnotationConfiguration config1=new AnnotationConfiguration();
////
////	
////		
////		
////		config1.addAnnotatedClass(Order1.class);
////		config1.configure();
////		new SchemaExport(config1).create(true, true);
//		

		
////////////////////////////////////////////////////////////////////////////////////////////////////////////////		
		
		
AnnotationConfiguration config1=new AnnotationConfiguration();

	
		
		
		config1.addAnnotatedClass(product.class);
		config1.configure();
		new SchemaExport(config1).create(true, true);	
		
AnnotationConfiguration config2=new AnnotationConfiguration();

	
		
		
		config2.addAnnotatedClass(coupon.class);
		config2.configure();
		new SchemaExport(config2).create(true, true);	
		
		
		
		
		
AnnotationConfiguration config3=new AnnotationConfiguration();

	
		
		
		config3.addAnnotatedClass(cart.class);
		config3.configure();
		new SchemaExport(config3).create(true, true);		
		
		
		
		
		
AnnotationConfiguration config4=new AnnotationConfiguration();

	
		
		
		config4.addAnnotatedClass(customer.class);
		config4.configure();
		new SchemaExport(config4).create(true, true);		
		
		
///////////////////////////////////////////////////////////////////////////////////////////////////////		
		
		
		/*//Session Factory
		SessionFactory factory= config.buildSessionFactory();
		
		//Session and Transaction
		Session session=factory.openSession();
		session.beginTransaction();
		session.save(student);
		session.save(student1);
		session.save(student2);
		session.save(student3);
		
		session.getTransaction().commit();
		*/
		/*session.close();*/
		/*SessionFactory sessionFactory;
		sessionFactory.getCurrentSession().createQuer*/
	}

		
	}

