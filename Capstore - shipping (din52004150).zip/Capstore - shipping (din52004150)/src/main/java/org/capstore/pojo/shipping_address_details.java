package org.capstore.pojo;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Transient;

@Entity
public class shipping_address_details {

@Id
@GeneratedValue
@Column(nullable=false)

@JoinColumn(name="order_id")
private int shipping_address_id;	

@Transient
@OneToOne(cascade=CascadeType.ALL,fetch=FetchType.EAGER,
targetEntity=order_details.class, mappedBy="shipping_address_details")
private order_details order_details;

@Column(nullable=false)
private String door_no;	

@Column(nullable=false)
private String street_name;

private String area_name;

@Column(nullable=false)
private String city;

private String landmark;

@Column(nullable=false)
private String state;

@Column(nullable=false)
private int pincode;


//************EMPTY CONSTRUCTOR****************//
public shipping_address_details(){}


//************FULLY LOADED CONSTRUCTOR****************//

public shipping_address_details(int shipping_address_id, org.capstore.pojo.order_details order_details, String door_no,
		String street_name, String area_name, String city, String landmark, String state, int pincode) {
	super();
	this.shipping_address_id = shipping_address_id;
	this.order_details = order_details;
	this.door_no = door_no;
	this.street_name = street_name;
	this.area_name = area_name;
	this.city = city;
	this.landmark = landmark;
	this.state = state;
	this.pincode = pincode;
}

//************GETTERS AND SETTERS****************//

public int getShipping_address_id() {
	return shipping_address_id;
}


public void setShipping_address_id(int shipping_address_id) {
	this.shipping_address_id = shipping_address_id;
}


public order_details getOrder_details() {
	return order_details;
}


public void setOrder_details(order_details order_details) {
	this.order_details = order_details;
}


public String getDoor_no() {
	return door_no;
}


public void setDoor_no(String door_no) {
	this.door_no = door_no;
}


public String getStreet_name() {
	return street_name;
}


public void setStreet_name(String street_name) {
	this.street_name = street_name;
}


public String getArea_name() {
	return area_name;
}


public void setArea_name(String area_name) {
	this.area_name = area_name;
}


public String getCity() {
	return city;
}


public void setCity(String city) {
	this.city = city;
}


public String getLandmark() {
	return landmark;
}


public void setLandmark(String landmark) {
	this.landmark = landmark;
}


public String getState() {
	return state;
}


public void setState(String state) {
	this.state = state;
}


public int getPincode() {
	return pincode;
}


public void setPincode(int pincode) {
	this.pincode = pincode;
}


//************TOSTRING METHOD****************//
@Override
public String toString() {
	return "shipping_address_details [shipping_address_id=" + shipping_address_id + ", order_details=" + order_details
			+ ", door_no=" + door_no + ", street_name=" + street_name + ", area_name=" + area_name + ", city=" + city
			+ ", landmark=" + landmark + ", state=" + state + ", pincode=" + pincode + "]";
}





	
}
