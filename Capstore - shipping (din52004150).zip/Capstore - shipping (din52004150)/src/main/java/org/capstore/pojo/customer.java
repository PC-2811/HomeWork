package org.capstore.pojo;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.validator.constraints.Email;

@Entity
public class customer {

	@Id
	private int	customer_id;
	
	@Column(nullable=false)
	private String first_name;
	@Column(nullable=false)
	private String last_name;

	@Column(nullable=false,unique=true)
	private String mobile_no;
	@Email
	@Column(nullable=false,unique=true)
	private String email_id;

	@Column(nullable=false,unique=true)
	private int cart_id;
	
	//***********EMPTY CONSTRUCTOR****************//
	
	public customer() {
		super();
	}

	//************FULLY LOADED CONSTRUCTOR****************//
	public customer(int customer_id, String first_name, String last_name,String mobile_no,
			String email_id, int cart_id) {
		super();
		this.customer_id = customer_id;
		this.first_name = first_name;
		this.last_name = last_name;
		this.mobile_no = mobile_no;
		this.email_id = email_id;
		this.cart_id = cart_id;
	}

	//************GETTERS AND SETTERS****************//

	public int getCustomer_id() {
		return customer_id;
	}

	public void setCustomer_id(int customer_id) {
		this.customer_id = customer_id;
	}

	public String getFirst_name() {
		return first_name;
	}

	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}

	public String getLast_name() {
		return last_name;
	}

	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}

	public String getMobile_no() {
		return mobile_no;
	}

	public void setMobile_no(String mobile_no) {
		this.mobile_no = mobile_no;
	}

	public String getEmail_id() {
		return email_id;
	}

	public void setEmail_id(String email_id) {
		this.email_id = email_id;
	}

	public int getCart_id() {
		return cart_id;
	}

	public void setCart_id(int cart_id) {
		this.cart_id = cart_id;
	}

	
	
	//************TOSTRING METHOD****************//
	@Override
	public String toString() {
		return "Customer [customer_id=" + customer_id + ", first_name=" + first_name + ", last_name=" + last_name
				+ ", mobile_no=" + mobile_no + ", email_id=" + email_id + ", cart_id="
				+ cart_id + "]";
	}

	
	
	
	
	
}
