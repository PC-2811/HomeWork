package org.capstore.pojo;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class cart {

	@Id
	private int cart_id;
	private int product_id;
	private int quantity;
	
	
	
	//************EMPTY CONSTRUCTOR****************//
	
	public cart() {
		super();
	}

	//************FULLY LOADED CONSTRUCTOR****************//
	public cart(int cart_id, int product_id, int quantity) {
		super();
		this.cart_id = cart_id;
		this.product_id = product_id;
		this.quantity = quantity;
	}
	
	//************GETTERS AND SETTERS****************//
	public int getCart_id() {
		return cart_id;
	}
	public void setCart_id(int cart_id) {
		this.cart_id = cart_id;
	}
	public int getProduct_id() {
		return product_id;
	}
	public void setProduct_id(int product_id) {
		this.product_id = product_id;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	//************TOSTRING METHOD****************//

	@Override
	public String toString() {
		return "cart [cart_id=" + cart_id + ", product_id=" + product_id + ", quantity=" + quantity + "]";
	}
	
	
	
	
}
