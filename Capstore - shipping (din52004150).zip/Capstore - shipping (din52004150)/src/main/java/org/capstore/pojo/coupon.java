package org.capstore.pojo;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class coupon {
	
	@Id
	@GeneratedValue
	private int coupon_discount_id;
	private double discount_percentage;
	private Date expiry_date;
	private double coupon_value;
	
	
	//************EMPTY CONSTRUCTOR****************//
	public coupon() {
		super();
	}

	//************FULLY LOADED CONSTRUCTOR****************//
	public coupon(int coupon_discount_id, double discount_percentage, Date expiry_date, double coupon_value) {
		super();
		this.coupon_discount_id = coupon_discount_id;
		this.discount_percentage = discount_percentage;
		this.expiry_date = expiry_date;
		this.coupon_value = coupon_value;
	}
	
	//************GETTERS AND SETTERS****************//
	public int getCoupon_discount_id() {
		return coupon_discount_id;
	}
	public void setCoupon_discount_id(int coupon_discount_id) {
		this.coupon_discount_id = coupon_discount_id;
	}
	public double getDiscount_percentage() {
		return discount_percentage;
	}
	public void setDiscount_percentage(double discount_percentage) {
		this.discount_percentage = discount_percentage;
	}
	public Date getExpiry_date() {
		return expiry_date;
	}
	public void setExpiry_date(Date expiry_date) {
		this.expiry_date = expiry_date;
	}
	public double getCoupon_value() {
		return coupon_value;
	}
	public void setCoupon_value(double coupon_value) {
		this.coupon_value = coupon_value;
	}
	
	//************TOSTRING METHOD****************//
	
	@Override
	public String toString() {
		return "Coupon [coupon_discount_id=" + coupon_discount_id + ", discount_percentage=" + discount_percentage
				+ ", expiry_date=" + expiry_date + ", coupon_value=" + coupon_value + "]";
	}	

}
