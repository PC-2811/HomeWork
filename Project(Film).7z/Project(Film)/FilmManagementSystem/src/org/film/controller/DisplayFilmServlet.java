package org.film.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.film.pojo.Film;
import org.film.service.FilmService;
import org.film.service.FilmServiceImpl;

/**
 * Servlet implementation class DisplayFilmServlet
 */
public class DisplayFilmServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		FilmService filmService=new FilmServiceImpl();
		String filmid=request.getParameter("filmid");
		String title=request.getParameter("title");
		
		Film film=new Film();
		
		film.setFilm_Id(Integer.parseInt(filmid));
		film.setFilm_Title(title);
		System.out.println("Title:" + title);
		
		List<Film> films=filmService.searchFilmDetails(film);
		
		PrintWriter out=response.getWriter();
		
		out.println("<h1 align='center'>Film Details</h1>");
		
		out.println("<table>");
		out.println("<tr>");
		out.println("<th>FilmId</th>");
		out.println("<th>Title</th>");
		out.println("<th>Description</th>");
		out.println("<th>ReleaseYear</th>");
		out.println("<th>OriginalLanguage</th>");
		out.println("<th>RentalDuration</th>");
		out.println("<th>Length</th>");
		out.println("<th>ReplacementCost</th>");
		out.println("<th>Ratings</th>");
		out.println("<th>SpecialFeatures</th>");
		out.println("<th>Category</th>");
		out.println("</tr>");
		
		for(Film film1:films)
		{
			out.println("<tr>");

			out.println("<td>" + film1.getFilm_Id() +"</td>");
			out.println("<td>" + film1.getFilm_Title() +"</td>");
			out.println("<td>" + film1.getDescreption() +"</td>");
			out.println("<td>" + film1.getRelease_Year() +"</td>");
			out.println("<td>" + film1.getOriginal_Language().getLanguage_Id()+"</td>");
			out.println("<td>" + film1.getRental_Duration()+"</td>");
			out.println("<td>" + film1.getLength() +"</td>");
			out.println("<td>" + film1.getReplacement_Cost() +"</td>");
			out.println("<td>" + film1.getRatings() +"</td>");
			out.println("<td>" + film1.getSpecial_Features()+"</td>");
			out.println("<td>" + film1.getCategory().getCategory_Id() +"</td>");
			out.println("</tr>");
		}
		out.println("</table>");
		
	
	}
		
	}


