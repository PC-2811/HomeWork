package org.film.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.film.pojo.Film;
import org.film.service.FilmService;
import org.film.service.FilmServiceImpl;

/**
 * Servlet implementation class DeleteServlet
 */
public class DeleteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
         FilmService filmService=new FilmServiceImpl();
         /*String filmid=request.getParameter("filmid");
 		String title=request.getParameter("title");*/
 		
 		Film film=new Film();
 		
 		/*film.setFilm_Id(Integer.parseInt(filmid));
 		film.setFilm_Title(title);
 		System.out.println("Title:" + title);*/
		boolean flag=filmService.deleteFilmDetails(film);
		
		if(flag){
			request.getRequestDispatcher("DeleteFilmServlet").forward(request, response);
		}
		
	}

}
