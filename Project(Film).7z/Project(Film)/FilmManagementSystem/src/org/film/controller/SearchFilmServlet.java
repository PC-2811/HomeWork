package org.film.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.film.pojo.Film;
import org.film.service.FilmService;
import org.film.service.FilmServiceImpl;

/**
 * Servlet implementation class SearchFilmServlet
 */
public class SearchFilmServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		

		FilmService filmService=new FilmServiceImpl();
		
		List<Film> films=filmService.getAllFilmDetails();
		
		PrintWriter out=response.getWriter();
		out.println("<html>");
		out.println("<head><title>Search Film</title>"
				+ "<script type='text/javascript' src='scripts/Validate.js'></script>"
				+ "<link rel='stylesheet' type='text/css' href='css/myStyle.css'>"
							
				+ "</head>"
				+ "<body><form name='f1'>"
				+ "<div>"
				+ "<label>Choose Film Id</label>"
				+ "<select name='filmid'>");
		for(Film film:films){
			out.println("<option value='"+ film.getFilm_Id()+"'>" + film.getFilm_Id() +"</option>");
		}
				out.println("</select>"
						+ "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label>Film Title:</label>"
						+ "<input type='text' name='title' size='20'>"
						+ "<input type='button' name='Search' value='Search' onClick='displayFilmDetails()'>"
				+ "</div>"
				+ "<div id='displayFilm'> "
				+ "<h2>Film Details</h2>"
				
				+ "</div>"
				+ "</form></body>");
		
		
		out.println("</html>");
	
	}
	}


