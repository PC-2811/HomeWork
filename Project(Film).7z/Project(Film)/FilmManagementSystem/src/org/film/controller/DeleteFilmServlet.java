package org.film.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.film.pojo.Film;
import org.film.service.FilmService;
import org.film.service.FilmServiceImpl;

/**
 * Servlet implementation class DeleteFilmServlet
 */
public class DeleteFilmServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		FilmService filmService=new FilmServiceImpl();
		
		List<Film> films=filmService.getAllFilmDetails();
		
		
        PrintWriter out=response.getWriter();
		
		out.println("<html>");
		out.println("<head>List All Films Details</head>"
				+ "<body>"
				
				
				+ "<table>"
				+ "<tr>"
				+ "<th>Film Id</th>"
				+ "<th>Title</th>"
				+ "<th>Description</th>"
				+ "<th>ReleaseYear</th>"
				+ "<th>OriginalLanguage</th>"
				+ "<th>RentalDuration</th>"
				+ "<th>Length</th>"
				+ "<th>ReplacementCost</th>"
				+ "<th>Ratings</th>"
				+ "<th>SpecialFeatures</th>"
				+ "<th>Category</th>"
				+ "</tr>");
		
			for(Film film:films){
				out.println("<tr>");
				out.println("<td>"+film.getFilm_Id()+"</td>");
				out.println("<td>"+film.getFilm_Title()+"</td>");
				out.println("<td>"+film.getDescreption()+"</td>");
				out.println("<td>"+film.getRelease_Year()+"</td>");
				out.println("<td>"+film.getOriginal_Language().getLanguage_Name()+"</td>");
				//out.println("<td>"+film.getOriginal_Language().getLanguage_Id()+"</td>");
				out.println("<td>"+film.getRental_Duration()+"</td>");
				out.println("<td>"+film.getLength()+"</td>");
				out.println("<td>"+film.getReplacement_Cost()+"</td>");
				out.println("<td>"+film.getRatings()+"</td>");
				out.println("<td>"+film.getSpecial_Features()+"</td>");
				out.println("<td>"+film.getCategory().getCategory_Name()+"</td>");
				//out.println("<td>"+film.getCategory().getCategory_Id()+"</td>");
				
				out.println("<td><a href='DeleteServlet?empid="+film.getFilm_Id()+film.getFilm_Title()+"'>Delete</a></td>");
				out.println("</tr>");
			}
				out.println("</table></body>");
	
				out.println("</html>");
		
		
		
		
	}
	    
	}


