package org.film.service;

import java.util.ArrayList;
import java.util.List;

import org.film.pojo.Actor;
import org.film.pojo.Category;
import org.film.pojo.Film;
import org.film.pojo.Language;

public interface FilmService {
	
	public void AddFilmServlet(Film film);
	public List<Language> getAllLanguages();
	public List<Actor> getAllActors();
	public List<Category> getAllCategories();
	public List<Film> getAllFilmDetails();
	public List<Film> searchFilmDetails(Film film);
	public boolean deleteFilmDetails(Film film);

}
