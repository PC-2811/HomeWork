package org.capstore.service;

import org.capstore.domain.Customer;
import org.springframework.stereotype.Service;

@Service
public interface CustomerService {
	
	public void saveCustomer(Customer customer);

}
