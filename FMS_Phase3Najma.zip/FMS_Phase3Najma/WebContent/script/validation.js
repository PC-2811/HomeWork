

//Validation for film title
function istitlevalidate()  
{   
		var filmtitle=fms.filmtitle.value;
		
		var letters = /^[A-Za-z]+$/;  
		if(filmtitle.match(letters))  
		{  
			document.getElementById("titlefms").innerHTML="";
			return true;  
		}  
		else  
		{  
			document.getElementById("titlefms").innerHTML="*Title should only contain alphabet"; 
			filmtitle.focus();  
			return false;  
		}  
}  

//Validation for Description of film 
function isdescriptionvalidate()  
{   
		var filmdescription=fms.filmdescription.value;
		
		var letters = /^[A-Za-z][0-9]+$/;  
		if(filmdescription.match(letters))  
		{  
			document.getElementById("descfms").innerHTML="";
			return true;  
		}  
		else  
		{  
			document.getElementById("descfms").innerHTML="* Please Enter the Film Description"; 
			filmdescription.focus();  
			return false;  
		}  
}  

//Validation for length of film 
function islengthvalid(){
	
	var filmlength=fms.filmlength.value;

    	 if(filmlength>=1 && filmlength<=1000){
    	
    	document.getElementById("lengthfms").innerHTML="";
		return true;  
    }
    else
    {
    	document.getElementById("lengthfms").innerHTML="*Length should be between 1 to 1000"; 
    	filmlength.focus();  
		return false; 
    }
    
}

//Validation for replacement cost of film 
function isreplacevalid(){
	
	var filmreplace=fms.replacementcost.value;

    	 if(filmreplace>=1 && filmreplace<=3000){
    	
    	document.getElementById("replacementcostfms").innerHTML="";
		return true;  
    }
    else
    {
    	document.getElementById("replacementcostfms").innerHTML="*Replacement cost should be between 1 to 3000"; 
    	filmreplace.focus();  
		return false; 
    }
    

  //Validation for ReleaseDate And RentalDuration where Rental duration must be greater than Release date

    	function isrentaldurationvalid(){
    		
    		var ReleaseDate=fms.releasedate.value;
    		var RentalDuration=fms.rentalduration.value;


    	    	
    	    	 if(RentalDuration>ReleaseDate){
    	    	
    	    	
    	    	document.getElementById("rentalduration").innerHTML="";
    			return true;  
    	    }
    	    else
    	    {
    	    	document.getElementById("rentalduration").innerHTML="*Rental Duration should be Greater than Release Date"; 
    	    	rentalduration.focus();  
    			return false; 
    	    }
    	    
    		
    	}	 
    	 
    	 
	
}

function validateForm(){
	
	if(istitlevalidate()&&isdescriptionvalidate()&&islengthvalid() )
	{
		return true;
	}
	else
		
		return false;
	
}

function validateField(){
	LoginUser user=new LoginUser();
	var flag=true;
	var uname=form1.uname.value;
	
	var upwd=form1.upwd.value;
	
		if(uname==""||uname==null)
		{
		document.getElementById("unameErr").innerHTML="*Please enter UserName";
		flag=false;
		}
		else{
			 document.getElementById("unameErr").innerHTML="";
		}
	
		if(upwd==""||upwd==null)
		{
		document.getElementById("upwdErr").innerHTML="*Please enter Password";
		flag=false;
		}else{
			document.getElementById("upwdErr").innerHTML="";
	
	
         }
		
//		var uname_form=uname;
//		var uname_db = user.userName;
//		 user_compare_result= uname_form.match(uname_db); 
//		
//		var upassword_form=upwd;
//		var upasswd_db= user.userPwd;
//		var password_compare_result= upassword_form.match(upasswd_db); 
//		 
//		if()
//		document.getElementById("upwdErr").innerHTML="*Please enter Password";
//		
return flag;

	
}


function isValidTitle(){
	
	var pattern=/[A-Za-z0-9@., ]+$/;
	
	if(document.getElementById("title").value.match(pattern))	
		return true;
	else
		return false;
}
