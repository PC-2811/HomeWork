function validateForm()
{
	IFilmService filmService=new FilmServiceImpl();
	var flag=true;
	var title=fms.filmtitle.value;
	var length=filmlength.value;
	//var rate=addfilm.rate.value;
	var cost = fms.replacementcost.value;
	//var orglanguage=addfilm.orglang.selectedIndex;
	//var actors=addfilm.actors.selectedIndex;
	//var category=addfilm.category.value;
	
	
	if (title == null || title == ""||!isValidTitle()) {
       document.getElementById("title_val").innerHTML="*Please enter Film Name!";
        flag=false;
    }else
    	document.getElementById("title_val").innerHTML="";
	
	
	if(length==null||length==""||!isValidLength()){
		document.getElementById("length_val").innerHTML="*Please enter valid Film Length!";
        flag=false;
    }else
    	document.getElementById("length_val").innerHTML="";
	
//	
//	if(rate==null||rate==""||!isValidRate()){
//		document.getElementById("rate_val").innerHTML="*Please enter Rating between 1 and 5!";
//        flag=false;
//    }else
//    	document.getElementById("rate_val").innerHTML="";
//	
	
	if(!isValidRentalDate()){
		
		document.getElementById("rental_val").innerHTML="*Rental Duration should be future date than Release Year";
		flag = false;
	}
		
	else
		document.getElementById("rental_val").innerHTML="";
	
	if(cost==""||cost==null||!isValidNumber()){
		document.getElementById("cost_val").innerHTML="*Only numbers are allowed!";
		flag = false;
	}
	else
		document.getElementById("cost_val").innerHTML="";
	
	
	return flag;
}

function isValidTitle(){
	
	var pattern=/[A-Za-z0-9@., ]+$/;
	
	if(document.getElementById("title").value.match(pattern))	
		return true;
	else
		return false;
}

function isValidLength(){
	var length=addfilm.length.value;
	var length1=parseInt(length);
	if(length1>0 && length1<=1000)
		return true;
	else
		return false;
}

function isValidRate(){
	var rate=addfilm.rate.value;
	
	if(rate>0 && rate<=5)
		return true;
	else
		return false;
}

function isValidRentalDate(){
	
	var releaseDate=new Date(addfilm.reldate.value).getTime();
	var rentalduration=new Date(addfilm.rendur.value).getTime();
	
	if(rentalduration >= releaseDate)
    	return true;
    else
    	return false;
}

function isValidNumber(){
	
	var numbers = /^[0-9]+(.)?[0-9]*$/;  
	var cost = addfilm.cost.value;
	
    if(cost.match(numbers))  
    	return true;
    else
    	return false;
}



