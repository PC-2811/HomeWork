package org.flp.fms.Test;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.flp.fms.dao.ActorDaoImplForList;
import com.flp.fms.domain.Actor;

public class ActorDaoImplForList_Test {
    
	ActorDaoImplForList actorDao=new ActorDaoImplForList();
	
	@Test
	public void test_getActors() {
		assertEquals(6, actorDao.getActors().size());
	}
	@Test
	public void test_getActors_List() {
		List<Actor> actor=new ArrayList<>();
		actor.add(new Actor(4, "Abhishek", "Bacchan"));
		actor.add(new Actor(5, "Amir", "Khan"));
		assertEquals(actor, actorDao.getActors());
	}

}


