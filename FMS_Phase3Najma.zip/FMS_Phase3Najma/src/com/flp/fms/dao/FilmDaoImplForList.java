package com.flp.fms.dao;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.domain.LoginUser;

public class FilmDaoImplForList implements IFilmDao{
	
	private Map<Integer, Film> film_Repository=new HashMap<>();
	
	
	//Get All Languages
	@Override
	public List<Language> getLanguages() {
		
		//create language Array list 
		List<Language> languages=new ArrayList<>();
		
		//create connection instance
        Connection con= ActorDaoImplForList.getConnection();
		//Select each row from language1 table and set into language object 
		String sql="select * from LANGUAGE1";
		
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			ResultSet rs=pst.executeQuery();
			
			while(rs.next())
			{
				Language lang1=new Language();
				lang1.setLanguage_Id(rs.getInt(1));
				lang1.setLanguage_Name(rs.getString(2));
				languages.add(lang1);
				
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return languages;
	}


	//Get All Categories
	
	public List <Category> getCategory(){
		
		//create Category Array list 
		List<Category> category=new ArrayList<>();
		
		//create connection instance
        Connection con= ActorDaoImplForList.getConnection();
		
      //Select each row from category table and set into category object 
		String sql="select * from CATEGORY";
		
		System.out.println("Category get started");
		
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			ResultSet rs=pst.executeQuery();
			
			while(rs.next())
			{
				Category cat1=new Category();
				cat1.setCategoryId(rs.getInt(1));
				cat1.setName(rs.getString(2));
				System.out.println(cat1);
				category.add(cat1);
				
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		return category;
		
	}
	
	//ADD film into the Database
		@Override
		public int addFilm(Film film) {
			
			Connection con= ActorDaoImplForList.getConnection();
			
			String sql="insert into film(title,description,releaseYear,originalLanguage,rentalDuration,LENGTH,replacementCost,ratings,specialFeatures,category)"
					+ "	 values(?,?,?,?,?,?,?,?,?,?)";
			
			int count=0;
			try {
				PreparedStatement pst=con.prepareStatement(sql);
				pst.setString(1, film.getTitle());
				pst.setString(2, film.getDescription());
				
				pst.setDate(3, new Date(film.getReleaseYear().getTime()));
				int language=film.getOriginallanguage().getLanguage_Id();
				pst.setInt(4, language);
				pst.setDate(5, new Date(film.getRentalDuration().getTime()));
				pst.setInt(6, film.getLength());
				pst.setDouble(7,film.getReplacementCost());
				
				pst.setInt(8,film.getRatings());
				pst.setString(9,film.getSpecialFeatures());
				int category=film.getCategory().getCategoryId();
				pst.setInt(10,category);
				
				
				
				count=pst.executeUpdate();
				
				//Fetching last film id 
				String sql1="select film_id from film order by film_id desc limit 1 ";
				PreparedStatement pst1=con.prepareStatement(sql1);
				ResultSet rs=pst1.executeQuery();
				int filmid=0;
				while(rs.next())
				{
					filmid=rs.getInt(1);
					
				}
			
		
				String sql2="insert into film_language values(?,?)";
				PreparedStatement pst2=con.prepareStatement(sql2);
			     List<Language> lang=film.getLanguage();
			     System.out.println(lang);
				for(Language lang1:lang){
				pst2.setInt(1, filmid);
				pst2.setInt(2,lang1.getLanguage_Id());
			    count=pst2.executeUpdate();
				}
				
				String sql3="insert into film_actors values(?,?)";
				PreparedStatement pst3=con.prepareStatement(sql3);
			    Set<Actor> actor=film.getActors();
				for(Actor act1:actor){
				pst3.setInt(1, filmid);
				pst3.setInt(2,act1.getActorId());
				 count=pst3.executeUpdate();
				}
			}
	catch (SQLException e) {
			
			e.printStackTrace();
		
	}
			
			return count;
			
		}


		
		@Override
		public Map<Integer, Film> searchfilm() {
			// TODO Auto-generated method stub
			return film_Repository;
			
		}

		@Override
		public Map<Integer, Film> removefilm() {
			// TODO Auto-generated method stub
			return film_Repository;
		}



//  displaying film details from Data-Base 
		
			@Override
			public ArrayList<Film> getAllFilms() {
				
				
				 Connection con=ActorDaoImplForList.getConnection();	
				 
				 ArrayList<Film> films=new ArrayList<Film>();
				
				 String sql="select * from film";
				 
					try {
						PreparedStatement pst=(PreparedStatement) con.prepareStatement(sql);
						ResultSet rs=pst.executeQuery();
						while(rs.next())
						{
							Film film=new Film();
							film.setFilmId(rs.getInt(1));
							film.setTitle(rs.getString(2));
							film.setDescription(rs.getString(3));
							film.setReleaseYear(rs.getDate(4));
							
							String subsql;
							subsql="select language_Name from LANGUAGE1 where language_Id="+rs.getInt(5);
							PreparedStatement pst1=con.prepareStatement(subsql);
							ResultSet rs3=pst1.executeQuery();
							Language lang=new Language();
							if(rs3.next())
							{
								lang.setLanguage_Id(rs.getInt(5));
								lang.setLanguage_Name(rs3.getString(1));
							}
							film.setOriginallanguage(lang);
							film.setRentalDuration(rs.getDate(6));
							film.setLength(rs.getInt(7));
							film.setReplacementCost(rs.getInt(8));
							film.setRatings(rs.getInt(9));
							film.setSpecialFeatures(rs.getString(10));
							
							subsql="select Name from category where categoryID="+rs.getInt(11);
							PreparedStatement pst3=con.prepareStatement(subsql);
						    rs3=pst3.executeQuery();
							if(rs3.next())
							{
								Category cat=new Category();
								cat.setCategoryId(rs.getInt(11));
								cat.setName(rs3.getString(1));
								film.setCategory(cat);
							}
							
							subsql="select language_id from film_language where film_id="+rs.getInt(1);
							System.out.println(rs.getInt(1));
							pst3=con.prepareStatement(subsql);
						    rs3=pst3.executeQuery();
						    List<Language> languages=new ArrayList<>();
							while(rs3.next())
							{
														
								String subsql1="select language_Name from LANGUAGE1 where language_Id="+rs3.getInt(1);
								PreparedStatement pst2=con.prepareStatement(subsql1);
								ResultSet rs1=pst2.executeQuery();
								while(rs1.next()){
									Language langs=new Language();
									langs.setLanguage_Id(rs3.getInt(1));
									langs.setLanguage_Name(rs1.getString(1));
									languages.add(langs);
									
								}
							}
							film.setLanguage(languages);
							subsql="select actor_id from film_actors where film_id="+rs.getInt(1);
						
							pst3=con.prepareStatement(subsql);
						    rs3=pst3.executeQuery();
						  Set<Actor> actors=new HashSet<>();
						   // List<Actor> actors = new ArrayList<>();
							while(rs3.next())
							{
								String subsql1="select FirstName,LastName from ACTOR where ActorId="+rs3.getInt(1);
								PreparedStatement pst2=con.prepareStatement(subsql1);
								ResultSet rs1=pst2.executeQuery();
								while(rs1.next()){
									Actor actr=new Actor();
									actr.setFirstName(rs1.getString(1));
									//System.out.println("******"+rs1.getString(1));
									actr.setLastName(rs1.getString(2));
									actr.setActorId(rs3.getInt(1));
									actors.add(actr);
									
								}
							}
							film.setActors((Set<Actor>) actors);
							film.setLanguage(languages);
							System.out.println(film);
							films.add(film);
						}
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					return films;
				
				
			}
			
// deleting film from database

			@Override
			public Boolean deleteFilm(int filmid) {
				Connection con=ActorDaoImplForList.getConnection();
				boolean flag=false;
				String sql="delete from film where film_id=?";
				String sql1="delete from film_language where film_id=?";
				String sql2="delete from film_actors where film_id=?";
				
				try {
					PreparedStatement pst=con.prepareStatement(sql);
					pst.setInt(1, filmid);
					int count=pst.executeUpdate();
					PreparedStatement pst1=con.prepareStatement(sql1);
					pst.setInt(1, filmid);
					int count1=pst.executeUpdate();
					PreparedStatement pst2=con.prepareStatement(sql2);
					pst.setInt(1, filmid);
					int count2=pst.executeUpdate();
					
					if(count>0 && count1>0 && count2>0)
						flag=true;
					
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
						return false;
			}


//// Search operation 

			@Override
			public ArrayList<Film> searchFilm(Film film) {
				Connection con=ActorDaoImplForList.getConnection();
				int count=0;
				String sql="select * from film where";
				ArrayList<Film> films=new ArrayList<Film>();
				System.out.println(film);
				if(film!=null)
				{
					if(film.getFilmId()>0)
					{
						
						sql+=" film_id="+film.getFilmId();
						
						count=1;
					}
					
					if(film.getTitle()!=null)
					{
						if(count==1)
						{
							sql+=" and title='"+film.getTitle()+"'";
						}
						else
						{
							sql+=" title='"+film.getTitle()+"'";
						}
						count=2;
					}
				

					if(film.getRatings()>0)
					{
						if(count==1||count==2)
						{
							sql+=" and ratings="+film.getRatings();
						}
						else
						{
							sql+=" ratings="+film.getRatings();
						}
						count=3;
					}
					if(film.getActors()!=null)
					{
						Actor actor=new Actor();
						Set<Actor> act=film.getActors();
						for(Actor a:act)
							actor=a;
						if(count==1||count==2||count==3)
						{
							sql+=" and film_id In(Select film_id from film_actors where actor_id="+actor.getActorId()+")";
							
						}else
						{
						sql+=" film_id In(Select film_id from film_actors where actor_id="+actor.getActorId()+")";
						}
						count=4;
					}
					if(film.getLanguage()!=null)
					{
						Language lang=new Language();
						List<Language> langs=film.getLanguage();
					
						for(Language l:langs)
							lang=l;
						if(count==1||count==2||count==3||count==4)
						{
							sql+=" and( film_id In(Select film_id from film_language where language_id="+lang.getLanguage_Id()+") or film_id In( Select film_id from film where originallanguage="+lang.getLanguage_Id()+"))";
							
						}else
						{
						sql+=" ( film_id In(Select film_id from film_language where language_id="+lang.getLanguage_Id()+") or film_id In (Select film_id from film where originallanguage="+lang.getLanguage_Id()+"))";
						
						}
						count=5;
					}
				
					 
					if(film.getReleaseYear()!=null)
					{
						if(count==1||count==2||count==3||count==4||count==5)
						{
							sql+=" and releaseYear='"+new java.sql.Date(film.getReleaseYear().getTime())+"'";
						}
						else
						{
							sql+=" releaseYear='"+new java.sql.Date(film.getReleaseYear().getTime())+"'";
						}
						count=6;
					}
					System.out.println(sql);
					try {
						PreparedStatement pst=con.prepareStatement(sql);
						ResultSet rs=pst.executeQuery();
					System.out.println("At yet ok");
						while(rs.next())
						{
							Film film1=new Film();
							film1.setFilmId(rs.getInt(1));
							film1.setDescription(rs.getString(3));
							film1.setTitle(rs.getString(2));
							film1.setReleaseYear(rs.getDate(4));
							
							String subsql;
							subsql="select language_Name from LANGUAGE1 where language_Id="+rs.getInt(5);
							PreparedStatement pst1=con.prepareStatement(subsql);
							ResultSet rs3=pst1.executeQuery();
							Language lang=new Language();
							if(rs3.next())
							{
								lang.setLanguage_Id(rs.getInt(5));
								lang.setLanguage_Name(rs3.getString(1));
							}
							film1.setOriginallanguage(lang);
							film1.setRentalDuration(rs.getDate(6));
							film1.setLength(rs.getInt(7));
							film1.setReplacementCost(rs.getInt(8));
							film1.setRatings(rs.getInt(9));
							film1.setSpecialFeatures(rs.getString(10));
							
							subsql="select name from CATEGORY where CategoryId="+rs.getInt(11);
							PreparedStatement pst3=con.prepareStatement(subsql);
						    rs3=pst3.executeQuery();
							if(rs3.next())
							{
								Category cat=new Category();
								cat.setCategoryId(rs.getInt(11));
								cat.setName(rs3.getString(1));
								film1.setCategory(cat);
							}
							
							subsql="select language_Id from film_language where film_id="+rs.getInt(1);
							System.out.println(rs.getInt(1));
							pst3=con.prepareStatement(subsql);
						    rs3=pst3.executeQuery();
						    List<Language> languages=new ArrayList<>();
							while(rs3.next())
							{
														
								String subsql1="select language_Name from LANGUAGE1 where language_Id="+rs3.getInt(1);
								PreparedStatement pst2=con.prepareStatement(subsql1);
								ResultSet rs1=pst2.executeQuery();
								while(rs1.next()){
									Language langs=new Language();
									langs.setLanguage_Id(rs3.getInt(1));
									langs.setLanguage_Name(rs1.getString(1));
									languages.add(langs);
									
								}
							}
							film1.setLanguage(languages);
							subsql="select actor_id from film_actors where film_id="+rs.getInt(1);
						
							pst3=con.prepareStatement(subsql);
						    rs3=pst3.executeQuery();
						    Set<Actor> actors=new HashSet<>();
							while(rs3.next())
							{
								String subsql1="select FirstName,LastName from ACTOR where ActorId="+rs3.getInt(1);
								PreparedStatement pst2=con.prepareStatement(subsql1);
								ResultSet rs1=pst2.executeQuery();
								while(rs1.next()){
									Actor actr=new Actor();
									actr.setFirstName(rs1.getString(1));
									actr.setLastName(rs1.getString(2));
									actr.setActorId(rs3.getInt(1));
									actors.add(actr);
									
								}
							}
							film1.setActors(actors);
							film1.setLanguage(languages);
							System.out.println(film1);
							films.add(film1);
					} }catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				
					
				}
				
				return films;
			}


// Modifying Film

			@Override
			public Boolean modifyFilm(Film film) {
				Connection con=ActorDaoImplForList.getConnection();

				 String sql="Update film Set description=?,title=?,releaseYear=?,originallanguage=?,rentalDuration=?,LENGTH=?,replacementCost=?,ratings=?,specialFeatures=?,category=? where film_id="+film.getFilmId();
				 
				 try {
					 	PreparedStatement pst = con.prepareStatement(sql);
						pst.setString(1,film.getDescription() );
						pst.setString(2,film.getTitle() );	
						pst.setDate(3,new java.sql.Date(film.getReleaseYear().getTime()));
						pst.setInt(4,film.getOriginallanguage().getLanguage_Id());
						pst.setDate(5,new java.sql.Date(film.getRentalDuration().getTime()));
						pst.setInt(6,film.getLength());
						pst.setDouble(7,film.getReplacementCost());
						pst.setInt(8,film.getRatings());
						pst.setString(9,film.getSpecialFeatures());
						Category cat=film.getCategory();
						pst.setInt(10,cat.getCategoryId());
						int count=pst.executeUpdate();
						//if insertion to film table is success execute
						if(count>0){
							
							//insertion to third party tables
							int filmId=film.getFilmId();
							
									
							sql="delete from film_actors where film_id="+filmId;
							PreparedStatement stmt = con.prepareStatement(sql);
							int count1= stmt.executeUpdate();
							
							sql="insert into film_actors(film_id,actor_id) values(?,?)";
							pst = con.prepareStatement(sql);
							
							//getting all the actors in the film
							Set<Actor> actors = film.getActors();			
							for(Actor act: actors){
								pst.setInt(1, filmId );
								pst.setInt(2, act.getActorId());
								
								count=pst.executeUpdate();
							}
							
							sql="delete from film_language where film_id="+filmId;
							 stmt = con.prepareStatement(sql);
							 count1= stmt.executeUpdate();
											
							sql="insert into film_language(film_id,language_Id) values(?,?)";
							pst = con.prepareStatement(sql);
							
							//getting all the other languages
							List<Language> languages = film.getLanguage();				
							for(Language lang: languages){
								pst.setInt(1, filmId );
								pst.setInt(2, lang.getLanguage_Id());
								
								count=pst.executeUpdate();
							}
						
					}} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				 return null;
			}





public boolean isValidLogin(LoginUser loginUser) {
	boolean flag=false;
	Connection con=ActorDaoImplForList.getConnection();
	String sql="select * from userlogin where username=? and userpassword=?";
	try {
		PreparedStatement pst=con.prepareStatement(sql);
		pst.setString(1, loginUser.getUserName());
		pst.setString(2, loginUser.getUserPwd());
		
		ResultSet rs=pst.executeQuery();
		
		if(rs.next())
			flag=true;
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	
	
	return flag;
}
			}
		
		




