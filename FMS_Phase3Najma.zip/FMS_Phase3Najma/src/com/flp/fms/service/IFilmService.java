package com.flp.fms.service;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.domain.LoginUser;

public interface IFilmService {
	public boolean isValidLogin(LoginUser loginUser);
	public List<Language> getLanguages();
	public List<Category> getCategory();
	public int addFilm(Film film);
	//public Map<Integer, Film> getAllFilms();
	public Map<Integer, Film> searchfilm();
	public Map<Integer, Film> removefilm();
	
	public ArrayList<Film>getAllFilms();
	
	Boolean deleteFilm(int filmid);
	
	ArrayList<Film> searchFilm(Film film);
	
	Boolean modifyFilm(Film film);
}

	
	

