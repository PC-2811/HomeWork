package com.flp.fms.service;
import java.util.Set;

import com.flp.fms.dao.ActorDaoImplForList;
import com.flp.fms.dao.IActorDao;
import com.flp.fms.domain.Actor;
public class ActorServiceImpl implements IActorService{

	private IActorDao actorDao=new ActorDaoImplForList();
	
	@Override
	public Set<Actor> getActors() {
		// TODO Auto-generated method stub
		return actorDao.getActors();
	}

	@Override
	public int addActor(Actor actor) {
		
		return actorDao.addActors(actor);
	}

	@Override
	public Boolean deleteActor(int actor_Id) {
		// TODO Auto-generated method stub
		
			
		return	actorDao.deleteActor(actor_Id);
		}

	@Override
	public Actor getActor(int actorId) {
		
			
			return actorDao.getActor(actorId);
		
		
	}

	@Override
	public int updateActor(Actor actor) {
		// TODO Auto-generated method stub
		return actorDao.updateActor(actor);
	}
		
	}

//	public Actor getActor(int actorId) {
//		
//		return actorDao.getActor(actorId);
//	}



