package com.flp.fms.service;
import java.util.ArrayList;
import java.util.List;

import com.flp.fms.dao.FilmDaoImplForList;
import com.flp.fms.dao.IFilmDao;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Language;
import com.flp.fms.domain.LoginUser;

import java.util.Map;
import java.util.Set;
import com.flp.fms.domain.Film;


public class FilmServiceImpl implements IFilmService{
	
	private IFilmDao filmDao=new FilmDaoImplForList();

	@Override
	public List<Language> getLanguages() {
		
		return filmDao.getLanguages();
	}

public List<Category> getCategory() {
		
		return filmDao.getCategory();
}
@Override
public int addFilm(Film film) {
	

	return filmDao.addFilm(film);
	
}

	public Map<Integer, Film> searchfilm() {
		
		return filmDao.searchfilm();
	
}
	
	@Override
	public Map<Integer, Film> removefilm() {
		// TODO Auto-generated method stub
		return filmDao.removefilm();
	}

	@Override
	public ArrayList<Film> getAllFilms() {
		// TODO Auto-generated method stub
		return filmDao.getAllFilms();
	}
	
    @Override
    public Boolean deleteFilm(int filmid) {
	// TODO Auto-generated method stub
	return filmDao.deleteFilm(filmid);
}

	@Override
	public ArrayList<Film> searchFilm(Film film) {
		// TODO Auto-generated method stub
		return filmDao.searchFilm(film);
		
		}

	@Override
	public Boolean modifyFilm(Film film) {
		// TODO Auto-generated method stub
		return filmDao.modifyFilm(film);
	}

	@Override
	public boolean isValidLogin(LoginUser loginUser) {
		// TODO Auto-generated method stub
		return filmDao.isValidLogin(loginUser);
	}
	}


