package com.capgemini.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.service.ActorServiceImpl;
import com.flp.fms.service.IActorService;

public class DeleteActor_ShowTable extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();		
		IActorService actorService=new ActorServiceImpl();
		
		Set<Actor> actors=actorService.getActors();
		
		out.println("<html>");
		out.println("<head>"
				+ "<link rel='stylesheet' type='text/css' href='css/myStyle.css'>"
				+ "<script type='text/javascript' src='script/validate.js'></script>"
				+ "<title>Delete Actors</title></head>"
				+ "<h2 align='center'>Delete Actors</h2>"
				+ "<body>"
				+ "<div style='margin-left:500px;'>  </div>"
				+ "<table border=1>"
				+ "<tr>"
				+ "<th>Actor Id</th>"
				+ "<th>First Name</th>"
				+ "<th>Last Name</th>"
				+ "<th>Edit</th>"
				+ "</tr>");
		
			for(Actor actor:actors){
				out.println("<tr>"
					+"<td>"+actor.getActorId()+"</td>"
					+"<td>"+actor.getFirstName()+"</td>"
					+"<td>"+actor.getLastName()+"</td>");				
				
				out.println("<td><a href=' DeleteActorServlet?actorId="+actor.getActorId()+"'>Delete</a></td>");
				
				out.println("</tr>");
			}
				out.println("</table></center></body>");
	
				out.println("</html>");
	}

	}


