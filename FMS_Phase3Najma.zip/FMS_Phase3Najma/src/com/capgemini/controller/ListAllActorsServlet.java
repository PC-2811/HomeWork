package com.capgemini.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.service.ActorServiceImpl;
import com.flp.fms.service.IActorService;


public class ListAllActorsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
     IActorService actorService=new ActorServiceImpl();
		
		Set<Actor> actors=actorService.getActors();		
					
		PrintWriter out=response.getWriter();
		
		out.println("<html>");
		out.println("<head>"
				+ "<link rel='stylesheet' type='text/css' href='css/myStyle.css'>"	
				+ "<h2 align='center'>List Of Actors</h2>"+ "<title>List All Actors</title></head>"
				+ "<body>"
				+ "<div style='margin-left:500px;'>  </div>"
				+ "<table border=1>"
				+ "<tr>"
				+ "<th>Actor Id</th>"
				+ "<th>First Name</th>"
				+ "<th>Last Name</th>"
				+ "</tr>");
		
			for(Actor actor:actors){
				out.println("<tr>");
				out.println("<td>"+actor.getActorId()+"</td>");
				out.println("<td>"+actor.getFirstName()+"</td>");
				out.println("<td>"+actor.getLastName()+"</td>");
				out.println("</tr>");
			}
				out.println("</table></center></body>");
	
				out.println("</html>");
	}
}
			
