package com.capgemini.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IFilmService;

//Save Film Details.....
public class AddFilm extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		//create  a printWriter object	
		  PrintWriter out=response.getWriter();
		
		  
		  IFilmService filmService=new FilmServiceImpl();
		
		
		  //Set film Details retrieved from UserInteraction servlet, in Film Object 
		  Film film=new Film();
		 
		
		  //Set Film Title
		  film.setTitle(request.getParameter("filmtitle"));
		 
		 
		  //Set Film Description
		  film.setDescription(request.getParameter("filmdescription"));
		 
		
		  //Set Film Length
		  film.setLength(Integer.parseInt(request.getParameter("filmlength")));
		 
		 
		  // Set original Language
		  Language lang=new Language(); 
			lang.setLanguage_Id(Integer.parseInt(request.getParameter("orglanguage")));
	    	film.setOriginallanguage(lang);
		
	   
	    // Set other Languages	
		  List<Language> languages=new ArrayList<>();
			 String[] str=request.getParameterValues("othrlanguage");
			 for(String str1:str)
			   {
					Language lang1=new Language(); 
					lang1.setLanguage_Id(Integer.parseInt(str1));
					languages.add(lang1);
				}
		
			
		// Set Ratings	
			film.setRatings(Integer.parseInt(request.getParameter("rating")));
		
			
		// Set ReplacementCost		
			film.setReplacementCost(Double.parseDouble(request.getParameter("replacementcost")));
		
			
		// Set ReleaseYear		
			film.setReleaseYear(new Date(request.getParameter("releasedate")));
		
			
		// Set RentalDuration		
			film.setRentalDuration(new Date(request.getParameter("rentalduration")));
		
			
		// Set SpecialFeatures	
			film.setSpecialFeatures(request.getParameter("specialfeature"));
		
			
		//Set Actors	
			Set<Actor> actors=new HashSet();
			
				String[] str3=request.getParameterValues("actor");
				for(String str1:str3){
					Actor actor1=new Actor(); 
					actor1.setActorId(Integer.parseInt(str1));
					actors.add(actor1);
				}
				film.setActors(actors);
		
				
		//Set Category 	
				Category cat=new Category();
				cat.setCategoryId(Integer.parseInt(request.getParameter("category")));
				film.setCategory(cat);
				
				
		
				
		//Calling the addFilm Method to save the Film object		
				filmService.addFilm(film);
		
				
		//After saving it remains in the same Create Film page		
				response.sendRedirect("UserInteraction01");
			}

			
			}




