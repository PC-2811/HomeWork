package com.capgemini.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Language;
import com.flp.fms.service.ActorServiceImpl;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IActorService;
import com.flp.fms.service.IFilmService;


public class SearchPageServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		IFilmService filmService =new FilmServiceImpl();
		IActorService actorService=new ActorServiceImpl();
		
		// Retrieving list of languages and category and set of actors
		List<Language> languages=filmService.getLanguages();
		Set<Actor>actors=actorService.getActors();
		List<Category>category=filmService.getCategory();
		
		//create Print Writer object 'out'
		PrintWriter out=response.getWriter();
		
		//  Creating a  SEARCH FORM...... 
		out.println("<html>");
		out.println("<head><title>Search Film</title>");
		out.println("<script type='text/javascript' src=''></script>"
				+ "<link rel='stylesheet' type='text/css' href='Css/myStyle.css'>"
				+"<meta charset='ISO-8859-1'>"
		        + "<link href='http://code.jquery.com/ui/1.10.4/themes/ui-lightness/jquery-ui.css' rel='stylesheet'>"
		        +" <script src='http://code.jquery.com/jquery-1.10.2.js'></script>"
		        +" <script src='http://code.jquery.com/ui/1.10.4/jquery-ui.js'></script>"
		        +"<!-- Javascript -->"
		        +"  <script>"
		        +"       $(function() {"
		        +"       $( '#datepicker1' ).datepicker({maxDate:'0', dateFormat:'dd-MM-yy'});"
		        +"    $( '#datepicker1' ).datepicker('show');"
		        +"});"
		        + "</script>");
		out.println("</head>"+"<body>");
		out.println("<form name='searchForm' action='SearchServlet'");
		out.println("<h2 ><b>Search Films.....</b></h2>");
		out.println("<div>");
		out.println("<table>");
		out.println("<tr>"
				+ "<td>");
	//Display text box for retrieving film id from user
		out.println(" Enter Film Id: &nbsp <input type='textbox' name='byId'/> ");
		out.println("</td>"
				+ "</tr>");
		out.println("<tr>"
    			+ "<td>");
  //Display text box for retrieving film rating from user
		out.println("Film Rating:&nbsp &nbsp &nbsp<input type='textbox' name='byRating'/> ");
		out.println("</td>"	+ "</tr>");
		
		
 //Display text box for retrieving release date from user	
		out.println("	<tr>"
				+"	<td>Release Date:&nbsp&nbsp &nbsp<input type='text' id='datepicker1' name='releasedate' size='20'>"
				+"	</td>"
				+"	</tr>");
		out.println("<tr>"
				+ "	<td>");
 //Display text box for retrieving title from user		
		out.println("Film Title:&nbsp &nbsp &nbsp &nbsp  <input type='textbox' name='byTitle'/> ");
		out.println("</td>"
				+ "</tr>"
				+ "<tr>"
				+ "<td>");
		
 //Display Drop dowm box  for retrieving Languages from user	
		out.println("By Language:&nbsp  &nbsp<select name='byLanguage'>"
				+"<option value='0'>--Select--</option>");
		  for(Language lang:languages)
		  {
				out.println("<option value='"+ lang.getLanguage_Id()+"'>"+lang.getLanguage_Name()+ "</option>");	
		   }
		out.println("</select>");
		out.println("</td></tr>");
		out.println("<tr><td>");
		
 //Display Drop Down box for retrieving Actors from user	
		out.println("By Actor:&nbsp &nbsp &nbsp &nbsp &nbsp <select name='byActor'>"
				+ "<option value='0'>--Select--</option>");
		for(Actor act: actors)
		{
			out.println("<option value='"+act.getActorId()+"'>"
					+act.getFirstName()+" "+act.getLastName()
					+"</option>");
			
		}
		out.println("</select>");
		out.println("</td>");
		out.println("</tr>"
				+ "<tr>"
				+ "<td>"
				+ "<input type='submit' value='search' name='search'>"
				+ "</td>"
				+ "</tr>"
				);

		out.println("</table>");
		out.println("</div>");
		out.println("</form>");
		out.println("</body>");
		out.println("</html>");
	}
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
