package com.capgemini.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.service.ActorServiceImpl;
import com.flp.fms.service.IActorService;

public class SetNewActor extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

PrintWriter out=response.getWriter();
		
		Actor actor=new Actor();
		actor.setFirstName(request.getParameter("actorFirstName"));
		actor.setLastName(request.getParameter("actorLastName"));
		
		IActorService actorService=new ActorServiceImpl();
		
		int count=actorService.addActor(actor);
		if(count==1)
		{
			request.getRequestDispatcher("AddActor").include(request, response);
		out.println("<html>"
				+"<head>"
				+"<title>Add Actor</title>"
				+"</head>");
		out.println("<body>");
		out.println("<h2>Actor Added Successfully</h2>"
				+ "</body></html>");
		}
	}

		
		
	}


