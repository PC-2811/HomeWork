package org.capgemini.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.capgemini.pojo.Employee;
import org.capgemini.service.LoginService;
import org.capgemini.service.LoginServiceImpl;

/**
 * Servlet implementation class DisplayEmpServlet
 */
public class DisplayEmpServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		LoginService loginService=new LoginServiceImpl();
		String empId=request.getParameter("empId");
		String firstName=request.getParameter("fname");
		
		Employee employee=new Employee();
		employee.setEmpId(Integer.parseInt(empId));
		employee.setFirstName(firstName);
		
		
		System.out.println("FirstName:" + firstName);
		//Employee emp=loginService.searchEmployee(Integer.parseInt(empId));
		
		
		List<Employee> emps=loginService.searchAllEmployee(employee);
		
		
		PrintWriter out=response.getWriter();
		
		out.println("<h1 align='center'>Employee Details</h1>");
		/*out.println("<b>Employee Id: </b>" + emp.getEmpId() +"<br><br>" );
		out.println("<b>Employee FirstName: </b>" + emp.getFirstName() +"<br><br>" );
		out.println("<b>Employee LastName: </b>" + emp.getLastName() +"<br><br>" );
	*/
	
		out.println("<table>");
		out.println("<tr>");
		out.println("<th>EmpId</th>");
		out.println("<th>FirstName</th>");
		out.println("<th>LastName</th>");
		out.println("<th>Address</th>");
		out.println("</tr>");
		
		for(Employee emp:emps)
		{
			out.println("<tr>");

			out.println("<td>" + emp.getEmpId() +"</td>");
			out.println("<td>" + emp.getFirstName() +"</td>");
			out.println("<td>" + emp.getLastName() +"</td>");
			out.println("<td>" + emp.getAddress() +"</td>");
			out.println("</tr>");
		}
		out.println("</table>");
		
	
	}

}
