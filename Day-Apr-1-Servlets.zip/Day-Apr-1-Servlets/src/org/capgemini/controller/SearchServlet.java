package org.capgemini.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.capgemini.pojo.Employee;
import org.capgemini.service.LoginService;
import org.capgemini.service.LoginServiceImpl;

/**
 * Servlet implementation class SearchServlet
 */
public class SearchServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		LoginService loginService=new LoginServiceImpl();
		ArrayList<Employee> employees=loginService.getAllEmployees();
		PrintWriter out=response.getWriter();
		out.println("<html>");
		out.println("<head><title>Search Employee</title>"
				+ "<script type='text/javascript' src='script/validate.js'></script>"
				+ "<link rel='stylesheet' type='text/css' href='css/mystyles.css'>"
							
				+ "</head>"
				+ "<body><form name='f1'>"
				+ "<div>"
				+ "<label>Choose Employee Id</label>"
				+ "<select name='empId'>");
		for(Employee emp:employees){
			out.println("<option value='"+ emp.getEmpId()+"'>" + emp.getEmpId() +"</option>");
		}
				out.println("</select>"
						+ "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label>FirstName:</label>"
						+ "<input type='text' name='fname' size='20'>"
						+ "<input type='button' name='Search' value='Search' onClick='displayEmployee()'>"
				+ "</div>"
				+ "<div id='displayEmp'> "
				+ "<h2>Employee Details</h2>"
				
				+ "</div>"
				+ "</form></body>");
		
		
		out.println("</html>");
	
	}

}
