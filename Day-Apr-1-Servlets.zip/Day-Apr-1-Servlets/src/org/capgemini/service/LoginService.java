package org.capgemini.service;

import java.util.ArrayList;
import java.util.List;

import org.capgemini.pojo.Employee;
import org.capgemini.pojo.LoginUser;

public interface LoginService {
	
	public boolean isValidLogin(LoginUser loginUser);
	public void saveEmployee(Employee employee);
	public ArrayList<Employee> getAllEmployees();
	public boolean deleteEmployee(int empId);
	public Employee searchEmployee(int employeeId);
	public List<Employee> searchAllEmployee(Employee employee);

}
