package org.capstore.domain;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.OneToOne;
import javax.persistence.Transient;

@Entity
public class Delivery {

	@Id
	@GeneratedValue
	private int delivery_id;
	
	private int invoice_no;
	
	@OneToOne//(targetEntity=Order.class)
	@JoinColumns({@JoinColumn(name="order_id_FK",referencedColumnName="order_id",insertable=true,updatable=false)})
	private Order_details order;
	
	private String status;
	
	@Transient
	@OneToOne//(mappedBy="order",targetEntity=Delivery.class)
	private Tracking tracking;

	public Delivery(int delivery_id, int invoice_no, Order_details order, String status, Tracking tracking) {
		super();
		this.delivery_id = delivery_id;
		this.invoice_no = invoice_no;
		this.order = order;
		this.status = status;
		this.tracking = tracking;
	}

	public Delivery(int invoice_no, Order_details order, String status, Tracking tracking) {
		super();
		this.invoice_no = invoice_no;
		this.order = order;
		this.status = status;
		this.tracking = tracking;
	}

	public Delivery() {
		super();
	}

	public int getDelivery_id() {
		return delivery_id;
	}

	public void setDelivery_id(int delivery_id) {
		this.delivery_id = delivery_id;
	}

	public int getInvoice_no() {
		return invoice_no;
	}

	public void setInvoice_no(int invoice_no) {
		this.invoice_no = invoice_no;
	}

	public Order_details getOrder() {
		return order;
	}

	public void setOrder(Order_details order) {
		this.order = order;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Tracking getTracking() {
		return tracking;
	}

	public void setTracking(Tracking tracking) {
		this.tracking = tracking;
	}

	@Override
	public String toString() {
		return "Delivery [delivery_id=" + delivery_id + ", invoice_no=" + invoice_no + ", order=" + order + ", status="
				+ status + ", tracking=" + tracking + "]";
	}
	
	
	
	
	
	
	
	
}
