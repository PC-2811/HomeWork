package org.capstore.domain;

import javax.persistence.Basic;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;


@Entity
@Table(name = "order_details")
public class Order_details {

	
	@Id
	@GeneratedValue
	private int order_id;
	
	
	@ManyToOne//(cascade=CascadeType.ALL,fetch=FetchType.EAGER)
	@JoinColumns({@JoinColumn(name="customer_id_Fk",referencedColumnName="customer_id",insertable=true,updatable=false)})
	private Customer customer;
	 
	
	@OneToOne
	@JoinColumns({@JoinColumn(name="cart_id_FK",referencedColumnName="cart_id",insertable=true,updatable=false)})
	private Cart cart;
	
	@Basic
	private double net_amount;
	
	@OneToOne//(cascade=CascadeType.ALL,fetch=FetchType.EAGER)
	@JoinColumns({@JoinColumn(name="shipping_id_FK",referencedColumnName="shipping_id",insertable=true,updatable=false)})
	private Shipping_details shipping_details;
	
	
	@Transient
	@OneToOne//(mappedBy="order")
	//@JoinColumns({@JoinColumn(name="delivery_id_FK",referencedColumnName="delivery_id",insertable=true,updatable=false)})
	private Delivery delivery;



	public Order_details(int order_id, Customer customer, Cart cart, double net_amount, Shipping_details shipping_details,
			Delivery delivery) {
		super();
		this.order_id = order_id;
		this.customer = customer;
		this.cart = cart;
		this.net_amount = net_amount;
		this.shipping_details = shipping_details;
		this.delivery = delivery;
	}



	public Order_details(Customer customer, Cart cart, double net_amount, Shipping_details shipping_details,
			Delivery delivery) {
		super();
		this.customer = customer;
		this.cart = cart;
		this.net_amount = net_amount;
		this.shipping_details = shipping_details;
		this.delivery = delivery;
	}



	public Order_details() {
		super();
	}



	public int getOrder_id() {
		return order_id;
	}



	public void setOrder_id(int order_id) {
		this.order_id = order_id;
	}



	public Customer getCustomer() {
		return customer;
	}



	public void setCustomer(Customer customer) {
		this.customer = customer;
	}



	public Cart getCart() {
		return cart;
	}



	public void setCart(Cart cart) {
		this.cart = cart;
	}



	public double getNet_amount() {
		return net_amount;
	}



	public void setNet_amount(double net_amount) {
		this.net_amount = net_amount;
	}



	public Shipping_details getShipping_details() {
		return shipping_details;
	}



	public void setShipping_details(Shipping_details shipping_details) {
		this.shipping_details = shipping_details;
	}



	public Delivery getDelivery() {
		return delivery;
	}



	public void setDelivery(Delivery delivery) {
		this.delivery = delivery;
	}



	@Override
	public String toString() {
		return "Order_details [order_id=" + order_id + ", customer=" + customer + ", net_amount=" + net_amount + "]";
	}



	
	
	
	
}
