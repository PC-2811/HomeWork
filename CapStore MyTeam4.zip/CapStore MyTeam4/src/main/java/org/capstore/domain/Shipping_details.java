package org.capstore.domain;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Transient;

@Entity
public class Shipping_details {
	
	@Id
	@GeneratedValue
	private int shipping_id;
	
	private int door_no;
	
	private String street_name;
	private String area_name;
	private String landmark;
	private String city;
	private String state;
	private int pincode;
	
	@Transient
	@OneToOne//(mappedBy="Shipping_details")
	private Order_details order;
	
	
	
	
	

	public Shipping_details(int shipping_id, int door_no, String street_name, String area_name, String landmark,
			String city, String state, int pincode, Order_details order) {
		super();
		this.shipping_id = shipping_id;
		this.door_no = door_no;
		this.street_name = street_name;
		this.area_name = area_name;
		this.landmark = landmark;
		this.city = city;
		this.state = state;
		this.pincode = pincode;
		this.order = order;
	}
	
	
	

	public Shipping_details(int door_no, String street_name, String area_name, String landmark, String city,
			String state, int pincode, Order_details order) {
		super();
		this.door_no = door_no;
		this.street_name = street_name;
		this.area_name = area_name;
		this.landmark = landmark;
		this.city = city;
		this.state = state;
		this.pincode = pincode;
		this.order = order;
	}




	public Shipping_details() {
		super();
	}




	public int getShipping_id() {
		return shipping_id;
	}

	public void setShipping_id(int shipping_id) {
		this.shipping_id = shipping_id;
	}

	public int getDoor_no() {
		return door_no;
	}

	public void setDoor_no(int door_no) {
		this.door_no = door_no;
	}

	public String getStreet_name() {
		return street_name;
	}

	public void setStreet_name(String street_name) {
		this.street_name = street_name;
	}

	public String getArea_name() {
		return area_name;
	}

	public void setArea_name(String area_name) {
		this.area_name = area_name;
	}

	public String getLandmark() {
		return landmark;
	}

	public void setLandmark(String landmark) {
		this.landmark = landmark;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public int getPincode() {
		return pincode;
	}

	public void setPincode(int pincode) {
		this.pincode = pincode;
	}

	public Order_details getOrder() {
		return order;
	}

	public void setOrder(Order_details order) {
		this.order = order;
	}
	
	
	
	
	
	
	

}
