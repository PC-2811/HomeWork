package org.capstore.domain;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.Transient;

@Entity
public class Cart {
	

	@Id
	@GeneratedValue
	public int cart_id;
	
	@OneToOne
	@JoinColumns({@JoinColumn(name="customer_id_FK",referencedColumnName="customer_id",insertable=true,updatable=false)})
	public Customer customer;
	
	@Transient
	@OneToOne
	private Order_details order;
	
	
	@ManyToMany
    @JoinTable(name="product_details", joinColumns={@JoinColumn(name="cart_id")}, inverseJoinColumns={@JoinColumn(name="product_id")})
    private List<Product> products_list=new ArrayList<>();
	
	
	private int quantity;


	public Cart(int cart_id, Customer customer, Order_details order, List<Product> products_list, int quantity) {
		super();
		this.cart_id = cart_id;
		this.customer = customer;
		this.order = order;
		this.products_list = products_list;
		this.quantity = quantity;
	}


	public Cart(Customer customer, Order_details order, List<Product> products_list, int quantity) {
		super();
		this.customer = customer;
		this.order = order;
		this.products_list = products_list;
		this.quantity = quantity;
	}


	public Cart() {
		super();
	}


	public int getCart_id() {
		return cart_id;
	}


	public void setCart_id(int cart_id) {
		this.cart_id = cart_id;
	}


	public Customer getCustomer() {
		return customer;
	}


	public void setCustomer(Customer customer) {
		this.customer = customer;
	}


	public Order_details getOrder() {
		return order;
	}


	public void setOrder(Order_details order) {
		this.order = order;
	}


	public List<Product> getProducts_list() {
		return products_list;
	}


	public void setProducts_list(List<Product> products_list) {
		this.products_list = products_list;
	}


	public int getQuantity() {
		return quantity;
	}


	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	


}
