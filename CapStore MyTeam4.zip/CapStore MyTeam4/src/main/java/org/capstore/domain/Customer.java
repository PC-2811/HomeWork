package org.capstore.domain;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Transient;

@Entity
public class Customer {
	
	@Id
	@GeneratedValue
	private int	customer_id;
	
	private String first_name;
	
	private String last_name;
	
   	private String mobile_no;
	
	@Transient
	@OneToOne//(mappedBy="customer")
	private Cart cart;

	@OneToMany //(mappedBy="customer")
    private List<Order_details> order=new ArrayList<>();

	public Customer(int customer_id, String first_name, String last_name, String mobile_no, Cart cart,
			List<Order_details> order) {
		super();
		this.customer_id = customer_id;
		this.first_name = first_name;
		this.last_name = last_name;
		this.mobile_no = mobile_no;
		this.cart = cart;
		this.order = order;
	}

	public Customer(String first_name, String last_name, String mobile_no, Cart cart, List<Order_details> order) {
		super();
		this.first_name = first_name;
		this.last_name = last_name;
		this.mobile_no = mobile_no;
		this.cart = cart;
		this.order = order;
	}

	public Customer() {
		super();
	}

	public int getCustomer_id() {
		return customer_id;
	}

	public void setCustomer_id(int customer_id) {
		this.customer_id = customer_id;
	}

	public String getFirst_name() {
		return first_name;
	}

	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}

	public String getLast_name() {
		return last_name;
	}

	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}

	public String getMobile_no() {
		return mobile_no;
	}

	public void setMobile_no(String mobile_no) {
		this.mobile_no = mobile_no;
	}

	public Cart getCart() {
		return cart;
	}

	public void setCart(Cart cart) {
		this.cart = cart;
	}

	public List<Order_details> getOrder() {
		return order;
	}

	public void setOrder(List<Order_details> order) {
		this.order = order;
	}

	@Override
	public String toString() {
		return "Customer [customer_id=" + customer_id + ", first_name=" + first_name + "]";
	}

	
	
	
	
	
	
	

}
