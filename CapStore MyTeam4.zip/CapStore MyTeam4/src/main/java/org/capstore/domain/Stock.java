package org.capstore.domain;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.OneToOne;

@Entity
public class Stock {
	@Id
	@GeneratedValue
	private int stock_id;
	private int no_of_items;
	
	
	@OneToOne//(cascade=CascadeType.ALL,fetch=FetchType.EAGER)
	@JoinColumns({@JoinColumn(name="product_id_FK",referencedColumnName="product_id",insertable=true,updatable=false)})
	private Product product;
	
	public Stock(){}
	
	public Stock(int no_of_items, Product product) {
		super();
		
		this.no_of_items = no_of_items;
		this.product = product;
	}


	public Stock(int stock_id, int no_of_items, Product product) {
		super();
		this.stock_id = stock_id;
		this.no_of_items = no_of_items;
		this.product = product;
	}


	public int getStock_id() {
		return stock_id;
	}


	public void setStock_id(int stock_id) {
		this.stock_id = stock_id;
	}


	public int getNo_of_items() {
		return no_of_items;
	}


	public void setNo_of_items(int no_of_items) {
		this.no_of_items = no_of_items;
	}


	public Product getProduct() {
		return product;
	}


	public void setProduct(Product product) {
		this.product = product;
	}

/*
	@Override
	public String toString() {
		return "Stock [stock_id=" + stock_id + ", no_of_items=" + no_of_items + ", product=" + product + "]";
	}*/
	
	
	
	
}
