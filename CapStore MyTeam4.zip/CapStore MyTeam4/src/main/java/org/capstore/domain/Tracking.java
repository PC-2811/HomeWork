package org.capstore.domain;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.OneToOne;

@Entity
public class Tracking {

	@Id
	@GeneratedValue
	private int tracking_id;
	
	@OneToOne
	@JoinColumns({@JoinColumn(name="delivery_id_FK",referencedColumnName="delivery_id",insertable=true,updatable=false)})
	private Delivery delivery;
	
	@OneToOne
	@JoinColumns({@JoinColumn(name="order_id_FK",referencedColumnName="order_id",insertable=true,updatable=false)})
	private Order_details order;
	
	private String tracking_status;
	
	private Date expected_delivery_date;
	
	private String current_location;
	
	private String next_location;
	
	private Date delivery_date;
	
	private String description;

	public Tracking(int tracking_id, Delivery delivery, Order_details order, String tracking_status,
			Date expected_delivery_date, String current_location, String next_location, Date delivery_date,
			String description) {
		super();
		this.tracking_id = tracking_id;
		this.delivery = delivery;
		this.order = order;
		this.tracking_status = tracking_status;
		this.expected_delivery_date = expected_delivery_date;
		this.current_location = current_location;
		this.next_location = next_location;
		this.delivery_date = delivery_date;
		this.description = description;
	}

	public Tracking(Delivery delivery, Order_details order, String tracking_status, Date expected_delivery_date,
			String current_location, String next_location, Date delivery_date, String description) {
		super();
		this.delivery = delivery;
		this.order = order;
		this.tracking_status = tracking_status;
		this.expected_delivery_date = expected_delivery_date;
		this.current_location = current_location;
		this.next_location = next_location;
		this.delivery_date = delivery_date;
		this.description = description;
	}

	public Tracking() {
		super();
	}

	public int getTracking_id() {
		return tracking_id;
	}

	public void setTracking_id(int tracking_id) {
		this.tracking_id = tracking_id;
	}

	public Delivery getDelivery() {
		return delivery;
	}

	public void setDelivery(Delivery delivery) {
		this.delivery = delivery;
	}

	public Order_details getOrder() {
		return order;
	}

	public void setOrder(Order_details order) {
		this.order = order;
	}

	public String getTracking_status() {
		return tracking_status;
	}

	public void setTracking_status(String tracking_status) {
		this.tracking_status = tracking_status;
	}

	public Date getExpected_delivery_date() {
		return expected_delivery_date;
	}

	public void setExpected_delivery_date(Date expected_delivery_date) {
		this.expected_delivery_date = expected_delivery_date;
	}

	public String getCurrent_location() {
		return current_location;
	}

	public void setCurrent_location(String current_location) {
		this.current_location = current_location;
	}

	public String getNext_location() {
		return next_location;
	}

	public void setNext_location(String next_location) {
		this.next_location = next_location;
	}

	public Date getDelivery_date() {
		return delivery_date;
	}

	public void setDelivery_date(Date delivery_date) {
		this.delivery_date = delivery_date;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
	
	
	
	
	
	
}
