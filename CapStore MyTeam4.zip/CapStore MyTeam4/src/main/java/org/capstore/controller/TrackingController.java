package org.capstore.controller;

import java.util.Map;

import org.capstore.service.CategoryService;
import org.capstore.service.MerchantService;
import org.capstore.service.ProductService;
import org.capstore.service.TrackingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class TrackingController {

	@Autowired
	public TrackingService trackingService;
	
	@Autowired
	public ProductService productservice;
	
	@Autowired
	public MerchantService merchantservice;
	
	@Autowired
	public CategoryService categoryservice;
	
	@RequestMapping("/deliveryDetails")
	public String getAllDeliveryDetails(Map<String, Object> maps){
		
		maps.put("deliveryList", trackingService.getDeliveryDetails());
		
		return "DeliveryDetails";
	}
	
	
}
