package org.capstore.dao;

import java.util.ArrayList;
import java.util.List;

import org.capstore.domain.Brand;
import org.capstore.domain.Category;
import org.capstore.domain.Merchant;
import org.capstore.domain.Product;
import org.capstore.domain.Stock;
import org.capstore.domain.Sub_category;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Repository;


@Repository("productDao")
public class ProductDaoImpl implements ProductDao{

	

	@Autowired
	public SessionFactory sessionFactory;
	
	@Override
	public List<Brand> getAllBrands() {
		List< Brand> brands=sessionFactory.getCurrentSession().createQuery("from Brand").list();
		
		//System.out.println(brands);
		
		return brands;
	}

	

	@Override
	public List<Sub_category> getAllSub_category() {
	List< Sub_category> sub_category=sessionFactory.getCurrentSession().createQuery("from Sub_category").list();
		
		//System.out.println(sub_category);
		
		return sub_category;
	}

	@Override
	public List<Stock> getAllStock() {
		
		List< Stock> stock=sessionFactory.getCurrentSession().createQuery("from Stock").list();
		
		//System.out.println(stock);
		
		return stock;
	}

	
	@Override
	public void saveProduct(Product product) {
		/* Session session = this.sessionFactory.getCurrentSession();
		session.beginTransaction();*/
		//System.out.println(product+"dao");
		sessionFactory.getCurrentSession().saveOrUpdate(product);
		System.out.println("DAO"+sessionFactory.getCurrentSession().createQuery("select product_id from Product order by product_id desc limit 1").list());
		//System.out.println("Commited");
		System.out.println(product.getProduct_id());
		Product product1=new Product();
		product1.setProduct_id(product.getProduct_id());
		Stock stock=product.getStock();
		stock.setProduct(product1);
		
		//int n=sessionFactory.getCurrentSession().createQuery("insert into Stock(no_of_items,product_id_FK) values("+product.getStock().getNo_of_items()+","+product.getProduct_id()+")").executeUpdate();
		//System.out.println("No of items"+n);
		sessionFactory.getCurrentSession().save(stock);
		
		System.out.println(product.getStock());
		
		
		/*Query query=session.createQuery("insert into purged_accounts(id, code, status) "+
			    "select id, code, status from acount where status=:status");
			query.setString("status", "purged");
			int rowsCopied=query.executeUpdate();*/
		/*session.getTransaction().commit();*/
	}
	
	
	@Override
	public List<Product> getAllProducts() {
		
		List<Product> products=new ArrayList<>();
		List<Product> products1=new ArrayList<>();
		products=sessionFactory.getCurrentSession().createQuery("from Product").list();
		for(Product prod:products){
			Category cat=prod.getCategory();
			//System.out.println(cat.getCategory_id());
			Category cate1=getCategoryById(cat.getCategory_id());
			prod.setCategory(cate1);
			System.out.println(prod+"After setting category");
			//products1.add(prod);
		}
		//System.out.println(products);
		//System.out.println(products1);
		 return products1;
	}



	private Category getCategoryById(int category_id) {
		Category cateogry=new Category();
		System.out.println(" getCategoryById"+sessionFactory.getCurrentSession().createQuery("select category_name from Category where category_id="+category_id).list());
		List<String> name=sessionFactory.getCurrentSession().createQuery("select category_name from Category where category_id="+category_id).list();
		for(String list:name){
		cateogry.setCategory_name(list);
		System.out.println("categoy name:"+cateogry.getCategory_name());
		}
		cateogry.setCategory_id(category_id);
		return cateogry;
	}



}
