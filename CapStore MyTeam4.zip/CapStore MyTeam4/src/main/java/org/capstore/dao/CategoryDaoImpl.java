package org.capstore.dao;

import java.util.List;

import org.capstore.domain.Category;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Repository;
@Repository("categoryDao")
public class CategoryDaoImpl implements CategoryDao{

	
	@Autowired
	public SessionFactory sessionFactory;

	@Override
	public List<Category> getAllCategories() {
		
		
		List<Category> cat=(List<Category>)sessionFactory.getCurrentSession().createCriteria(Category.class).list();
		
		System.out.println(cat);
		return cat;
}
	
	
}
