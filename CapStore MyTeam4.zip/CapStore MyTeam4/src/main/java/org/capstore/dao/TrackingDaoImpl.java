package org.capstore.dao;

import java.util.ArrayList;
import java.util.List;

import org.capstore.domain.Customer;
import org.capstore.domain.Delivery;
import org.capstore.domain.Order_details;
import org.capstore.domain.Product;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Order;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository("trackingDao")
public class TrackingDaoImpl implements TrackingDao{
	
	@Autowired
	public SessionFactory sessionFactory;

	@Override
	public List<Delivery> getDeliveryDetails() {
		
		List<Delivery> delivery=new ArrayList<>();
		List<Delivery> delivery1=new ArrayList<>();
		delivery=sessionFactory.getCurrentSession().createQuery("from Delivery").list();
		System.out.println("The list size is" + delivery.size());
		for (Delivery delivery2 : delivery) {
			
			/*Customer customer=delivery2.getOrder().getCustomer();
			System.out.println(customer.getCustomer_id());
			Customer cust=getCustName(customer.getCustomer_id());
			System.out.println(cust);
			Order_details order1=new Order_details();	
			order1.setCustomer(cust);
			delivery2.setOrder(order1);
			System.out.println(delivery2);
			delivery1.add(delivery2);
		
			System.out.println(delivery);*/
			System.out.println("ORDER ID="+delivery2.getOrder().getOrder_id());
			Order_details order=getOrderById(delivery2.getOrder().getOrder_id());
			
			
			
			
			
			delivery1.add(delivery2);
			
			
		}
		
		return delivery1;
	}
	
	private Order_details getOrderById(int order_id) {
		Order_details order=new Order_details();
		
		List<Order_details>oderDetails=sessionFactory.getCurrentSession().createQuery("from Order_details where order_id="+order_id).list();
		System.out.println("ORDERBYID"+oderDetails);
		
		return order;
	}

	public Customer getCustName(int cust_id){
		
		
		Customer cust=null;;
	
		
		List<Customer> customerName=sessionFactory.getCurrentSession().createQuery("from Customer where customer_id="+cust_id).list();
		
		for(Customer customer1:customerName){
			 cust=new Customer();
			
			cust.setFirst_name(customer1.getFirst_name());
			cust.setLast_name(customer1.getLast_name());
			
			System.out.println("Customer name:"+customer1.getFirst_name());
			}
			//cateogry.setCategory_id(category_id);
		
		
		
		/*Category cateogry=new Category();
		//System.out.println(" getCategoryById"+sessionFactory.getCurrentSession().createQuery("select category_name from Category where category_id="+category_id).list());
		List<String> category_name=sessionFactory.getCurrentSession().createQuery("select category_name from Category where category_id="+category_id).list();
		for(String name:category_name){
		cateogry.setCategory_name(name);
		System.out.println("category name:"+cateogry.getCategory_name());
		}
		cateogry.setCategory_id(category_id);
		return cateogry;*/
		
		return cust;
		
	}

}
