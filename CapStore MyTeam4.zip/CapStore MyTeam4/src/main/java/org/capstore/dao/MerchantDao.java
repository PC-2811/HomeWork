package org.capstore.dao;

import java.util.List;

import org.capstore.domain.Merchant;

public interface MerchantDao {

	public void saveMerchant(Merchant merchant);
	public List<Merchant> getAllMerchants();

}
