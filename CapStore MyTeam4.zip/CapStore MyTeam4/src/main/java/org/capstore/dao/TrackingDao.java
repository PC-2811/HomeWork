package org.capstore.dao;

import java.util.List;

import org.capstore.domain.Delivery;

public interface TrackingDao {
	
	public List<Delivery> getDeliveryDetails();

}
