package org.capstore.service;

import java.util.List;

import org.capstore.dao.TrackingDao;
import org.capstore.domain.Delivery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class TrackingServiceImpl implements TrackingService {

	@Autowired
	TrackingDao trackingDao;
	
	@Transactional
	public List<Delivery> getDeliveryDetails() {
		
		return trackingDao.getDeliveryDetails();
	}

}
