package org.capstore.service;

import java.util.List;

import org.capstore.domain.Delivery;


public interface TrackingService {

	public List<Delivery> getDeliveryDetails();
	
	

}
