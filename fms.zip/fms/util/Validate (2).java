package com.flp.fms.util;

public class Validate {

	public static boolean isValidTitle(String title){
		return title.matches("[A-Za-z0-9.,! ]+");
	}
	
	public static boolean isValidDate(String myDate){
		return myDate.matches("[0123][0-9]-(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)-[12][890]\\d{2}");
	}
}
