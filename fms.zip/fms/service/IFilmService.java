package com.flp.fms.service;

import java.util.List;

import com.flp.fms.domain.Language;

public interface IFilmService {
	public List<Language> getLanguages();
}
