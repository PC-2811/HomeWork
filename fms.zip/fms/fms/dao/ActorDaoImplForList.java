package com.flp.fms.dao;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Film;

public class ActorDaoImplForList implements IActorDao{

	
	@Override
	public Set<Actor> getActors() {
		
		Set<Actor> actors=new TreeSet<>();
		actors.add(new Actor(101,"Sharukh","Khan"));
		actors.add(new Actor(102,"Salman","Khan"));
		actors.add(new Actor(103,"Ram","Sharma"));
		actors.add(new Actor(104,"Ranbir","Singh"));
		
		return actors;
	}

	
	

}
